## 1. OSI & Device

##### 1. PHYSIC:物理设备之间进行连接

**[HUB,Cable]** 

​	该层只处理(transmit & Receive) bit数据, 即1,0. HUB也不过滤数据, 会发送到全部本地设备上, 浪费一定的带宽

##### 2. LINK：LAN的主机之间或WAN的设备之间建立连接

**[Switch, Bridge, Modem]**

​	该层处理Data Frame(一定的bit长度, 来自于MAC层), 并建立LAN点对点通信

 	Switch会根据MAC adrress table识别目标, 即过滤数据, 指向特定目标. 但不识别IP Address.

​	Bridge用于连接两个LAN

##### 3. NETWORK：在不同的网络之间LAN－WAN之间建立连接

**[Router]**

该层依据Transport里的规定的协议建立Route Table, 并依据该Table传输数据, 该层依据IP Address来传输数据, 比如IPpackage(V4.V6), ICMP,ARP,IPsec等

##### 4. TRANSPORT：在源和目的地之间通过地址编码准备进行连接

**[Gateway, Firewall]**

TCP/UDP, 同样建立点对点通信. 但具备分割/再合并的校验功能, 如果这个过程导致数据损坏, 可以进行修复.

##### 5. Session Layer

##### 6. Presentation

##### 7. APPLICATION

**[Server, PC]**

利用Application建立通信

## 2. WAN

##### 连接类型:

* **MPLS**: 不使用ip地址, 而是使用**OSPF(Open Shortest Path First)**将数据发送到目的地
* **HDLC,PPP**: 高级数据链路控制, 点对点协议

