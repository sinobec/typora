### 1. Operations

#### 1.1 打开文件

`open(‘file’)`打开文件, 并返回一个obj; 有4种打开文件的模式, 默认为r+t

* r: 读取文件 若文件不存在, 则报错 --> 默认
* a: Append, 若文件不存在, 则新建
* w: 开启文件准备写入, 若文件不存在, 则新建
* x; Create, 新建文件, 若已存在, 则报错

文件格式分为: t -> text, b ->binary

```
thisFile = open(abc.txt)
```

#### 1.2 关闭文件

```python
thisFile = open('my file')
showContent = thisFile.readlines() # 显示内容
thisFile.close()  #关闭文件以便让其他程序使用该文件, 否则会一直锁定该文件
```

#### 1.3 open with

为了避免遗忘file.close()导致文件被锁定, 可以使用`open with`, 可以在完成操作后自动close文件

```
with open ('myfile') as thisFile:
	showContent = thisFile.readlines()
```

