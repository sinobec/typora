

## 1. SFTP

利用ssh协议上传下载文件, 需要用户登录.

```
#sftp user@ip
sftp>
```

##### 服务器及本机的文件目录操作

服务器端命令: 登录后可以使用常用命令, 比如ls, mkdir, chgrp, ln, rm, rename
客户端命令: lcd, lls, lpwd, lmkdir, 

##### 1.2 文件上传下载

```
put fileName, 上传至远程服务器当前目录

get fileName, 下载至本地当前目录
```

## 2.scp

无需用户登录

* option:

  -p: 复制时保留权限

  -r: 复制目录时包含子文件夹

  ```
  #scp -/etc/nginx root@104.243.27.45:/var/www/html
  将本地的/etc/nginx目录完整地复制到44.55的userHome/bck下.
  #scp r@192.168.20.11:/etc/nginx/nginx.conf /myBackUp
  将20.11下的/etc/nginx/nginx.conf文件复制到本地的MyBackUp文件夹下
  ```

  
