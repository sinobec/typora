



# 1. 系统主要目录

* /usr: Unix Software Resource,发行版软件目录; 主要包含

  **/usr/bin/**: 系统主要命令, 即可执文件. 可使用which cli来查询该命令所在的目录

  **/usr/local/**: 自行安装的软件

  **/usr/lib**:  ⼀些程序使⽤的动态函数库

* **/var**: 经常变化的文件,比如log, MySQL数据库, 网站内容等

* **/etc**: 配置文件

* /dev: 

* /home:

#### 创建目录:

```
mkdir -p : 用于同时创建父目录及子目录 
#
[ ! -d "mypath/subdir" ] && mkdir -p mypath/subdir
```

# 2. 文件结构

#### 2.1 文件元数据(METADATA)

##### * inode: 文件的元数据, 用于:

* 放置文件的权限,属性, secure content和block number (文件的实际数据放置到block里, 一个文件仅使用一个inode,但一个文件可能存储于多个block里)

  文件定位过程: 先搜索第一层目录的inode,查询权限后 -> 第一层目录的block -> 第二层目录的inode,查询权限后->第二层目录的block->...->文件的inode,查询权限->文件的block

  - [ ] inode map: 记录inode number的使用情况. 根据此表可对新文件赋予未使用的inode number.和superblock/block map一同称为**metadata区**
  - [ ] inode table: 记录inode number和文件之间的索引关系/ 和daba block一同称为**数据存储区**
  - [ ] 文件的写入不仅需要将数据写入数据存储区,也需要将其与metadata区同步

* 查询inode信息: **ls -il**, **df -i**

  ```
  >ls -il /etc
  287985 drwxr-xr-x.     4      root   root   78 Mar  2 02:09 dbus-1
  此数字代表inode number   有4个hl
  ```

  ```
  >df -i .
  Filesystem     Inodes    IUsed    IFree      IUse%  Mounted on
  /dev/sda3      19961856  69651    19892205    1%    /
  ```

#### 11.2 superblock: 文件系统的元数据(metadata),记录文件系统最基本的信息(包括inode/block

的总量、使⽤量、剩余量， 以及⽂件系统的格式与相关信息等),如果sb损坏,则该分区无法挂载. 因此sb会分散存储在block里.

* 查询可用来恢复的sb: **`dumpe2fs /dev/sda1 | grep -i superblock`**

  ```
  >dumpe2fs /dev/sda1 | grep -i superblock
  Primary superblock at 0, Group descriptors at 1-6
    Backup superblock at 32768, Group descriptors at 32769-32774
    Backup superblock at 98304, Group descriptors at 98305-98310
  ```


#### 11.3 hard link: (文件名)连接到同一个inode, 不能hl目录

​	建立hl: 

```
ln /etc/dbus-1 dbus-1
```

#### 11.4 symbolic link: 快捷方式

​	建立sl:

```
ln -s /etc/dbus-1 dbus-1
```

# 3. 设置权限

## 2.1 设置一般权限: chmod之a(all) = u/g/o

#### 2.1.1 默认权限

1. 目录默认最高权限: 777(因为目录默认需要有x的list权限)

2. 文件默认最高权限为666(rw- rw- rw-)
3. 目录权限超越文件权限

> 对⽬录来说，rwx则是针对“⽬录内的⽂件名列表”来设计权限. 目录权限超越目录内文件权限. 即如果用户有文件夹的x权限,但是没有文件夹内文件的任何权限,仍然可以删除该文件.

#### 2.1.2 设置权限

```
r/4: 可列出目录内文件列表
w/2: 可在目录内创建删除文件
x/1: 可进入该目录
=>
u: USER
g: GROUP
o: OTHER
```

* 修改文件:不仅需要有对文件的rw权限,也需要具备当前目录的x权限.
* 创建文件: 不仅需要有对文件的rw权限,也需要具备当前目录的wx权限

```
chmod a-x : 对所有人(u,g,o)均移除x权限
chmod o+w : 对o添加w权限
chgrp groupName dir: 设置目录的所有组
```

#### 2.1.3 umask

* umask->默认权限:

  目录的权限是7减去umask, 文件是6-umask

  比如umask0022,相当于go减去了w; 对于目录则指的是755,对于文件指的是644

* umask->修改权限:

  在当前目录下执行: `**umask nnn**, 比如umask 002,就将当前目录赋予了g/w权限.

## 2.2 设置只读权限: **chattr + / -**

* **chattr +i file**: 不能修改。不能删除或重命名，不能创建到该文件的链接，也不能向该文件写入数据。只有超级用户或拥有 CAP_LINUX_IMMUTABLE 能力的进程才能设置或清除此属性
*  **chattr +a file** : 设置文件无法被删除,且只能其中的增加数据, 比如设置logs文件. 如果要取消该属性: chattr -a fiwaaaaaleName
* 显示文件隐藏属性: **lsattr file**

## 2.3 设置特殊权限: 

#### 2.3.1 设置SUID/SGID/SBIT

* 设置SUID: **`chmod 4755 file`**; 针对二进制文件. 当文件的u/x位变成s时, 等于设置了suid, 即任何人执行该(二进制)可执文件时,都会暂时成为owner.典型的是/usr/bin/passwd文件,. 该文件可以访问/etc/shadow以获取用户密码.

  ```
  设置suid方法
  #chmod 4xxx file
  ```

* 设置SGID: **`chmod 2775 dir`**; 主要用于目录, 当目录具备该权限(g/x变成了s), 在此目录下新建的文件, 其所属组都会和父目录的组一样.这样可以保证该组成员在此目录下新建的文件可以被其他组员编辑.

  ```
  设置sgid方法
  #chmod 2xxx dir
  ```

* SBIT: 主要用于目录, 当目录具备该权限, 在此目录下的文件只有owner和root可以删除.

  ```
  设置sbit方法
  #chomd 1xxx dir
  ```

* ###### 查询具有SUID/GUID/SBIT权限的文件/文件夹

  ```
  #find path -perm /modeNum: /的意思是只要被该模式'比如6000'所涵盖,即可被搜索.也可以写成/7000,那么三种模式就都包括
  #find / -perm /6000: 查询当前目录下具备SUID或GUID的文件/文件夹
  #find / -perm /+4000
  ```
  

#### 2.3.2 为单独用户设置权限: **setfacl**

可以针对单独的文件或文件夹, 为特定的用户设置相关权限, 其权限或超越该用户所属的组授予的权限. 这样就可以让这个用户访问改组所不能访问的文件或文件夹

* 设置user权限

  ```
  setfacl -m u:userName:rwx fileName或dir
  setfacl -m m:rwx file/dir
  ```

* 设置组权限

  ```
  setfacl -m g:groupName:rwx file或dir
  ```

* 取消acl

  ```
  setfacl -x u:userName file
  setfacl -b file/dir
  ```

* 查询某文件或文件夹的acl权限

  ```
  getfacl -b file或dir
  ```

# 3.复制文件:

## 3.1 复制文件: cp

```
#cp -a
将源文件的属性也复制到目标文件, 比如权限,创建时间

#cp file1 file2 ... targetDir
将多个文件复制到同⼀个⽬录
```

## 3.2 创建/复制文件link

```
ln sourceFile targetFile: 创建hard link
ln -s sourceFile targetFile : 创建symbol link
```



```
#cp -s 源文件 软连接文件: 建立slink
#cp -l 源文件 硬链接文件: 建立hardlink文件, 创建后,ls该文件,其i-node数量会增加一个
#cp -d 源slink 目标slink: 复制symbotic link文件, 否则会将源文件复制
```

# 4. 显示文件

#### 4.1 显示文件内容

```
#more: 空格键->翻页; enter键->翻行; /str 然后回车->搜索字符串
#less: 空格键->翻页; /str->向下搜索字符串; ?str->向上搜索字符串
#head -n 与tail -n
#tail -f /var/log/messages: 有新数据时立即显示
```

#### 4.2 显示文件属性

```
#ls -i: 显示inode信息
#ls -Z: 显示文件的secure content
```

#### 4.3 显示文件夹容量: **du**

```
du: 
	-s:显示目录总大小
	-S:归纳显示子目录大小
	-h:易读模式
#e.x
du -hs /etc
```

# 5. 搜索文件

##### 5.1 find

```
#find / -type d -name 'httpdocs': 找到特定的目录
#find / -size +1M: 搜索大于1M的文件
#find /etc -perm /7000: 搜索有suid,sgid,sbit权限的文件
#find /usr/bin /usr/sbin -perm /7000 -exec ls -l {} \; 从-exec开始是额外命令块, -exec指的是命令起始, \;是命令结尾, {}是find搜索结果放置区
```

###### * 按照文件时间特性来搜索

包括: modification time( mtime); status time (ctime); access time (atime）

```
#find path -mtime n fileName: n天之前的"那一天内"有改动的文件
#find path -mtime -n fileName:n天内有改动的文件
#find path -mtime +n fileName: n天前有改动的文件

#find /etc -mtime 0: 显示一天内etc内有改动的文件
```

##### 5.2 按照特定条件搜索文件

###### 		whereis: 仅搜索 /bin /sbin等特定目录

######  	   locate: 搜索数据库里已有的文件列表, 该数据库每天更新一次,所以可能找不到一天内新建的文件. 可用`updatedb`手动更新数据库(需要几分钟)

```
#locate -ir fileName: -i 忽略大小写, -r 可使用regex
```

# 6. 压缩文件/文件夹: **tar** -zvf

##### tar包括压缩和打包两个功能:

​	-f 文件名: tar要处理的文件

​	-z: 使用gzip解压/压缩

​	-v: 处理过程中显示文件名

​	-p: 保留权限等属性,用于打包配置文件

​    -c: 创建压缩文件

1. ##### 解压:  **-x**

   -x: 解压缩

   -C path: 解压缩到特定路径 

```
tar -xzvf zipfile #解压
tar -xzvf zipFile /path/file #仅提取出特定文件
```

2. ##### 压缩:  **-c**

```
tar -czvf target.tar.gz sourcefileORdir #压缩(因为使用了z选项,因此压缩纹面扩展名需要手动指定为tar.gz)
```

1. ##### 备份:  **-jc**


```
tar --exclude path1 --exclude path2 -jcvpf TARGETpath&name sourcePath(通常是/)
```

1. #####  查看压缩包:  **-t**


```
tar -tzvf zipFile  #查看压缩包
```

# 7. 判断文件/文件夹是否存在等: test

```
-e: 该“⽂件名”是否存在？
-f: 该“⽂件名”是否存在且为⽂件（file）？ 
-d: 该“⽂件名”是否存在且为⽬录（directory）？ 
多重判断条件符号:
-o: 或者
-a: 以及
! : 非,例如 [ ! -d "${xxx}" ],判断变量xxx是否不是一个文件夹
#
test -f file && echo "existing" || echo "doesn't existing"
等同于 [ -f file ] && echo "existing" || echo "doesn't existing"
```

* test判断的符号方法: **[   ]**

  该判断方式的参数和test相同

  比如`[ -f filename ]; echo $?`, 括号两侧必须有空格

  ```
  [ "${a1}"=="y" -o "${a1}"=="Y" ]
  ```

# 8. 编辑文件: 

### 8.1 vim

```
vi ~/.vimrc

syntax on
colorscheme desert
```

​	G: 跳转到最末

​	gg: 跳转到开始

​	/str: 向下搜索str

​	?str: 向上搜索str

​		n: 继续刚才的搜索

​		N:反向继续刚才搜索

​	:w newfile: 存储为新文件

> vim意外中断后, swp文件的处理: R->恢复之前的编辑; D->删除之前的编辑,开始新的编辑

​	编辑$HOME/..vimrc, 增加如下设置:

```
set showmode
set nohlsearch
set autoindent
set tabstop=4
set expandtab
```

### 8.3 echo

显示指定内容:

* echo -e: 其后的句子可以使用escape

  ```
  echo -e "Geeks \bfor \bGeeks"
  ```

  

echo是 将文本新内容添加到文件里, 

```
echo "line 1 content
line 2 content
line 3 content" >> myfile.txt
```

### 8.4 cat

cat 可以将其他文件的内容添加到文件里

```
cat >> destnationFile < sourceF
```

cat也可以将文本添加到文件里

```
# cat >> greetings.txt <<EOL
# line 1 content
# line 2 content
# line 3 content
# EOL
```



# 10. 其他

查看可创建最大文件体积: ulimit -a | grep 'file size'





