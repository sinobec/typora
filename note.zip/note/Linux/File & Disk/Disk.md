# 1. 文件系统格式

#### 1.1 查询文件系统: **df**

> XFS: 64-bit journaling file system; 
>
> * ensures file system integrity (easy recovery after accidient)
> * Fast index and allocating
> * High performance and scalability
> * High I/O

df: 其后接文件夹,会显示文件夹所在分区的信息
	-h: 易读
	-T: 显示文件系统
	-i:  显示inode信息

```
#df -hT
文件系统       类型      容量  已用  可用 已用% 挂载点
/dev/sda3      xfs      39G  3.7G  35G 10%   /
#df -hi
文件系统       Inode 已用(I) 可用(I) 已用(I)% 挂载点
/dev/sda3     20M    69K     19M     1%      /
```



CentOS默认的是xfs; Ubuntu默认的是ext4

* 查询xfs文件系统信息: **xfs_info /dev/sda3**

```
>xfs_info /dev/sda3
#isize=512: inode的size
#bsize=4096 blocks=9980928: block的size和总数
#extsz=4096: realtime区域的extend的size
```


> xfs文件系统特点: 更快格式化. 包含data section(即**数据存储区**), log section(类似于log区, 系统意外中断时会在此查询历史活动以便校验), realtime section(新数据的缓存)

* 查询ext4文件系统信息: **dumpe2fs -h /dev/sda1**

#### 1.2 修复文件系统故障

| 必须先unmoun分区才可以检查, 且检查有可能损害系统

###### * 修复xfs: **xfs_repair  /dev/sda4**

###### * 修复ext4: **fsck.ext4 -b 32767  /dev/sda5**

​	32767是通过`dumpe2fs`查询到的可用于修复的有效superblock起始block

#### 1.3, 查询哪个proc在使用该文件或设备: fuser

```
fuser -muv fileName或者devName
#fuser /etc/nginx/nginx.conf
  root      11921 Frce. (root)nginx
                     www-data  11922 Frce. (www-data)nginx
                     www-data  11923 Frce. (www-data)nginx
```

# 2. 创建新分区

### 1.1 获取磁盘

* ###### 显示已有磁盘: **lsblk**

  ```
  >lsblk
  sda      8:0    0 46.6G  0 disk
  |-sda2   8:2    0    8G  0 part [SWAP]
  |-sda3   8:3    0 38.1G  0 part /
  `-sda1   8:1    0  512M  0 part /boot/efi
  ```

* ###### 判断磁盘分区类别(gpt/mbr): **parted dev print** 

  ```
  #parted /dev/sda print (此处使用整个磁盘名)
  Partition Table: gpt
  或
  Partition Table: msdos
  Number  Start  End     Size    File system  Flags
   1      0.00B  40.9GB  40.9GB  xfs
  ```


### 2. 获取并操作分区: 

* ###### 显示分区大小类型使用率等:  **`df -hT`**

  ```
  #df -hT
  Filesystem     Type      Size  Used Avail Use% Mounted on
  devtmpfs       devtmpfs  449M     0  449M   0% /dev
  tmpfs          tmpfs     489M     0  489M   0% /dev/shm
  tmpfs          tmpfs     489M   50M  440M  11% /run
  tmpfs          tmpfs     489M     0  489M   0% /sys/fs/cgroup
  /dev/sda3      xfs        39G  5.7G   33G  15% /
  ```

* ###### 创建新分区: 

  * **gdisk**->对应gpt
  * **fdisk**->对应mbr
  * **parted** : 可以创建上述两种分区

  ​	显示分区类型: gpt / mbr

  ```
  #gdisk /dev/sda (此处使用整个磁盘名)
  之后可以继续其他操作,比如创建/删除分区
  ```

  ​	创建新分区()

  ```
  #gdisk /dev/sda
  #p  查看已有分区
  #n  开始新建分区
  在Last sector处, 使用+300M, +15GB之类的方式制定容量,其余步骤可使用默认
  #每新建一个分区就使用p查看一下新的分区表
  ```

  => 把文件创建为分区:

  ​	1. 创所需容量的空文件:

  ​	`dd if=/dev/zero of=/srv/挂载点 bs=1M count=512`; 创建了512M的(可作为分区)空文件

  ​	`dd if=/dev/zero of=/tmp/swap bs=1G count=2`; 创建了2GB的(可作为swap)空文件

* ###### 删除分区

  ```
  #gdisk
  #p  查看
  #d  选择要删除的分区号
  ```

> 使用parted也可以创建分区,主要用于脚本自动执行分区操作.

###  3. 最后进行分区格式化: **mkfs**

* 格式化成xfs: **mkfs -t xfs /dev/sda4** 或 **mkfs.xfs /dev/sda4**

  ```
  mkfs.xfs -f -d agcount=6 /dev/sda4 
  #-d agcount=6指的是针对6xcpu线程系统, -f强制该格式
  ```

* 格式化成ext4: 

  ```
  mkfs.ext4 /dev/sda5
  ```
  
  

# 2. 挂载/卸载filesystem: **mount**

###### * 先查询可挂载的磁盘uuid: **blkid**

```
>blkid
/dev/sda1: UUID="35BC-6D6B..." TYPE="vfat"
```

###### * 设置设备的label: 

​	xfs类型: `xfs_admin -L newLabel /dev/sda4`

​	ext4类型: `tune2fs -L newLabel /dev/sda4`

###### * 创建空目录

```
mkdir /data/usb
```

###### * 挂载(filesystem)

```
#挂载usb
mount UUID="35BC-6D6B" /data/usb
#挂载iso
mount -o loop isoFile mountPoint
```

​	=> 开机自动挂载: **/etc/fstab**. 其中文件系统参数可以设置: async/sync; auto/noauto; rw/ro等

​	设置开机挂载, 在文件中增加: `UUID/Label  /mountpoint  xfs(或ext4)  defaults  0  0`

```
>cat /etc/fstab
#设备/UUID              mount point 分区的⽂件系统 ⽂件系统参数                   是否以 fsck
UUID=677c85ad-19a0-44...... /        xfs  			defaults,_netdev,_netdev  0   0
LABEL=cloudimg-rootfs       /        ext4 			defaults	                0   1
```

​	设置好fstab后, 需要进行测试:

```
mount -a #立即挂载fstab里没mount的分区
df       #显示当前已挂载的分区
```

​	=>挂载文件创建的分区: 

		1. 挂载一般文件分区: `mount -0 loop UUID= 挂载点`
		2. 挂载swap分区: `mkswap /tmp/swap`,  `swapon /tmp/swap`, `swapon -s`

> *将文件分区写入fstab时不可以用uuid,只能用文件路径*

###### * 卸载(须先将当前⽬录移到 mount point及其⼦⽬录之外)

```
umount /data/usb
```



# 3. parted

parted是功能全面的磁盘操作工具, 包括以下功能:

* 列出现有Disk: 

  ```
  p(arted) print
  ```

* 选择某个disk

  ```
  (parted) select /dev/sda
  ```

* 建立Label -> 创建分区 -> 格式化

  ```
  (parted) mklable mydate
  (parted) mkpart  #会提示起始扇区
  (parted) quit    #之后会利用mkfs进行格式化
  ```

* (optional)Resize分区

  ```
  (parted) resizepart
  ```

* 删除sda1分区: 

  ```
  parted /dev/sda rm 1
  ```



# 4. 创建LVM

> LVM是弹性磁盘使用机制, 由**PV**(物理扇区,比如/dev/vda1)->**VG**(扇区组)->**LV**->**LVM**一步步组成
>
> * VG被划分成不同大小的LV, 这些LV就可以组成LVM.
> * LVM所使用的物理分区,不可在LV被删除前进行删除格式化等操作

#### 4.1 由物理扇区创建PV

```
首先检查是否已经有现成的pv
#pvscan
其次将选定的物理扇区转换成成一个个单独的pv
#pvcreate /dev/sda{2,3,4}
```

#### 4.2 VG的操作

显示当前vg的状态: `vgdisplay`

1. ##### 建立新的VG: 该命令将sda2, sda3两个PV组合成一个VG,且把PE(存储模块单位)的大小设置为4M

   ```
   #vgcrate -s 4M vgName /dev/sda{2,3}
   ```

2. ##### 将上一步新建的pv合并到原有的vg中

   ```
   #vgextend vgName /dev/sda4
   该命令将sda4添加到vgName这个VG里
   ```


#### 4.3 LV的操作

在建立完pv之后, 可以对lv进行操作. 显示当前lv的状态: `lvdisplay`

1. ##### 建立新的lv

   ```
   #lvcreate -L 2G -n lvName vgName
   将vg中的2格式化为一个LV
   ```

之后就可以对LV进行格式化：`mkfs.xfs /dev/vgName/lvName`,此处需要注明lv的绝对路径

2. ##### 调整现有的LV大小

```
给LV增加1G容量
#lvresize -L +1G /dev/vgName/lvName, 这个路径可以使用lvdisplay查询到
xfs只能增加容量,不能减少LV的容量;但ext4可以缩减.

将lv的容量增加到5.72GB. 这个容量应该是pv size, 可以有pvdisplay查询到
```

##### 4.4 调整目录大小

在调整完lv size后, 使用lvm格式的挂载点就可以进行扩容.

* 调整ext4格式的挂载点 : 

  ```
  resize2fs mountPoint
  ```

* 调整xfs格式的 : 

  ```
  xfs_growfs mountPoint
  ```

> 对于将现有lvm挂载点扩容, 大致步骤为:
>
> 1. 先查看可用pv size, 如不够, 则利用磁盘空闲新建pv: 利用fdisk或gdisk新建分区, 指定大小后, 需要运行"t", 并指定Hex code为8e. 最后执行partprobe.
> 2. 将新建的分区比如/dev/sd8加入该挂载点所属的pv: vgextend vgName /dev/sd8, 这样就增加了pv size
> 3. 调整lv size: lvresize -L 新的大小 lvmPath
> 4. 将该挂载点 进行容量调整: 根据gpt或mbr, 执行对应的命令

# 5. Soft Raid

##### 3.3.1 创建soft raid

首先要有几个容量相同的分区(xfs或ext4)

```
#mdadm --create /dev/md0 --level=10 --raid-devices=4 /dev/sda[2-5]1
用sdb~sde四个分区建立了一个raid10系统dev/md0
#mkfs.xfs /dev/md0
在raid系统上格式化
#vi /etc/fstab
/dev/md0  /mnt/raid10  xfs  defaults  0  0
```



##### 3.3.2 检查现有raid系统

```
cat /proc/mdstat
或
mdadm --detail /dev/md0
```

