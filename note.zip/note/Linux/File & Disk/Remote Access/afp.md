```jsx
cd /usr/src/

wget <http://prdownloads.sourceforge.net/netatalk/netatalk-3.1.12.tar.gz>

mv netatalk-3.1.11.tar.gz netatalk-3.1.12.tar.gz

tar -zxvf netatalk-3.1.12.tar.gz

cd netatalk-3.1.12

apt-get install build-essential libdb-dev libgcrypt20-dev checkinstall

./configure --with-init-style=systemd --sysconfdir=/etc --with-init-dir=/etc/systemd/system --with-lockfile=/var/run/netatalk

// ...should return results ...
make

checkinstall
---Should I create a default set of package docs? [y]: n
---Please write a description for the package.
End your description with an empty line or EOF.
>> netatalk
>>

---Enter a number to change any of them or press ENTER to continue: 13
Enter the replaced packages: 
>> netatalk

---Enter a number to change any of them or press ENTER to continue: Enter
---Do you want me to list them? [n]:N
---Should I exclude them from the package? (Saying yes is a good idea) [y]:y

vi /etc/afp.conf
[storage]
  path = /...path.../
  valid users = @netatalk

addgroup netatalk
adduser afp
usermod -a -G netatalk afp

systemctl daemon-reload
systemctl enable netatalk
systemctl start netatalk
```