# 1.user

### 1.1 基本操作

#### * 查询user信息

```
查询账户信息
#id accountName

查询在线用户
#w
```

查询最后登陆记录

```
#lastlog
或
$last [可选的用户名] | less

查询失败的登录记录
#lastb | less
```



#### * Add user

​	-m: 建立用户的同时,建立新用户的home文件夹, 否则该用户登录后会出现无home的错误信息.

​	-s shell     : 默认的loginshell, 如果设置成: `-s /sbin/nologin, 指的是不可login的用户

​    -d dir       : 设置用户的login目录

​	-G group : 将新用户加入到group

```
# useradd -m newUser
# useradd newUser -G groupName
# useradd -s /sbin/nologin ftptest
```

该过程执行了以下步骤:

1.在 /etc/passwd ⾥⾯创建⼀⾏与帐号相关的数据，包括创建 UID/GID/
主⽂件夹等；
2.在 /etc/shadow ⾥⾯将此帐号的密码相关参数填⼊，但是尚未有密
码；
3.在 /etc/group ⾥⾯加⼊⼀个与帐号名称⼀模⼀样的群组名称；
4.在 /home 下⾯创建⼀个与帐号同名的⽬录作为使⽤者主⽂件夹，且
权限为 700

> 对于在shell里新建的用户, 会无法使用bash.此时需要运行`sudo chsh -s /bin/bash userName`

#### * Add user to group

```
usermod -a -G group1,group2 username
gpasswd -a user groupname
```

#### * 将用户从group中移除

```
gpasswd -d user groupname
```

#### * 新建group

```
groupadd groupname
```

设置group的home

```
#chgrp group homeDir
```



#### * 切换user

```
完整切换user: su -l targetUser
```



#### * Lock/unlock user

```
passwd -l userName: 锁定用户以至于无法用密码登录
passwd -u userName: 解锁
也可以使用:
#usermod -s /bin/nologim userName: 禁止用户使用shell
#sudo usermod –s /bin/false userName: 同上
```

#### * Del user

```
userdel -r account, 一并删除用户文件夹
```

#### * 强制要求修改密码

```
#chage -E 0 agetest
#chage -l agetest | head -n 3

-M number: 天数, 设置密码的有效天数
```



### 1.2 user id

每个用户都有一个uid/gid:

```
root: uid -> 0
system account: uid < 1000
```

### 1.3 password

用户密码保存在/etc/shadow文件内. 可以由/usr/bin/passwd这个二进制文件来读取.

### 1.4 group

###### 1.4.1 查询所属组

```
#groups
```

###### 1.4.2 设置新的所属组

在/etc/group中的第四段, 可以添加用户名, 以使得该用户成为该组成员

```
root:x:0:alex
#alex就是root组成员
```

###### 1.4.3 有效组: 即新建文件时的默认组

```
#groups
显示的第一个组即为有效组
```

在多个所属组之间切换有效组: 

```
newgrp newEffectiveGroup
```

### 1.5 sudo

###### 1.5.1 设置单个用户成为sudoer

sudo是让用户可以执行root才能执行的命令, 具备该资格需要在`/etc/sudoers`里有相应的设置

```
增加用户到sudoers里
visudo
#添加
newuser ALL=（ALL） ALL

或者
adduser userName sudo
```

切换用户: `su - userName`

###### 1.5.2 设置wheel群组,以便批量授予sudo

```
visudo
#添加以下行
%groupName ALL=（ALL） ALL
#然后将用户添加到该组,即成为sudoer
或者%wheel ALL=（ALL） NOPASSWD: ALL
在该群组里的sudoer无需密码即可sudo
```

> 上述的第二个ALL代表可以以root身份执行一切操作. 如果禁止某些操作,可以将第二个ALL改为 :
>
> `ALL=（root） !/usr/bin/passwd, /usr/bin/passwd [A-Za-z]*, !/usr/bin/passwd root`

###### 1.5.3 sudo别名(Alias): 免sudo

为了避免多次重复输入sudo,可以使用创建一个sudoer alias, 并设置初始命令.在此别名内的用户都具备临时root权限(别名以及别名cmd都需要大写):

* 此类用户成为sudo的方法: 

  **`sudo su -`** , 然后输入自己的密码, 之后即可直接执行root命令,无需sudo

```
#visudo
User_Alias TEMPROOT=alex,ben
Cmnd_Alias TEMPCMD=/bin/su -,!/usr/bin/passw, !/usr/bin/passwd root
TEMPROOT ALL=(root) TEMPCMD
```



# 2.ACL

针对单独的个体设置权限,比如将某个目录的读取权限单独设置给某个用户,但又避免该用户所属的组员可以访问该目录.

### 2.1 获取ACL设置: **getfacl**

```
#getfacl file或者dir
其中 user:alex:r-x 显示的就是针对alex设置的特定的权限
```

### 2.2 设置ACL: **sefacl**

```
设置user权限: setfacl -m u:userName:rwx fileName或dir
设置组权限: setfacl -m g:group:rwx file或dir
取消acl: setfacl -b file或dir
```

例如: 

```
setfacl -R -m "g:samba:rwx" /srv/samba/samfolder, 将权限赋予组
setfacl -m u:thisuser:rx test1, 将权限赋予用户
setfacl -R -m "u:nobody:rwx" /srv/samba/public/, 将权限赋予人
```



### 2.3 案例

dir的权限为750, root:root. 通过setfacl将某用户加入该目录并设置u:rx权限以便得以访问该目录; 但同处于改组的其他成员并不具备访问该奴鲁权限.