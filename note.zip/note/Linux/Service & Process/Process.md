## 1. 查询proc: **ps**

### 1.1 查询当前bash下的proc

```
#ps -elf
  	-e:显示所有proc11
		-f:完整输出
		-l:仅列出当前bash的信息, 如果不是root用户,则没有systemd级别的proc
		-A:显示所有的proc(并非仅当前bash下的)
F S UID          PID    PPID  C PRI  NI ADDR SZ WCHAN  STIME TTY          TIME CMD
4 S root           1       0  0  80   0 - 42337 ep_pol Apr04 ?        00:00:44 /sbin/init
1 S root           2       0  0  80   0 -     0 kthrea Apr04 ?        00:00:00 [kthreadd]
*F -> Flags; 4 指的是root; 1 表⽰此⼦程序仅进⾏复制（fork）⽽没有实际执⾏（exec）
*S -> Status; Sleep/Running/D(不可唤醒的睡眠)/sTop/Zombie
*C -> CPU
*PRI/NI：Priority/Nice
Priority_value = Nice_value + 20
```



### 1.2 查询系统级proc

```
#ps aux
		a: 列出全部proc
		x: 显示完整信息
USER       PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         1  0.0  0.8 194028  8568 ?        Ss   Mar31   7:38 /usr/lib/systemd/systemd -
root         2  0.0  0.0      0     0 ?        S    Mar31   0:00 [kthreadd]
*VSZ: 使用的虚拟内存
*RSS: 该proc占用的固定内存
```

## 2. 依据资源使用排序proc: **top**

#### 2.1 参数

```
#top -d 秒数
手动设置top刷新间隔
```



#### 2.2 top在运行时可以直接输入以下命令:

```
? ：显⽰在 top 当中可以输⼊的按键指令；
P ：按CPU排序(默认)
M ：按Memory排序
N ：按照PID排序
T ：由该 Process 使⽤的 CPU 时间累积 （TIME+） 排序。
k ：给予某个 PID ⼀个signal
r ：调整PID的nice值
```

e.x:

```
#top
top - 00:53:28 up 23 days, 15:19,  1 user,  load average: 0.00, 0.00, 0.00
Tasks: 123 total,   1 running, 122 sleeping,   0 stopped,   0 zombie
%Cpu(s):  0.0 us,  0.0 sy,  0.0 ni,100.0 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :    976.9 total,     93.3 free,    260.1 used,    623.5 buff/cache
MiB Swap:   2048.0 total,   1940.5 free,    107.5 used.    539.9 avail Mem
*load average: 系统在1, 5, 15分钟时的平均负载, 若>1, 说明负载过高

#top -d 2 -p pidNumber > rec.txt
将某pid的占用资源情况记录到文件里
```

#### 2.3 使用

可以针对某个占用cpu过高的proc, 调高其nice值以便降低cpu占用率



## 3. 查询proc家族结构图: **pstree**

```
-A ：各程序树之间的连接以 ASCII 字符来连接
-p ：并同时列出每个 process 的 PID
-u ：并同时列出每个 process 的所属帐号名称
#pstree -Ap
```

## 4. 操作proc: **kill, killall**

#### 4.1 以pid来终止proc

```
kill -1 pid: 重启proc
kill -9    : 强制立即终止
kill -15   : 正常终止
kill -19   : pause, 相当于ctrl z
```

#### 4.2 以service的名字来终止

可以同时终止众多与该service相关联的proc

```
#killall -i service Name
	       -i: 有终止提示
```

## 5. 调整proc的优先级: **nice**, **renice**, top

#### 5.1 预先调整

```
#nice -n -10 procName
nice的调整范围:
	root: -20 ~ 19
	user: 0 ~ 19,即普通用户只能调大, 即降低proc的优先级
```

#### 5.2 调整执行中的proc的nice

```
renice -n Newnice_val -p [pid]
```

## 6. 查询文件/文件夹被哪个proc使用&查询proc使用到哪些文件

### 6.1 查询文件或dev被哪些proc使用: **fuser**

```
#fuser -muv fileName/devName
  root      11921 Frce. (root)nginx
                     www-data  11922 Frce. (www-data)nginx
                     www-data  11923 Frce. (www-data)nginx
```

### 6.2 查询proc使用了哪些文件: **lsof**



```

```

