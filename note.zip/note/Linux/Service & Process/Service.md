# 1. Systemctl

> 系统的核心服务包括:
>
> acpid:电源管理
>
> atd: 预约命令
>
> haldaemon: 硬件检测
>
> xinetd: 即super daemon
>
> 其他: network. sshd, crond, iptables, postfix, rsyslog

### 1.1 设置系统服务

##### systemctl  [action option]  serviceName

```
#systemctl status : 显示server状态
Loaded: loaded (/usr/lib/systemd/system/sshd.service; enabled; vendor preset: enabled)
                                                                             =>enabled,代表开机启动
   Active: active (running) since Wed 2021-03-31 01:23:48 CST; 1 months 3 days ago
   =>代表正在执行
```

* 设置开机启动

```
#systemctl enabled serviceName
```

* 查看自启动状态

```
#systemctl is-enabled serName
```

* 注销service

```
systemctl mask servceName
(需要先stop之)
```

### 1.2 查询依存的服务

```
#systemctl list-dependencies serviceName
```

### 1.3  查询/修改服务的启动设置

系统提供的默认配置位置为: /usr/lib/systemd/system/, 此目录中不同类型的deamon有不同的扩展名

* 查询系统开机启动的服务

  ```
  #systemctl list-unit-files | grep xxx
  ```

  

##### 1.3.1 daemon的类型

1. service: 系统服务, 例如 v2ray.service
2. target: 是一些service和socket的组合, 如  rescue.target
3. mount: 挂载服务, 例如 nfs-mountd.service

##### 1.3.2 查询相关type的daemon

```
#systemctl list-units --type=service --all
#systemctl list-units --type=target --all
```

### 1.4 封禁/启用service: mask/unmask

对service的禁用有不同的等级, systemctl stop service的service可以用start重新启用; 更高级的封禁可以用systemctl mask serviceName, 此时只能用systemctl unmask来解禁, start service将不起作用.

```
查询service的启用状态
#systemctl list-unit-files | grep -i serviceName
```

#### 1.5 查询已启动的网络服务

```
#netstat  -tunlp
```



# 2. 修改/新建service

## 2.1 从系统原有的service中选择, 复制为新的服务

系统默认位置/usr/lib/systemd/system/内的配置文件不要修改 , 但是可以作为参考模板.

* 1.在以下目录下, 新建以该服务命名的文件夹, 例如 `/etc/systemd/system/abc.service.d/` 

  将原配置文件从/usr/lib/systemd/system/ 拷贝到本文件夹, 然后进行修改

  ```
  一般的service配置文件包含2-3个部分, 依次为
  #服务概要:
  [Unit]
  Description=OpenSSH 2 server daemon , 此处对新的service进行命名
  #运行内容:
  [Service]
  Type=notify
  EnvironmentFile=/etc/sysconfig/sshd
  ExecStart=/usr/sbin/sshd -f /etc/ssh/sshd2_config -D $OPTIONS , 此处添加的-f confFile是根据查询man serviceName得到的结果
  ```

  

* 2.在该目录内新建abc.conf文件

* 3.在/etc/systemd/system/vsftpd.service.wants/下放置该service所依存的其他服务的slink, 以便启动相关依存服务

* 4.在/etc/systemd/system/vsftpd.service.requires/下放置该service启动之前就需要运行的其他服务的slink, 以便提前启动pre-requested service

## 2.2 建立全新的service

1. 建立bash文件, 并且chmod a+x bash文件

2. 在`/etc/systemd/system`里, 编辑abc.service文件

   ```
   [Unit]
   Description=serviceName
   
   [Service]
   Type=simple
   ExecStart=/bin/bash -c "echo /bash文件路径"
   
   [Install]
   WantedBy=multi-user.target
   ```

3. 启动service

   ```
   #systemctl daemon-reload
   #systemctl start serviceName
   然后查看其状态
   也可以systemctl enable service以便自启动, 但对于非常驻内存的service就不必自启动, 尤其对于iptable之类的只要运行一次就可以, 此类的也不必设置为service.
   ```



### 1.4 主要的系统service

1. atd
2. auditd
3. crond: 配置文件就是/etc/crontab
4. firewalld: 可以取代旧的iptables服务
5. NetworkManager
6. rc-local
7. rsyslog: 可以将logs记录到/var/log/messages