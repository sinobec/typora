## Ubuntu

### 1. Install

```
apt install rkhunter -y
选择local only
system mail选择localhost
```

### 2. Conf

```
# vim /etc/rkhunter.conf
UPDATE_MIRRORS=1
MIRRORS_MODE=0
WEB_CMD=""
[可选]MAIL-ON-WARNING=yourmailAddress
新建文件
# vim /etc/default/rkhunter.conf
CRON_DAILY_RUN="true"
CRON_DB_UPDATE="true"
APT_AUTOGEN="true"
```

### 3. Post-install

```
rkhunter -C ,验证
rkhunter --update, 更新
rkhunter --propupd , 更新数据库
rkhunter --check --rwo, 开始检查
```



