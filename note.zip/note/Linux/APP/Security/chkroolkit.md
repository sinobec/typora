> chkrootkit可以检测哪些进程掌握了root权限

## 1. Install

配置文件: /etc/chkrootkit.conf 

##### 1.1 CentOS

1. ```
   dnf --enablerepo=powertools install glibc-static
   ```

2. ```
   cd /usr/local/src
   wget ftp://ftp.pangeia.com.br/pub/seg/pac/chkrootkit.tar.gz
   tar xvf chkrootkit.tar.gz
   cd chkrootkit-*
   make sense
   ```

3. ```
   ./chkrootkit
   ```

4. ```
   crontab -e
   0 3 * * * /usr/local/src/chkrootkit-*/chkrootkit -q 2>&1 | mail -s "ChkRootKit Output from `hostname`" yourEmailAddress
   =>每日扫描
   ```

   ##### 1.2 Ubuntu
   
   ```
   apt install chkrootkit -y
   vi /etc/chkrootkit.conf 
   将RUN_DAILY改为true
   ```

## 2. 分析

当某文件有 INFECTED的标志时, 代表此文件有可能被感染(/tmp下有任何有x权限的文件或文件夹都会出现INFECTED)