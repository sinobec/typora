> PortSentry可以防御恶意扫描, 将其导向null, 并记录扫描者ip

## 1. 安装

安装后路径为: /usr/local/psionic/portsentry

```
apt-get install portsentry
```

## 2. 配置

配置文件在: /etc/portsentry/portsentry.conf

###### 2.1 配置 vim  /etc/portsentry/portsentry.conf, 其权限要改为600

```
#163行
#Generic
#KILL_ROUTE="/sbin/route add $TARGET$ 333.444.555.666"
#Generic Linux
KILL_ROUTE="/sbin/route add -host $TARGET$ gw 333.444.555.666
#164行此处配置路由定向
```

* 终止攻击:

```
209行
KILL_ROUTE="/usr/local/sbin/iptables -I INPUT -s $TARGET$ -j DROP"
```

* 记录攻击信息, 其信息会在tcp wrapper的机制下记录到etc/hosts.deny里:

```
#236
KILL_HOSTS_DENY="ALL:$TARGET$ # Portsentry blocked"
```

######  2.2 配置 vi  /etc/portsentry/portsentry.ignore, 添加白名单, 需要加上127.0.0.1和本地网络

> 在`/var/log/meeesges`,或者`/var/log/syslog`以及secure里会看到portsentry拦截的扫描log
>
> May 31 10:17:17 127.0.0.1 portsentry[16554]: adminalert: Advanced Stealth scan detection mode activated. Ignored TCP port: 514
> May 31 10:17:17 127.0.0.1 portsentry[16554]: adminalert: Advanced Stealth scan detection mode activated. Ignored TCP port: 113
> May 31 10:17:17 127.0.0.1 portsentry[16554]: adminalert: Advanced Stealth scan detection mode activated. Ignored TCP port: 139

此时可以在/var/log/syslog见到port entry的log.

