![ezgif.com-gif-maker](/Users/penggao/pCloud Drive/Work_Space/note/ezgif.com-gif-maker.jpg)





> System Requirement:
>
> - **Memory**: *>=8GB*
> - **vcpus**: *>=4*

* ### Install DNS bind Server

  * vim /etc/sysconfig/network-scripts/网卡

  ```
  添加DNS1=本机IP
  ```

  * vim /etc/hosts

  ```
   本机IP   mail.acis.cc mail
  ```

  * Install bind DNS server

  ```
  yum install bind bind-utils -y
  systemctl start named
  systemctl enable named
  vim /etc/named.conf
  ```

  * vim /etc/named.conf (先备份)

  ```
  在Option下
  listen-on port 53 { 127.0.0.1; 192.168.50.121; }; #此处添加server的内网ip, 仅监听本机
  allow-query     { localhost;192.168.50.121; }; 
  在该部分的末尾添加
  forwarders { 8.8.8.8; };
  
  在末尾的includes之前添加
  zone "acis.cc" {
      type master;
      file "acis.cc.zone";
  };
  ```

   * 验证DNS

     ```
     dig -t MX acis.cc
     显示
     ANSWER SECTION为有效MX记录
     ```

## 1. Dependencies & NTP(network tome protocol)

```
systemctl stop postfix
dnf remove postfix -y
```



```
dnf -y update
```

```
sudo dnf -y install epel-release dnf-utils
sudo dnf config-manager --enable PowerTools
sudo dnf -y install bash-completion vim curl wget unzip openssh-clients telnet net-tools sysstat perl-core libaio nmap-ncat libstdc++.so.6 bind-utils tar
```

NTP

```
dnf -y install chrony
timedatectl set-timezone America/Toronto
sudo systemctl enable --now chronyd
sudo chronyc sources
#
timedatectl
```

Setup language and unicode

```
sudo localectl set-locale LANG=en_US.UTF-8
sudo localectl set-locale LANGUAGE=en_US
echo "export LC_ALL=en_US.UTF-8" >>~/.bashrc
logout
```

## 2. Install Zimbra

```
wget https://files.zimbra.com/downloads/8.8.15_GA/zcs-8.8.15_GA_3953.RHEL8_64.20200629025823.tgz
tar xvf zcs-8.8.15_GA_3953.RHEL8_64.20200629025823.tgz
```

#### * Install Zimbra

```
cd zcs-8.8.15_GA_3953.RHEL8_64.20200629025823
./install.sh
#不安装
DNSCACHE
zimbra-imapd (BETA - for evaluation only)
#Change domain name:
acis.cc
```

* Verify

  ```
  sudo su - zimbra -c "zmcontrol status"
  ```

  

## 3. Post Installation

##### 3.1 安装后会提示设置Admin 密码

##### 3.2 Firewall

```
firewall-cmd --add-service={http,https,smtp,smtps,imap,imaps,pop3,pop3s} --permanent
firewall-cmd --add-port 7071/tcp --permanent
firewall-cmd --add-port 8443/tcp --permanent
firewall-cmd --add-port 587/tcp --permanent
firewall-cmd --add-port 143/tcp --permanent
firewall-cmd --reload
```

##### 3.3 Start zimbra

```
su - zimbra
zmcontrol status
#某些服务可能未启动
zmcontrol stop
zmcontrol start
```

##### 3.4 Management

```
#重置密码
zmprov sp <admin email address> <new password>
#显示Admin
zmprov gaaa
```

##### 3.5 Lets  encrypt

```
sudo su - zimbra -c "zmproxyctl stop"
sudo su - zimbra -c "zmmailboxdctl stop"
```

install let's encrypt

```
mkdir /opt/zimbra/ssl/letsencrypt
cat $CERTPATH/chain.pem | sudo tee /opt/zimbra/ssl/letsencrypt/zimbra_chain.pem
```

Build a proper Intermediate CA plus Root CA, merge it after the chain.pem.

```
sudo tee -a /opt/zimbra/ssl/letsencrypt/zimbra_chain.pem<<EOF
-----BEGIN CERTIFICATE-----
MIIDSjCCAjKgAwIBAgIQRK+wgNajJ7qJMDmGLvhAazANBgkqhkiG9w0BAQUFADA/
MSQwIgYDVQQKExtEaWdpdGFsIFNpZ25hdHVyZSBUcnVzdCBDby4xFzAVBgNVBAMT
DkRTVCBSb290IENBIFgzMB4XDTAwMDkzMDIxMTIxOVoXDTIxMDkzMDE0MDExNVow
PzEkMCIGA1UEChMbRGlnaXRhbCBTaWduYXR1cmUgVHJ1c3QgQ28uMRcwFQYDVQQD
Ew5EU1QgUm9vdCBDQSBYMzCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEB
AN+v6ZdQCINXtMxiZfaQguzH0yxrMMpb7NnDfcdAwRgUi+DoM3ZJKuM/IUmTrE4O
rz5Iy2Xu/NMhD2XSKtkyj4zl93ewEnu1lcCJo6m67XMuegwGMoOifooUMM0RoOEq
OLl5CjH9UL2AZd+3UWODyOKIYepLYYHsUmu5ouJLGiifSKOeDNoJjj4XLh7dIN9b
xiqKqy69cK3FCxolkHRyxXtqqzTWMIn/5WgTe1QLyNau7Fqckh49ZLOMxt+/yUFw
7BZy1SbsOFU5Q9D8/RhcQPGX69Wam40dutolucbY38EVAjqr2m7xPi71XAicPNaD
aeQQmxkqtilX4+U9m5/wAl0CAwEAAaNCMEAwDwYDVR0TAQH/BAUwAwEB/zAOBgNV
HQ8BAf8EBAMCAQYwHQYDVR0OBBYEFMSnsaR7LHH62+FLkHX/xBVghYkQMA0GCSqG
SIb3DQEBBQUAA4IBAQCjGiybFwBcqR7uKGY3Or+Dxz9LwwmglSBd49lZRNI+DT69
ikugdB/OEIKcdBodfpga3csTS7MgROSR6cz8faXbauX+5v3gTt23ADq1cEmv8uXr
AvHRAosZy5Q6XkjEGB5YGV8eAlrwDPGxrancWYaLbumR9YbK+rlmM6pZW87ipxZz
R8srzJmwN0jP41ZL9c8PDHIyh8bwRLtTcm1D9SZImlJnt1ir/md2cXjbDaJWFBM5
JDGFoqgCWjBH4d1QB7wCCZAA62RjYJsWvIjJEubSfZGL+T0yjWW06XyxV3bqxbYo
Ob8VZRzI9neWagqNdwvYkQsEjgfbKbYK7p2CNTUQ
-----END CERTIFICATE-----
EOF
```

```
chown -R zimbra:zimbra /opt/zimbra/ssl/letsencrypt/
#Verify
sudo su - zimbra -c '/opt/zimbra/bin/zmcertmgr verifycrt comm /opt/zimbra/ssl/letsencrypt/privkey.pem /opt/zimbra/ssl/letsencrypt/cert.pem /opt/zimbra/ssl/letsencrypt/zimbra_chain.pem'
sudo cp -a /opt/zimbra/ssl/zimbra /opt/zimbra/ssl/zimbra.$(date "+%Y%.m%.d-%H.%M")
sudo cp /opt/zimbra/ssl/letsencrypt/privkey.pem /opt/zimbra/ssl/zimbra/commercial/commercial.key
sudo chown zimbra:zimbra /opt/zimbra/ssl/zimbra/commercial/commercial.key
sudo su - zimbra -c '/opt/zimbra/bin/zmcertmgr deploycrt comm /opt/zimbra/ssl/letsencrypt/cert.pem /opt/zimbra/ssl/letsencrypt/zimbra_chain.pem'
sudo su - zimbra -c "zmcontrol restart"
```

##### 3.6 Mailjet

1. 验证domain

   ```
   #DNS里添加:
   spf: 添加txt, @ -> value
   dkim: 
   ```

2. 设置smtp

   ```
   在outlook里:
   imap: mail.acis.cc/auto/用户名密码为email的
   smtp: 服务器地址为mailjet的/auto/用户名密码为脉络金额与
   ```

   
