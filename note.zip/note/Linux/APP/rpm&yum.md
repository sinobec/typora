> rpm是Redhat的软件安装管理, 李彤rpm可以查询到安装的软件的依赖库/配置文件等信息

```
#rpm -option
```

-qa ：列出所有的已经安装的软件

-qi ：列出该软件的详细信息，包含开发商、版本与说明等

```
#rpm -option appName
```

**-q** :  显示此app是否已安装

-ql ：列出该软件所有的⽂件与⽬录所在完整⽂件名 （list）；

-qc ：列出该软件的所有配置⽂件 （找出在 /etc/ 下⾯的⽂件名⽽已）

-qd ：列出该软件的所有说明⽂档 （找出与 man 有关的⽂件⽽已）

-qR ：列出与该软件有关的相依软件所含的⽂件 （Required 的意思）

-qf ：由后⾯接的⽂件名称，找出该⽂件属于哪⼀个已安装的软件；

##### 1.1  常用

查询rpm安装包的源安装包: `rpm -qa | grep packageName`

删除安装包: `rpm -e sourcePackageName` , 上一步查询到的源安装包名

# 2.yum

#### 2.1 搜索app相关信息

```
#yum option appName
```

search ：搜寻某个软件名称或者是描述 （description） 的重要关键字；

list ：列出⽬前 yum 所管理的所有的软件名称与版本，有点类似 rpm -qa；

info ：同上，不过有点类似 rpm -qai 的执⾏结果；

provides：利用⽂件名去搜app, 类似 rpm -qf 的功能！

#### 2.2 安装升级删除

```
yum update xxx
yum remove xxx
```



#### 2.3 repo

设置文件在: /etc/yum.repos.d/CentOS-Base.repo

在/etc/yum.repos.d/的其他第三方repo是否启用, 取决于该/repo里的设置项 `enabled = 0/1`

对于暂时没有启用的设置项, 即enable=0, 可以在安全app时指定搜索它的repo: `yum --enablerepo=epel install xxx`

















