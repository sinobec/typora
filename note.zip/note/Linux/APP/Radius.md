```
$ docker run --name radius -d --restart unless-stopped freeradius/freeradius-server
```





















