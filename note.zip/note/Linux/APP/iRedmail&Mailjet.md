## 1. Install

> log: /var/log/mail.log

* Ubuntu 20
  1. 在域名管理处建立mx record: @ -> mail.domain.com
  2. 新建hostname

```
sudo hostnamectl set-hostname mail.domain.com
# 一定要用hostname -f验证新的hostname
编辑/etc/hosts: 添加hostname
```

​	03. 下载安装 

```
wget https://github.com/iredmail/iRedMail/archive/refs/tags/1.4.0.tar.gz
tar xvf 1.4...
cd iRedMail...
chmod +x iRedMail.sh && sudo bash iRedMail.sh
# 选择Nginx和MariaDB
```

4. reboot & 测试URL

   > portentry会屏蔽143端口
   >
   > iptables的rule会屏蔽一些端口

5. 安装Let's

```
sudo apt install certbot -y
sudo certbot certonly --webroot --agree-tos --email your-email@example.com -d mail.your-domain.com -w /var/www/html/
```

5. 在Postfix and Dovecot中安装tls

   ```
   # vi /etc/postfix/main.cf
   将:
   smtpd_tls_key_file = /etc/ssl/private/iRedMail.key
   smtpd_tls_cert_file = /etc/ssl/certs/iRedMail.crt
   smtpd_tls_CAfile = /etc/ssl/certs/iRedMail.crt
   改为:
   smtpd_tls_key_file = /etc/letsencrypt/live/mail.your-domain.com/privkey.pem
   smtpd_tls_cert_file = /etc/letsencrypt/live/mail.your-domain.com/cert.pem
   smtpd_tls_CAfile = /etc/letsencrypt/live/mail.your-domain.com/chain.pem
   
   # sudo vi /etc/dovecot/dovecot.conf
   将:
   ssl_cert = </etc/ssl/certs/iRedMail.crt
   ssl_key = </etc/ssl/private/iRedMail.key
   改为:
   ssl_cert = </etc/letsencrypt/live/mail.your-domain.com/fullchain.pem
   ssl_key = </etc/letsencrypt/live/mail.your-domain.com/privkey.pem
   ```

   ```
   sudo systemctl reload postfix
   sudo systemctl reload dovecot
   ```

   ##### 在nginx里设置tls

   ```
   # sudo vi /etc/nginx/templates/ssl.tmpl
   替换ssl_certificate /etc/ssl/certs/iRedMail.crt;
   ssl_certificate_key /etc/ssl/private/iRedMail.key;
   为:
   ssl_certificate /etc/letsencrypt/live/mail.your-domain.com/fullchain.pem;
   ssl_certificate_key /etc/letsencrypt/live/mail.your-domain.com/privkey.pem;
   # systemctl reload nginx
   ```

   

6. 修改sudo vi /etc/fail2ban/jail.local以便对本地登录不限制

   ```
   ignoreip = 添加serverIP
   ```

* 最后, 测试port 25

  ```
  # telnet gmail-smtp-in.l.google.com 25
  如果显示: ... - gsmtp代表未被封锁
  ```

  

## 2. Post-install

##### 2.1 SPF Record

在DNS manage:

新建txt -> @ : v=spf1 mx ~all

##### 2.2 DKIM Record

`sudo amavisd-new showkeys`

DKIM value就是p之后的内容, 无换行无引号.

在DNS里新建txt -> dkim._domainkey: v=DKIM1; p=DKIMvalue

运行sudo amavisd-new testkeys验证

##### 2.3 DMARC Record

新建账户dmarc@your-domain.com

在DNS里新建txt -> _dmarc: v=DMARC1; p=none; pct=100; rua=mailto:dmarc@your-domain.com

##### 2.4 Mailjet.com

pengbuddy@hotmail.com

> 在发送邮件的时候, 为了避免邮件进入到对方的spam, 需要有可信的发件ip.

* 在mailjet. account setting ->
  1. 在smtp设置里的smtp server, 比如是in-v3.mailjet.com:587
  2. Add sender domain -> Sending Domain Authenticatio

* 在iRedmail上

  ```
  # sudo apt install postfix libsasl2-modules
  安装时选择Internet Site
  # sudo vi /etc/postfix/main.cf
  relayhost = in-v3.mailjet.com , 填写mailjet账户里的smtp server地址
  并添加:
  # outbound relay configurations
  smtp_sasl_auth_enable = yes
  smtp_sasl_password_maps = hash:/etc/postfix/sasl_passwd
  smtp_sasl_security_options = noanonymous
  smtp_tls_security_level = may
  header_size_limit = 4096000
  ```

  ```
  # sudo vi /etc/postfix/sasl_passwd
  添加:
  in-v3.mailjet.com:587  api-key:secret-key
  in-v3.mailjet.com:587 eabaa7b78898896ff77e15386fa9d1de:d0f891b40ca3509a574d4d02d3913c68
  api-key指的是smtp的credential的username, secret-key指的是password
  ```
  
  建立hash db: `sudo postmap /etc/postfix/sasl_passwd`
  
  ```
  sudo systemctl restart postfix
  sudo chown root:root /etc/postfix/sasl_passwd /etc/postfix/sasl_passwd.db
  sudo chmod 0600 /etc/postfix/sasl_passwd /etc/postfix/sasl_passwd.db
  ```

##### 2.5 smtp设置

1. 将邮件app的smtp设置为mailjet的smtp地址, 
2. 开启验证(和IMAP的验证不同), 验证的用户名密码是mailjet的api-key:secret-key

### 3. Infomation

在 `/root/iRedMail-x.y.z/iRedMail.tip ` 里

