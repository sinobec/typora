### 1. Client Config

* Mail server: mail.acis.cc

* POP3 service: port 110 over STARTTLS (recommended), or port 995 with SSL.
* IMAP service: port 143 over STARTTLS (recommended), or port 993 with SSL.
* SMTP service: port 587 over STARTTLS.
  If you need to support old mail clients with SMTP over SSL (port 465),

### 2. Server Config

* Admin of domain acis.cc:

  \* Account: [postmaster@acis.cc](mailto:postmaster@acis.cc)
  \* Password: 3891289Gp

  You can login to iRedAdmin with this account, login name is full email address.

First mail user:
  \* Username: [postmaster@acis.cc](mailto:postmaster@acis.cc)
  \* Password: 3891289Gp
  \* SMTP/IMAP auth type: login
  \* Connection security: STARTTLS or SSL/TLS 

* Enabled services:  rsyslog postfix mysql nginx php7.3-fpm dovecot clamav-daemon amavis clamav-freshclam fail2ban cron nftables

* SSL cert keys (size: 4096):
    \- /etc/ssl/certs/iRedMail.crt
    \- /etc/ssl/private/iRedMail.key

* Mail Storage:
    \- Mailboxes: /var/vmail/vmail1
    \- Mailbox indexes:
    \- Global sieve filters: /var/vmail/sieve
    \- Backup scripts and backup copies: /var/vmail/backup

* MySQL:
    \* Root user: root, Password: "3891289Gp" (without quotes)
    \* Bind account (read-only):
      \- Username: vmail, Password: KmW5myDijaesUwO3O9sZOzS1pY6bXqff
    \* Vmail admin account (read-write):
  \- Username: vmailadmin, 

  -Password: h6PsRRbvu35na8uLfiw2SeYevm9CEDdI
    \* Config file: /etc/mysql/my.cnf
    \* RC script: /etc/init.d/mysql

* Virtual Users:
    \- /root/iRedMail-1.4.0/samples/iredmail/iredmail.mysql
    \- /root/iRedMail-1.4.0/runtime/*.sql

* Backup MySQL database:
    \* Script: /var/vmail/backup/backup_mysql.sh
    \* See also:
      \# crontab -l -u root

* **Postfix:**
    \* Configuration files:
      \- /etc/postfix
      \- /etc/postfix/aliases
      **\- /etc/postfix/main.cf**
      \- /etc/postfix/master.cf

* SQL/LDAP lookup config files:
      \- /etc/postfix/mysql

* Dovecot:
    \* Configuration files:
      \- /etc/dovecot/dovecot.conf
      \- /etc/dovecot/dovecot-ldap.conf (For OpenLDAP backend)
      \- /etc/dovecot/dovecot-mysql.conf (For MySQL backend)
      \- /etc/dovecot/dovecot-pgsql.conf (For PostgreSQL backend)
      \- /etc/dovecot/dovecot-used-quota.conf (For real-time quota usage)
      \- /etc/dovecot/dovecot-share-folder.conf (For IMAP sharing folder)
    \* Syslog config file:
      \- /etc/rsyslog.d/1-iredmail-dovecot.conf (present if rsyslog >= 8.x)
    \* RC script: /etc/init.d/dovecot
    \* Log files:
      \- /var/log/dovecot/dovecot.log
      \- /var/log/dovecot/sieve.log
      \- /var/log/dovecot/lmtp.log
      \- /var/log/dovecot/lda.log (present if rsyslog >= 8.x)
      \- /var/log/dovecot/imap.log (present if rsyslog >= 8.x)
      \- /var/log/dovecot/pop3.log (present if rsyslog >= 8.x)
      \- /var/log/dovecot/sieve.log (present if rsyslog >= 8.x)
    \* See also:
      \- /var/vmail/sieve/dovecot.sieve
      \- Logrotate config file: /etc/logrotate.d/dovecot

* Nginx:
    \* Configuration files:
      \- /etc/nginx/nginx.conf
      \- /etc/nginx/sites-available/00-default.conf
      \- /etc/nginx/sites-available/00-default-ssl.conf
    \* Directories:
      \- /etc/nginx
      \- /var/www/html
    \* See also:
      \- /var/www/html/index.html

* php-fpm:
    \* Configuration files: /etc/php/7.3/fpm/pool.d/[www.conf](http://www.conf/)

PHP:
  \* PHP config file for Nginx:

* Disabled functions:

  posix_uname,eval,pcntl_wexitstatus,posix_getpwuid,xmlrpc_entity_decode,pcntl_wifstopped,pcntl_wifexited,pcntl_wifsignaled,phpAds_XmlRpc,pcntl_strerror,ftp_exec,pcntl_wtermsig,mysql_pconnect,proc_nice,pcntl_sigtimedwait,posix_kill,pcntl_sigprocmask,fput,phpinfo,system,phpAds_remoteInfo,ftp_login,inject_code,posix_mkfifo,highlight_file,escapeshellcmd,show_source,pcntl_wifcontinued,fp,pcntl_alarm,pcntl_wait,ini_alter,posix_setpgid,parse_ini_file,ftp_raw,pcntl_waitpid,pcntl_getpriority,ftp_connect,pcntl_signal_dispatch,pcntl_wstopsig,ini_restore,ftp_put,passthru,proc_terminate,posix_setsid,pcntl_signal,pcntl_setpriority,phpAds_xmlrpcEncode,pcntl_exec,ftp_nb_fput,ftp_get,phpAds_xmlrpcDecode,pcntl_sigwaitinfo,shell_exec,pcntl_get_last_error,ftp_rawlist,pcntl_fork,posix_setuid

* ClamAV:
    \* Configuration files:
      \- /etc/clamav/clamd.conf
      \- /etc/clamav/freshclam.conf
      \- /etc/logrotate.d/clamav
    \* RC scripts:
        \+ /etc/init.d/clamav-daemon
        \+ /etc/init.d/clamav-freshclam

* Amavisd-new:
    \* Configuration files:
      \- /etc/amavis/conf.d/50-user
      \- /etc/postfix/master.cf
      \- /etc/postfix/main.cf
    \* RC script:
      \- /etc/init.d/amavis
    \* SQL Database:
      \- Database name: amavisd
      \- Database user: amavisd
      \- Database password: CuwAjH5HnlZjsk9KVQ1sm3xt4Vw1xcX4

* DNS record for DKIM support:

; key#1 2048 bits, i=dkim, d=acis.cc, /var/lib/dkim/acis.cc.pem
dkim._domainkey.acis.cc.   3600 TXT (
v=DKIM1; p=MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAooYeSJV1Nwoow2LfeXw8MDbpSZtDewGDDoGcEpvZtk8FHca07k1/bfQcegyi5bnzqa+USjAreEVempCYwiIrX3Isvj+DOkEwggFo+fu9HHEE9hUIFutbtVmXo+lEu7x2cm/3yyFIFgXpMKT/jgJZyXc1IUxBEJT6JO7504j122eWoSDVI+tTyEhd4wVxADxQ1OMhBdcMkI9oOSMrBA93YPif5e1iwvGaG5J92+QyR71WR8KWvLbVevinljt9d4TcdsPexXfWFtPx8BVwvO5BVTHikfAJrMhlWpMEASylIsg97A8g8I+MHry4+lUIIaw8vkIvBmwPlsxSNuX8wy1UwIDAQAB
SpamAssassin:
  \* Configuration files and rules:
    \- /etc/mail/spamassassin
    \- /etc/mail/spamassassin/local.cf

iRedAPD - Postfix Policy Server:
  \* Version: 5.0
  \* Listen address: 127.0.0.1, port: 7777
  \* SQL database account:
    \- Database name: iredapd
    \- Username: iredapd
    \- Password: C1sHUZxxKu5Ubss1nYA2wabD6iVCX2Tb
  \* Configuration file:
    \- /opt/iredapd/settings.py
  \* Related files:
    \- /opt/iRedAPD-5.0
    \- /opt/iredapd (symbol link to /opt/iRedAPD-5.0

iRedAdmin - official web-based admin panel:
  \* Version: 1.3
  \* Root directory: /opt/www/iRedAdmin-1.3
  \* Config file: /opt/www/iRedAdmin-1.3/settings.py
  \* Web access:
    \- URL: https://debian.acis.cc/iredadmin/
    \- Username: [postmaster@acis.cc](mailto:postmaster@acis.cc)
    \- Password: 3891289Gp
  \* SQL database:
    \- Database name: iredadmin
    \- Username: iredadmin
    \- Password: 0Y10E9HyEaAi4sd6PqhuR63z1437N5be

Roundcube webmail: /opt/www/roundcubemail-1.4.11
  \* Config file: /opt/www/roundcubemail-1.4.11/config
  \* Web access:
    \- URL: http://debian.acis.cc/mail/ (will be redirected to https:// site)
    \- URL: https://debian.acis.cc/mail/ (secure connection)
    \- Username: [postmaster@acis.cc](mailto:postmaster@acis.cc)
    \- Password: 3891289Gp
  \* SQL database account:
    \- Database name: roundcubemail
    \- Username: roundcube
    \- Password: AiwaPIkbFWlh13Q1wFqGA1Td0UxyD87r
  \* Cron job:
    \- Command: "crontab -l -u root"

netdata (monitor):
  \- Config files:
    \- All config files: /opt/netdata/etc/netdata
    \- Main config file: /opt/netdata/etc/netdata/netdata.conf
    \- Modified modular config files:
      \- /opt/netdata/etc/netdata/go.d
      \- /opt/netdata/etc/netdata/python.d
  \- HTTP auth file (if you need a new account to access netdata, please
   update this file with command like 'htpasswd' or edit manually):
    \- /etc/nginx/netdata.users
  \- Log directory: /opt/netdata/var/log/netdata
  \- SQL:
    \- Username: netdata
    \- Password: u5k39DEEfMsSec7KvY7whqwlKglRxtnr
    \- NOTE: No database required by netdata.