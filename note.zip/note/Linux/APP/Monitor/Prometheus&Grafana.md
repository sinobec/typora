

> Prometheus和Grafana结合使用, 可以有效地监控多个Server/App/Docker

## 1. Prometheus

分为Server和Node两个部分, Server负责收集来自于各个Node的信息,并加以整理.

#### 1.1 Server的安装

配置文件: /etc/prometheus/prometheus.yml

```bash
sudo groupadd --system prometheus
sudo useradd -s /sbin/nologin --system -g prometheus prometheus
sudo mkdir /var/lib/prometheus
for i in rules rules.d files_sd; do sudo mkdir -p /etc/prometheus/${i}; done
sudo apt-get -y install wget
mkdir -p /tmp/prometheus && cd /tmp/prometheus
curl -s https://api.github.com/repos/prometheus/prometheus/releases/latest \
  | grep browser_download_url \
  | grep linux-amd64 \
  | cut -d '"' -f 4 \
  | wget -qi -
tar xvf prometheus*.tar.gz
cd prometheus*/

sudo mv prometheus promtool /usr/local/bin/
sudo mv prometheus.yml  /etc/prometheus/prometheus.yml
sudo mv consoles/ console_libraries/ /etc/prometheus/

cd ~/
rm -rf /tmp/prometheus
```

* 默认配置文件: vim /etc/prometheus/prometheus.yml

* 建立service

  ```bash
  sudo tee /etc/systemd/system/prometheus.service<<EOF
  
  [Unit]
  Description=Prometheus
  Documentation=https://prometheus.io/docs/introduction/overview/
  Wants=network-online.target
  After=network-online.target
  
  [Service]
  Type=simple
  User=prometheus
  Group=prometheus
  ExecReload=/bin/kill -HUP $MAINPID
  ExecStart=/usr/local/bin/prometheus \
    --config.file=/etc/prometheus/prometheus.yml \
    --storage.tsdb.path=/var/lib/prometheus \
    --web.console.templates=/etc/prometheus/consoles \
    --web.console.libraries=/etc/prometheus/console_libraries \
    --web.listen-address=0.0.0.0:9090 \
    --web.external-url=
  
  SyslogIdentifier=prometheus
  Restart=always
  
  [Install]
  WantedBy=multi-user.target
  EOF
  ```

  ```bash
  for i in rules rules.d files_sd; do sudo chown -R prometheus:prometheus /etc/prometheus/${i}; done
  for i in rules rules.d files_sd; do sudo chmod -R 775 /etc/prometheus/${i}; done
  sudo chown -R prometheus:prometheus /var/lib/prometheus/
  sudo systemctl daemon-reload
  sudo systemctl start prometheus
  sudo systemctl enable prometheus
  ```

  * URL:  *http://[ip_hostname]:9090*

#### 1.2 Install node_exporter

配置文件:  /etc/prometheus/prometheus.yml

###### 1.2.1 首先建立本机node

在server上: 

```bash
curl -s https://api.github.com/repos/prometheus/node_exporter/releases/latest \
| grep browser_download_url \
| grep linux-amd64 \
| cut -d '"' -f 4 \
| wget -qi -

tar -xvf node_exporter*.tar.gz
cd  node_exporter*/
sudo cp node_exporter /usr/local/bin
```

建立一个Node

```bash
sudo tee /etc/systemd/system/node_exporter.service <<EOF
[Unit]
Description=Node Exporter
Wants=network-online.target
After=network-online.target

[Service]
User=prometheus
ExecStart=/usr/local/bin/node_exporter

[Install]
WantedBy=default.target
EOF

sudo systemctl daemon-reload
sudo systemctl start node_exporter
sudo systemctl enable node_exporter
```

在server上配置node

```bash
# vi /etc/prometheus/prometheus.yml
添加
- job_name: 'node_exporter'
    static_configs:
      - targets: ['localhost:9100']
        labels:
          service: '1'
      
sudo systemctl restart prometheus
```

### 1.2.2 监控Linux machine(在client上建立node)

```bash
sudo groupadd --system prometheus
sudo useradd -s /sbin/nologin --system -g prometheus prometheus
curl -s https://api.github.com/repos/prometheus/node_exporter/releases/latest | grep browser_download_url | grep linux-amd64 |  cut -d '"' -f 4 | wget -qi -
tar xvf node_exporter-*linux-amd64.tar.gz
cd node_exporter*/
sudo mv node_exporter /usr/local/bin/
```

######  建立node service

* Ubuntu

```bash
sudo vim /etc/systemd/system/node_exporter.service
#添加
[Unit]
Description=Prometheus
Documentation=https://github.com/prometheus/node_exporter
Wants=network-online.target
After=network-online.target

[Service]
Type=simple
User=prometheus
Group=prometheus
ExecReload=/bin/kill -HUP $MAINPID
ExecStart=/usr/local/bin/node_exporter \
    --collector.cpu \
    --collector.diskstats \
    --collector.filesystem \
    --collector.loadavg \
    --collector.meminfo \
    --collector.filefd \
    --collector.netdev \
    --collector.stat \
    --collector.netstat \
    --collector.systemd \
    --collector.uname \
    --collector.vmstat \
    --collector.time \
    --collector.mdadm \
    --collector.zfs \
    --collector.tcpstat \
    --collector.bonding \
    --collector.hwmon \
    --collector.arp \
    --web.listen-address=:9100 \
    --web.telemetry-path="/metrics"
[Install]
WantedBy=default.target
```

* CentOS

```
[Unit]
Description=Prometheus Node Exporter
Wants=network-online.target
After=network-online.target

[Service]
User=prometheus
Group=prometheus
Type=simple
ExecStart=/usr/local/bin/node_exporter

[Install]
WantedBy=multi-user.target
```

* 修改firewall

```
iptables -I INPUT -p tcp --dport 9100 -j ACCEPT 

sudo ufw allow 9100
sudo ufw reload
或
sudo firewall-cmd --add-port=9100/tcp --permanent
sudo firewall-cmd --reload

sudo systemctl restart node_exporter
sudo systemctl enable node_exporter
```

* 在Server上添加Node

  ```
  # vi /etc/prometheus/prometheus.yml
  # Linux Servers
    - job_name: apache-linux-server1
      static_configs:
        - targets: ['10.1.10.20:9100']
          labels:
            alias: server1
  
    - job_name: apache-linux-server2
      static_configs:
        - targets: ['10.1.10.21:9100']
          labels:
            alias: server2
  ```

  ```
  sudo systemctl restart prometheus
  ```

#### 1.2.3 监控Apache



#### 1.2.4 监控MySQL



#### 1.2.5 监控Docker

#### 1.2.6 监控Windows

Windows监控利用的是WMI Exporter(普通windows host的dashboard与server有差别). 需要开启9182端口.

## 2 Alert

#### 2.1 Rule

`vim /usr/local/bin/prometheus/prometheus_rules.yml`

```
groups:
  - name: custom_rules
    rules:
      - record: node_memory_MemFree_percent
        expr: 100 - (100 * node_memory_MemFree_bytes / node_memory_MemTotal_bytes)

      - record: node_filesystem_free_percent
        expr: 100 * node_filesystem_free_bytes{mountpoint="/"} / node_filesystem_size_bytes{mountpoint="/"}

  - name: alert_rules
    rules:
      - alert: InstanceDown
        expr: up == 0
        for: 1m
        labels:
          severity: critical
        annotations:
          summary: "Instance [{{ $labels.instance }}] down"
          description: "[{{ $labels.instance }}] of job [{{ $labels.job }}] has been down for more than 1 minute."
      - alert: DiskSpaceFree10Percent
        expr: node_filesystem_free_percent <= 10
        labels:
          severity: warning
        annotations:
          summary: "Instance [{{ $labels.instance }}] has 10% or less Free disk space"
          description: "[{{ $labels.instance }}] has only {{ $value }}% or less free."
```

校验: `./promtool check rules  prometheus_rules.yml`

#### 2.2 Install AlertManager



```
sudo su
cd /opt/
wget https://github.com/prometheus/alertmanager/releases/download/v0.23.0/alertmanager-0.23.0.linux-amd64.tar.gz
tar -xvzf alertmanager-0.23....
cd aler...
cp -r . /usr/local/bin/alertmanager
```

* **vi  /etc/systemd/system/alertmanager.service**

  ```
  [Unit]
  Description=Prometheus Alert Manager Service
  After=network.target
  [Service]
  Type=simple
  ExecStart=/usr/local/bin/alertmanager/alertmanager \
          --config.file=/usr/local/bin/alertmanager/alertmanager.yml 
  [Install]
  WantedBy=multi-user.target
  ```

  `sudo service alertmanager start`
  `sudo service alertmanager status`

* **vi /usr/local/bin/alertmanager/alertmanager.yml**

  ```
  global:
    resolve_timeout: 5m
  
  route:
    group_by: ['alertname']
    group_wait: 10s
    group_interval: 10s
    repeat_interval: 10s
    receiver: 'email'
  receivers:
  - name: 'email'
    email_configs:
    - to: 'receiver_mail_id@gmail.com'
      from: 'mail_id@gmail.com'
      smarthost: smtp.gmail.com:587
      auth_username: 'mail_id@gmail.com'
      auth_identity: 'mail_id@gmail.com'
      auth_password: 'password'
  inhibit_rules:
    - source_match:
        severity: 'critical'
      target_match:
        severity: 'warning'
      equal: ['alertname', 'dev', 'instance']
  ```

  `/usr/local/bin/alertmanager/amtool check-config /usr/local/bin/alertmanager/alertmanager.yml`

#### 2.3 添加AlertManager到Prometheus server

`vim /etc/prometheus/prometheus.yml`

```
global:
  scrape_interval:     15s # Set the scrape interval to every 15 seconds. Default is every 1 minute.
  evaluation_interval: 15s # Evaluate rules every 15 seconds. The default is every 1 minute.
  # scrape_timeout is set to the global default (10s).

# 以下新增
rule_files:
  - "prometheus_rules.yml"

alerting:
  alertmanagers:
  - static_configs:
    - targets:
      - localhost:9093

```

## 3. Silences

当某个job的ALert触发后, 比如down, 在修复之前的这段时间不再需要接受来自该job的其他任何警报, 可以设置silences, 规则是:

```
alertname="啊"等于job="jobName"
```

 

## 2.Grafana

> 推荐的dashboard:
>
> https://grafana.com/grafana/dashboards/8919
>
> https://grafana.com/dashboards/159
> https://grafana.com/dashboards/3662
> https://github.com/percona/grafana-dashboards
> https://github.com/rfrail3/grafana-dashboards

user id: bj9871@gmail.com

#### 2.1 添加Source



#### 2.2 设置Alert

