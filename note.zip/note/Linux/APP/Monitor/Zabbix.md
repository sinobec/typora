

# ==== Server ====

## **Step 1: Set SELinux to permissive mode**

Configure SELinux to work in permissive mode:

```
setenforce 0 && sed -i 's/^SELINUX=.*/SELINUX=permissive/g' /etc/selinux/config
```

This way, SELinux will not block anything, but the audit log will fill up with what would have been denied. And later in [step 12](https://bestmonitoringtools.com/how-to-install-zabbix-server-on-centos-or-rhel/#Step_12_Enable_and_configure_SELinux_on_Zabbix), we can create an SELinux policy based on that.

## **Step 2: Install Zabbix server, frontend, and agent**

Setup Zabbix 5 RPM package on CentOS 8, clean repo and install Zabbix server, frontend, and agent. Choose 5.0 LTS release (stable, 5-year support) or 5.4 standard release (more features, 6-month support, more bugs).



```
#Zabbix 5.0 LTS version (supported until May, 2025)
rpm -Uvh https://repo.zabbix.com/zabbix/5.0/rhel/8/x86_64/zabbix-release-5.0-1.el8.noarch.rpm
dnf clean all
dnf -y install zabbix-server-mysql zabbix-web-mysql zabbix-apache-conf zabbix-agent

                                                     OR 

#Zabbix 5.4 standard version (supported until November, 2021)
rpm -Uvh https://repo.zabbix.com/zabbix/5.4/rhel/8/x86_64/zabbix-release-5.4-1.el8.noarch.rpm
dnf clean all
dnf -y install zabbix-server-mysql zabbix-web-mysql zabbix-apache-conf zabbix-agent
```

You can find more information about [Zabbix’s life cycle and release policies](https://www.zabbix.com/life_cycle_and_release_policy) on the official website.

## **Step 3: Install and configure database**

In this installation, I will use password rootDBpass as root password and zabbixDBpass as Zabbix password for DB. Consider changing your password for security reasons.

### **a. Install MariaDB**

```
dnf -y install mariadb-server && systemctl start mariadb && systemctl enable mariadb
```

### **b. Reset root password for database**

Secure MySQL by changing the default password for MySQL root:

```
# mysql_secure_installation
```

### **c. Create database**

Create a database for Zabbix directly from the terminal using these two commands:



```
mysql -u root -p'rootDBpass' -e "create database zabbix character set utf8 collate utf8_bin;"
mysql -uroot -p'rootDBpass' -e "grant all privileges on zabbix.* to zabbix@localhost identified by 'zabbixDBpass';"
```

### **d. Import initial schema and data**

Temporary disable strict mode ([ZBX-16465](https://support.zabbix.com/browse/ZBX-16465)) to avoid MySQL error “`ERROR 1118 (42000) at line 1284: Row size too large (> 8126)`” :

```
mysql -uroot -p'rootDBpass' zabbix -e "set global innodb_strict_mode='OFF';"
```

Import database shema for Zabbix server (could last up to 5 minutes):

```
zcat /usr/share/doc/zabbix-server-mysql*/create.sql.gz | mysql -uzabbix -p'zabbixDBpass' zabbix
```

Enable strict mode:

```
mysql -uroot -p'rootDBpass' zabbix -e "set global innodb_strict_mode='ON';"
```

### **e. Enter database password in Zabbix configuration file**

Open `zabbix_server.conf` file with command: “`vi /etc/zabbix/zabbix_server.conf`” and add database password in this format anywhere in file:

```
DBPassword=zabbixDBpass
```

Save and exit file (**ctrl**+**x**, followed by **y** and **enter**).

## **Step 4: Start Zabbix server and agent processes**

```
systemctl restart zabbix-server zabbix-agent
systemctl enable zabbix-server zabbix-agent
```

## **Step 5: Configure firewall**

```
firewall-cmd --add-service={http,https} --permanent
firewall-cmd --add-port={10051/tcp,10050/tcp} --permanent
firewall-cmd --reload
```

## **Step 6: Configure Zabbix frontend**

### **a. Configure PHP for Zabbix frontend**

Edit file “`/etc/php-fpm.d/zabbix.conf`” with command:

```
vi /etc/php-fpm.d/zabbix.conf
```

Uncomment line in zabbix.conf that starts with “`; php_value date.timezone Europe/Riga`” by removing symbol “`;`” and set the [right timezone](https://www.php.net/manual/en/timezones.php) for your country, for example:



```
php_value date.timezone US/Eastern
```

Save and exit file (**ctrl**+**x**, followed by **y** and **enter**)

### **b. Restart Apache web server and make it start at system boot**

```
systemctl restart httpd php-fpm
systemctl enable httpd php-fpm
```

### **c. Configure web frontend**

Connect to your newly installed Zabbix frontend using URL “*http://server_ip_or_dns_name/zabbix*” to initiate the Zabbix installation wizard.

In my case, that URL would be “*http://192.168.1.161/zabbix*” because I have installed Zabbix on the server with IP address 192.168.1.161 (you can find the IP address of your server by typing “`ip a`” command in the terminal).

Basically, in this wizard **you only need to enter a password for Zabbix DB user** and for everything else just click “*Next step*“. In this guide, I have used a zabbixDBpass as a database password, but if you set something else, be sure to enter the correct password when prompted by the wizard.

> 执行安装时输入db password.
>
> 登陆时http://server_ip_or_dns_name/zabbix的默认id: Admin ; ps: zabbix

## **Step 8: Create MySQL partitions on History and Events tables**

Zabbix’s housekeeping process is responsible for deleting old trend and history data. Removing old data from the database using SQL delete query can negatively impact database performance. Many of us have received that annoying alarm “`Zabbix housekeeper processes more than 75% busy`” because of that.

That problem can be easily solved with the database partitioning. Partitioning creates tables for each hour or day and drops them when they are not needed anymore. SQL DROP is way more efficient than the DELETE statement.

​				**Step 8.1: Download SQL script for partitioning**

Download and uncompress SQL script “`zbx_db_partitiong.sql`” on your database server:



```
wget http://bestmonitoringtools.com/dl/zbx_db_partitiong.tar.gz
tar -zxvf zbx_db_partitiong.tar.gz
```

Script “`zbx_db_partitiong.sql`” is configured to keep 7 days of history data and 365 days of trend data – move to step 2 if those settings are acceptable to you.

However, if you want to change days for trends or history then open file “***zbx_db_partitiong.sql***“, change settings as shown in the picture below, and save the file.

[![Picture showing how to change days for trends and history in MySQL "create procedure" step](https://bestmonitoringtools.com/wp-content/uploads/2019/10/best_monitoring_tools_change_history_and_trends_in_partitoning_script.png)](https://bestmonitoringtools.com/wp-content/uploads/2019/10/best_monitoring_tools_change_history_and_trends_in_partitoning_script.png)Picture showing how to change days for trends and history in MySQL “create procedure” step

**Step 8.2: Create partitioning procedures with the SQL script**

Syntax for running script is “***mysql -u ‘<db_username>’ -p'<db_password>’ <zb_database_name> < zbx_db_partitiong.sql***“.

Now, run it with your Zabbix database name, username , and password to create partitioning procedures:



```
mysql -u 'zabbix' -p'zabbixDBpass' zabbix < zbx_db_partitiong.sql
```

Script will create MySQL partitioning procedures very quickly on the new Zabbix installation, but on large databases, this may last for hours.

**Step 8.3: \**Run \*\*partitioning procedures\*\* automatically\****

We’ve created partitioning procedures, but they don’t do anything until we run them!

This step is the most important because the partitions must be deleted and created regularly (every day) using partitioning procedures!

Don’t worry, you don’t have to do that manually. We can use two tools for such tasks: **MySQL event scheduler** or **Crontab** – choose whatever you prefer.

Be careful when configuring MySQL event scheduler or Crontab. Zabbix will stop collecting data if you misconfigure them! You will notice that by the empty graphs and the error “[Z3005] query failed: [1526] Table has no partition for value ..” in the Zabbix log file.

By default, the MySQL event scheduler is disabled. You need to enable it by setting “*event_scheduler=ON*” in the MySQL configuration file just after the “[mysqld]” line.

`vi /etc/my.cnf.d/mariadb-server.cnf`

```
[mysqld] 
event_scheduler = ON
```

Don’t know where that file is located? If you used my [tutorial for installing and optimizing Zabbix](https://bestmonitoringtools.com/how-to-install-zabbix-server-on-ubuntu/#Step_7_Optimizing_MySQL_MariaDB_database_optional), then the MySQL configuration file (*10_my_tweaks.cnf*) should be located at “*/etc/mysql/mariadb.conf.d/*” or “*/etc/my.cnf.d/*“, otherwise try to search for it with the command:



```
sudo grep --include=*.cnf -irl / -e "\[mysqld\]"
```

Once you have made the changes restart your MySQL server for the setting to take effect!

```
sudo systemctl restart mysql
```

Nice! MySQL event scheduler should be enabled, let’s check that with the command:

```
root@dbserver:~ $ mysql -u 'zabbix' -p'zabbixDBpass' zabbix -e "SHOW VARIABLES LIKE 'event_scheduler';"
+-----------------+-------+
| Variable_name | Value |
+-----------------+-------+
| event_scheduler | ON |
+-----------------+-------+
```

Now we can create an event that will run procedure “*partition_maintenance_all*” every 12 hours.

```
mysql -u 'zabbix' -p'zabbixDBpass' zabbix -e "CREATE EVENT zbx_partitioning ON SCHEDULE EVERY 12 HOUR DO CALL partition_maintenance_all('zabbix');"
```

After 12 hours, check to see if the event has been executed successfully using the command below.

```
mysql -u 'zabbix' -p'zabbixDBpass' zabbix -e "SELECT * FROM INFORMATION_SCHEMA.events\G"
EVENT_CATALOG: def
                   ...
CREATED: 2020-10-24 11:01:07
LAST_ALTERED: 2020-10-24 11:01:07
LAST_EXECUTED: 2020-10-24 11:43:07
                   ...
```

**Step 8.4: Configure Housekeeping on Zabbix frontend**

Configure housekeeping on Zabbix frontend as shown in the picture below.

在Dashboard->admin-general 右侧下拉菜单选择Housekeeping

=> History 仅选择override - 7d

=>Trends 仅选择Override - 365d



## **Step 9: Optimizing Zabbix Server (optional)**

Don’t bother with this optimization if you are monitoring a small number of devices, but if you are planning to monitor a large number of devices then continue with this step.

Open “`zabbix_server.conf`” file with command: “`nano /etc/zabbix/zabbix_server.conf`” and add this configuration anywhere in file:



```
StartPollers=100
StartPollersUnreachable=50
StartPingers=50
StartTrappers=10
StartDiscoverers=15
StartPreprocessors=15
StartHTTPPollers=5
StartAlerters=5
StartTimers=2
StartEscalators=2
CacheSize=128M
HistoryCacheSize=64M
HistoryIndexCacheSize=32M
TrendCacheSize=32M
ValueCacheSize=256M
```

Save and exit file (**ctrl**+**x**, followed by **y** and **enter**).

This is not a perfect configuration, keep in mind that you can optimize it even more. Let’s say if you don’t use ICMP checks then set the “`StartPingers`” parameter to 1 or if you don’t use active agents then set “`StartTrappers`” to 1 and so on. You can find out more about the parameters supported in a Zabbix server configuration file in the [official documentation](https://www.zabbix.com/documentation/4.0/manual/appendix/config/zabbix_proxy).

If you try to start the Zabbix server you will receive an error “`[Z3001] connection to database 'Zabbix' failed: [1040] Too many connections`” in the log “`/var/log/zabbix/zabbix_server.log`” because we are using more Zabbix server processes than MySQL can handle. We need to increase the maximum permitted number of simultaneous client connections and optimize MySQL – so move to the next step.



## **Step 10: Optimizing MySQL/MariaDB database (optional)**

### **a. Create custom MySQL configuration file**

Create file “`10_my_tweaks.cnf"` with “`vi /etc/my.cnf.d/10_my_tweaks.cnf`” and paste this configuration:

```
[mysqld]
max_connections = 300
innodb_buffer_pool_size = 800M

innodb-log-file-size = 128M
innodb-log-buffer-size = 128M
innodb-file-per-table = 1
innodb_buffer_pool_instances = 8
innodb_old_blocks_time = 1000
innodb_stats_on_metadata = off
innodb-flush-method = O_DIRECT
innodb-log-files-in-group = 2
innodb-flush-log-at-trx-commit = 2

tmp-table-size = 96M
max-heap-table-size = 96M
open_files_limit = 65535
max_connect_errors = 1000000
connect_timeout = 60
wait_timeout = 28800
```

Save and exit the file (**ctrl**+**x**, followed by **y** and **enter**) and set the correct file permission:

```
chown mysql:mysql /etc/my.cnf.d/10_my_tweaks.cnf
chmod 644 /etc/my.cnf.d/10_my_tweaks.cnf
```

**Two things to remember!**

Configuration parameter [**max_connections**](https://dev.mysql.com/doc/refman/5.5/en/server-system-variables.html#sysvar_max_connections) must be larger than the total number of all Zabbix proxy processes plus 150. You can use the command below to automatically check the number of Zabbix processes and add 150 to that number:

```
egrep "^Start.+=[0-9]" /etc/zabbix/zabbix_server.conf | awk -F "=" '{s+=$2} END {print s+150}'
295
```

The second most important parameter is **[innodb_buffer_pool_size](https://dev.mysql.com/doc/refman/5.7/en/innodb-parameters.html#sysvar_innodb_buffer_pool_size)**, which determines how much memory can MySQL get for caching InnoDB tables and index data. You should set that parameter to 70% of system memory if only database is installed on server.



However, in this case, we are sharing a server with Zabbix and Apache processes so you should set **innodb_buffer_pool_size** to 40% of total system memory. That would be 800 MB because my CentOS server has 2 GB RAM.

I didn’t have any problems with memory, but if your Zabbix proxy crashes because of lack of memory, reduce “`innodb_buffer_pool_size`” and restart MySQL server.

Note that if you follow this configuration, you will receive “`Too many processes on the Zabbix server`” alarm in Zabbix frontend due to the new Zabbix configuration. It is safe to increase the trigger threshold or turn off that alarm (select “*Problems*” tab → left click on the alarm → select “*Configuration*” → remove the check from “*Enabled*” → hit the “*Update*” button)

### **b. Restart Zabbix Server and MySQL service**

Stop and start the services in the same order as below:

```
systemctl stop zabbix-server
systemctl stop mysql
systemctl start mysql
systemctl start zabbix-server
```

## **Step 11: How to manage Zabbix / MySQL / Apache service**

Sometimes you will need to check or restart Zabbix, MySQL or Apache service – use commands below to do that.

```
Zabbix Server
systemctl <status/restart/start/stop> zabbix-server

MySQL/MariaDB Server
systemctl <status/restart/start/stop> mysql

Apache Server
systemctl <status/restart/start/stop> httpd

PHP FastCGI Process Manager
systemctl <status/restart/start/stop> php-fpm

Zabbix Agent
systemctl <status/restart/start/stop> zabbix-agent
```



## **Step 12: Enable and configure SELinux on Zabbix**

While it is acceptable to disable SELinux in a lab environment, depending on the requirements of the local security IT team, you may need to enable and configure SELinux in your production environment.



At the beginning of this guide, we did not turn off SELinux completely but configure it to work in the permissive mode which means it will log all the security errors but will not block anything.

If you accidentally left it in enforcing mode then you will receive the “`Zabbix server is not running: the information displayed may not be current`” warning on the Zabbix frontend and “`cannot set resource limit: [13] Permission denied`” in the log file.

Don’t worry, this can be easily fixed, so without further delay, let’s configure SELinux for Zabbix!

### **a) SELinux: Allow http daemon to connect to Zabbix:**

Enable SELinux  boolean “`httpd_can_connect_zabbix`” that will allow http daemon to connect to Zabbix:

```
setsebool -P httpd_can_connect_zabbix 1
```

### **b) \**SELinux:\**** **Allow Zabbix to connect to all TCP ports:**

Enable SELinux  boolean “`zabbix_can_network`” that will allow Zabbix to connect to all TCP ports :



```
setsebool -P zabbix_can_network 1
```

### **c) Set SELinux to work in enforcing mode**

Turn on SELinux by setting it to work in enforcing mode:

```
setenforce 1 && sed -i 's/^SELINUX=.*/SELINUX=enforcing/g' /etc/selinux/config
```

And check SELinux status :

```
# sestatus
SELinux status: enabled
SELinuxfs mount: /sys/fs/selinux
SELinux root directory: /etc/selinux
Loaded policy name: targeted
Current mode: enforcing
Mode from config file: enforcing
Policy MLS status: enabled
Policy deny_unknown status: allowed
Memory protection checking: actual (secure)
Max kernel policy version: 31
```

### **d) Create additional SELINUX policy for Zabbix**

Just in case, we will create an additional SELinux policy for each error in the audit log (“`/var/log/audit/audit.log`“)

To do this, we will need the policycoreutils-python tool, so let’s install it:

```
dnf -y install policycoreutils-python-utils
```

Create a custom policy package:

```
grep "denied.*zabbix" /var/log/audit/audit.log | audit2allow -M zabbix_policy
```

Install custom SELinux policy package:

```
semodule -i zabbix_policy.pp
```

Well done! You have configured SELinux for Zabbix!

## **Step 13: Upgrade between minor Zabbix versions**



I wrote about upgrade procedures in my post about [Zabbix upgrade](https://bestmonitoringtools.com/upgrade-zabbix-to-the-latest-version/). Zabbix’s team releases new minor versions at least once a month. The main purpose of minor upgrades is to fix bugs (hotfix) and sometimes even bring new functionality. Therefore, try to do a minor upgrade of Zabbix at least once a month.

There is no need for backups when doing a minor upgrade, they are completely safe. With this command you can easily upgrade minor versions of 5.0.x (for example, from 5.0.1 to 5.0.5):

```
dnf upgrade 'zabbix-*'
```

And restart Zabbix server afterward:

```
systemctl restart zabbix-server
```

# ==== Client ====

Download : https://www.zabbix.com/download?zabbix=5.0&os_distribution=centos&os_version=7&db=mysql&ws=apache

> 由于zabbix agent2默认的zabbix用户无法执行docker命令, 所以需要将其加入到docker组
>
> usermod -a -G docker zabbix
>
> systemctl restart zabbix-agent2

## 1. CentOS 7

```
setenforce 0
# rpm -Uvh https://repo.zabbix.com/zabbix/5.0/rhel/7/x86_64/zabbix-release-5.0-1.el7.noarch.rpm
# yum clean all
# yum install zabbix-agent2
```

* Config: `vim /etc/zabbix/zabbix_agent2.conf`

```
Server=127.0.0.1,serverIP
ServerActive=serverIP
Hostname=client
systemctl restart zabbix-agent2
systemctl enable zabbix-agent2
firewall-cmd --add-service={http,https} --permanent
firewall-cmd --add-port={10051/tcp,10050/tcp} --permanent
firewall-cmd --reload
```

## 2.Ubuntu 20

```
# wget https://repo.zabbix.com/zabbix/5.0/ubuntu/pool/main/z/zabbix-release/zabbix-release_5.0-1+focal_all.deb
# dpkg -i zabbix-release_5.0-1+focal_all.deb
# apt update
****************
apt install zabbix-agent2
```

* config: `vim /etc/zabbix/zabbix_agent2.conf`

```
Server=127.0.0.1,zabbixServer
ServerActive=zabbixServer
Hostname=<Write the hostname of your CURRENT server here>
**************
systemctl start zabbix-agent2
systemctl enable zabbix-agent2
ufw allow 10050/tcp
iptables -I INPUT -p tcp --dport 10050 -j ACCEPT
iptables-save
apt-get install iptables-persistent
netfilter-persistent save
netfilter-persistent reload
```

