# 1.pipe

最初的命令需要由stdout的输出, 且之后的命令具备接收stdin

#### 1.1 提取同一行里的数据: **cut**

```
cut -d ':' -f 2,5
      分隔符  显示的列
#cat /etc/passwd | cut -d ':' -f1
#cut -d ':' -f1 /etc/passwd
```

#### 1.2 默认以字母为标准排序: **sort**

```
-f ：忽略⼤⼩写
-n ：使⽤“数字”进⾏排序
-r ：反向排序
-u ：就是 uniq ，相同的数据中，仅出现⼀⾏代表
sort -t ':' -k 3: 对分隔符分割后的某一列进行排序
```

#以空格为分隔符, 倒序显示第一列并去除重复项

```
last | cut -d ' ' -f 1 | sort -u
```

#### 1.3 计数统计行数: **wc**

```
wc -l: 统计总行数
```

# 2. grep / sed / awk

## 2.1 正则表达式Regex

正则表达式RE: 支持RE的命令行主要有`grep, sed, vi, awk`

```
grep -n -A3 -B2: 显示结果的上下文, 显示搜索结果上面3行以及下面2.
grep -i        : 不区分大小写.
grep [abc]     : 包含abc里的某个字符.
grep 'r..t'    : .代表任意"一个"字符,可以是空格或符号.
grep 'a*'      : *代表多个a字符. 例如".*"就代表多个任意字符.
grep '^.*thisStr'  : 以起始为条件来过滤, 即以"数量不定的任意字符"为起始, 直到thisStr为止的过滤条件. 一般用于截取掉行内的起始部分.
grep -v '^#' | grep -v '^$' : 反选, 显示不以#开头的且非空的行, 也可以使用grep ^[^#] 
grep 'str.*$'  : 代表从str开始直到末尾的全部字符, 一般用于截取掉行尾.例如 netstat -tnlp | grep node.*
grep '[^abc]'  : [ ]内的"^"代表反选, 即不包含abc内的任意一个字符. grep '^[^gf]oo'指的是不以g或f开头,且包含2个o.
grep 'x$'      ;  $代表结尾. 比如'^$'指的是空白行,即以空白为首也以空白为结束.
grep \标点      : 过滤条件里有标点. 比如grep "\'".

[a-z]           : 等于[[:lower:]], 例如^[^a-zA-Z]指的是不以字母为开头
```



## 2.2 grep

在grep的同时还可以保留原命令的标题栏, 使用: 

**`ps -elf| head -1; ps -elf | grep xxx`**

或者(在已知原标题一部分的前提下):

`ps -elf | egrep 'xxx|PID'`

```
-i ：忽略⼤⼩写
-v ：反选
-E: 可以使用正则表达式, 一般用于多条件的'或'搜索, 比如grep -E 'aaa|bbb|ccc', 满足其中一个条件即可.
grep '\<apple\>' : 精确匹配
```

###  egrep

1. 同时搜索多个条件之a'和'b

   ```
   #egrep -v '^$|^#' file: 搜索非空或非注释行
   #grep -E '^$|^#' file: 同上
   #egrep 'g(la|oo)d' file: 同时搜索glad或good
   ```

2. 同时搜索多个条件之 : a'以及'b

   ```
   #grep 'ssh' /var/log/secure | grep -i 'accepted'
   可以搜索成功登陆ssh的ip
   ```

   

## **2.4 sed: 重构输出内容**

https://www.grymoire.com/Unix/Sed.html#uh-15a

对cat等屏幕显示操作进行重构: 过滤, 新增, 剔除.包括对全部显示的行进行筛选过滤, 对单行显示的行内信息进行筛选过滤. 但sed不具备判断操作能力, 如需对输出结果进行判断, 可使用awk

> ###### 基本参数:
>
> -n : 静默;否则所有来自stdin的内容都会显示. 一般用在 p, 即选择行来打印
>
> -e : 执行简短的脚本, 比如 `sed -e ''$a newContent" thisFile`

### 	[基本操作1 - 以行为单位] **sed  'lineNum+option action'**

* ##### d: 删除行. 

  ```
  cat -n /etc/passswd | sed '2,11d' #在cat的显示里删除了第2-11行
  cat -n /etc/passswd | sed '2,$d'  #删除了第2行之后的所有行
  ```

  > sed 'n1, n2' : 对n1行和n2行之间进行操作. $代表最后一行

* ##### 增加内容

  1. i : 插入行(在之前): 

  ```
  cat -n file | sed '3i newContent'  #在第3行前插入新内容
  #cut -d ':' -f1 /etc/passwd | sort -uf |  sed '1i ===User List==='
  ```

  2. a : 新增行(在其后):

  ```
  cat -n file | sed '3a newContent'  #在第3行后插入新内容
  #新增多行:  
  cat -n file | sed '3a newline-one\
  ...
  newline-two'
  ```

* ##### c: 以指定的字符串取代:

  ```
  cat -n /etc/passwd | sed '2,$c xxx'  #从第2行开始的所有内容都被替换为xxx
  #cut -d ':' -f1,3 /etc/passwd | sort -uf |  sed '5,$c 0000'
  第五行之后的被0000取代, 并不是每一行都成为0000, 而是所有余下的行成为一行0000
  ```

* ###### sed -n p : 打印选择的行

  ```
  sed -n '2,$p'   #打印从第2行开始的所有行. 需要使用-n的静默模式, 否则所有的内容依然会输出.
  sed -n '3p' fileName: #仅显示第3行
  sed -m "${var}p" fineName: 变量行数
  cut -d ':' -f1,3 /etc/passwd | sort -uf |  sed -n '35,$p' 
  ```

### 	[ 基本操作2 - 行内数据操作 ]

* ##### **s/something//g** : 替换:

  ```
  sed 's/oldstr/newstr/g'   #将oldstr替换为newstr
  例如: 
  ifconfig ens3|grep '\<inet\>'|sed 's/^.*inet//g'|sed 's/netmask.*$//g' #选择出有inet的那行 |  将行首到inet之间的字符替换为空 | 将从netmask到末尾的字符替换为空
  ```

### [ 基本操作3 - 修改文件内容/显示 ]

该操作可以真正修改文件内容

```
在文件末添加新行: sed -i '$a xxx' file
删除某行-第四行: sed -e '4d' file
取代某行: sed -e '6c newContent' file
#可以同时执行多个动作: sed -e '4d' -e '6c xxx' file
```



## **2.5 awk : `自定义显示格式`**

**格式: ** 

```
awk -F '分隔符' 'condition {...action...}' fileName
```

##### 2.5.1 内置变量

```
NR: 目前处理的行号
NF: 此行有多少列
FS : 分隔符
#awk -F ':' '{print "The " NR " account is" "\: " "\"" $1 "\""}' /etc/passwd 
```

##### 6.5.2 设置显示条件: 利用逻辑判断符

```
awk -F ':' '$3<10 {print $1 "\t" $3}' /etc/passwd

#显示uid>999的账号
cut -d ':' -f1,3 /etc/passwd | awk -F ':' '$2>999 {print $1 "\t" $2}' | sort
此处的$2其实是源文件的第三列, 但是在cut过滤后就成为了awk处理的第2列
```

# 3. diff

* 格式: `diff -bBi 原始文件 被对比的文件`

```
-b: 忽略空白字符
-B: 忽略空白行
-i: 忽略大小写
```