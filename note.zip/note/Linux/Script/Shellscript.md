```
#!/bin/bash
。。。
exit
```



# 1. 变量 

####  1.1 常用命令

> PS1: 指的是命令行提示符之前的默认内容
>
> 命令行内优先级: ````或 $()内的语句优先执行, 例如: ls -ld $(locate crontab)`
>
> 上一个命令的执行结果: echo $? 返回0指的是执行正常

#### 1.2 设置变量: 

* 变量类型: 自定义变量(仅在当前bash下有效); 环境变量(在各个bash下均有效)

​	`var1=xxx`

​	**`var1=$(ls-al) `=>以命令作为变量内容**

​	`var2='Of $var1' `=> 值为Of $var1

​	`var2="Of $var1"` =>引用变量var1

> ​	利用键盘输入设置变量vlaue:**` read var`** 此时var的值由键盘输入来赋值

* 获取变量: `echo $var`
* 修改变量: `var1="$var1"newContent` => 将新内容添加到原变量的末尾
* 自定义变量输出为变量: `export var1` => 将变量输出为环境变量
* 取消变量: `unset var`
* 多个变量的连接: 用点连接 -> ${var1}.${var2}
* 设置固定范围变量: 1-100的数字 => num ={1..100}; a-z的字母=> letter={a..z}

#### 1.2 环境变量: 

###### 显示当前环境变量: `env`



#### 1.3 引用变量:

​	var=${var1}了2.wildcard字符: 不同于RE

\* :  任意字符, 数量不定

? :  任意"一个"字符

[ ] : 任意一个"在括号内”的字符（⾮任意字符） 

[ - ]: 在编码顺序内的所有字符”。例如 凡有数字[0-9], 小写 [a-z], 凡有字母 [a-zA_Z]

[^] : 任意一个不在括号里的字符

```
/etc/[^a-z]* : 以(非小写)字母开头的
/etc/*[0-9]* : 凡带有数字的
```

##### 1.4 bash默认自带变量

```
file.sh var1 var2 var3...
$@: 显示所有变量
$0:bash文件的名字
$#: 变量总数
```



# 2.判断: 

#### 2.1 if  elseif  then, 需要严格使用格式, 比如test[ ]两边的空格

```
if [ criteria1 ]; then
	... action1 ...
elif [ criteria2 ]; then
	... action2 ...
else
	... action3 ...
fi
```

#### 2.1 判断符号

和test命令判断符号相同

```
-o: 或者, 用 || 表示
-a: 以及, 用 && 表示
! : 非
#if [ "a"=="xxx" ] || [ "b"== "yyy" ];then
```



#### 2.2 case esac

```
case xxx in
	"matched1" 
	... action ...;;
	"matched2"
	... action ...;;
esca
```

例如

```
#!/bin/sh
#filename is : this.sh
option="${1}" 
case ${option} in 
   -f) FILE="${2}" 
      echo "File name is $FILE"
      ;; 
   -d) DIR="${2}" 
      echo "Dir name is $DIR"
      ;; 
   *)  
      echo "`basename ${0}`:usage: [-f file] | [-d directory]" 
      exit 1 # Command to come out of the program with status 1
      ;; 
esac 
#./this.sh -f aFile.html
此时$1的值是-f, $2的值是aFile.html
```



# 3.loop

```bash
loop condition
do
	,,, action ...
done
```



### 3.1 while condition/action: 当条件成立/执行动作时, 开始循环

```
while [ cretiria ]
```

例如:

```
while read ip
do ping -c1 $ip && echo "connected" || echo "failed"
done < <(sed 's/^.* //g' sourceFile)
```



```
 while read ip; do ping -c1 $ip; done < <(sed 's/^.* //g' sourceFile)
 ##### sourceFile ######
 ip1 8.8.8.8
 ip2 4.4.4.4 ...
```



### 3.2 until: 当条件成立时,终止循环

```
until [ cretiria ]
do
	... action ...
done
```

例如

```
until [ "${x}"=="y" ]
do 
	read -p "input: " x
done
echo "input is y"
```



### 3.3  for

##### 3.3.1 for in

```
for var in value1 value2 value3 ...
do
	... action ...
done
#第一次运行时, var的值为value1, 以此运行时, 值以此为上述设定
```

例如: ` for var in aa bb cc; do echo "variable is : ${var}."; done`

```
ipsFile内容:
google 8.8.8.8
srv 43.55.12.111
dns 192.168.50.1
```

```
#!/bin/bash
ips=$(sed 's/^.* //g' ipsFile)
echo $ips
for ip in $ips
do
        ping -c1 $ip > /dev/null 2>&1 && echo "${ip} is: ok" || echo "${ip} is: failed"
done
```

对于连续ip地址:

```
netid="10.10.10"
for ip in {1..100}
do
	ping -c1 ${netid}.${ip}  .....
done
```

配置内核ipv4参数:

```
for i in /proc/sys/net/ipv4/conf/*/{rp_filter,log_martians}; 
do
	echo "1" > $i
```

##### 3.3.2 for i++

```
for (( i=$n; i<=${xxx}; i++ ))
do
	... action ...
done
```

## 4. debug

```
sh -[option] file.sh: 
-n: 不执行, 仅查询语法错误
-x: 显示执行过程
```

