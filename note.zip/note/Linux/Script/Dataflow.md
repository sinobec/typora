###  一般操作:

```
[ctrl]+u/[ctrl]+k: 删除输入的命令行之此前/之后的所有字符
[ctrl]+a/[ctrl]+e: 光标跳转到最前/末尾
 
-: 在stdout时, 代替所生成的文件
source file.sh: 在当前夫程序bash里执行脚本, 其中的变量将会被保留
bash file.sh: 在chile bash里执行脚本, 其中的变量在执行完毕后被舍弃
```



```
tar -cvf - /home | tar -xvf - -C /tmp/xxx
#第一个-, 代表本应打包到文件,取而代之的是输出到stdout
#第二个-, 代表从stdout取虚拟文件作为stdin, 将其解压到/tmp/xxx
```

## 3.数据流导向

数据的输入->处理后的输出, 包括正确执行输出与错误输出

##### 1.输入 stdin:           <  		    <<

```
ssh root@1.2.3.4 "cat >>  ~/.ssh/authorized_keys" < c:\Users\Gaop\.ssh\id_rsa.pub
#过程是先用cat id_rsa.pub取得.pub文件的内容(cat < .pub)
#然后将此内容添加到keys( cat >> keys)
```

##### 2.正确输出stdout:  

##### >   :覆盖     

##### >> :累加 

```
ping -c3 $ip > /dev/null  #执行ping, 但屏幕不会显示
```

#### 3.错误输出stderr:  

#### 2>   :覆盖	

#### 2>> :累加



### 3.1 信息输出

```
#将正确与错误的信息分别存入不同文件: find /home -name .bashrc > rightFile 2> errFile  
```

* 错误黑洞 : /dev/null, 仅显示出正确信息.

```
find /home -name .bashrc 2> /dev/null #输出不会显示错误信息
```

* **数据重定向**

  ​	**fileToBeWrited 1>&2**     : 将1, 即正确输出的数据也导向2
  
  ​	**2>file 2>&1**: 将2, 即错误的数据也导向1		
  
  ​	**&> fileToBeWrited**         : 同上, zsh bash不识别

  例如:

  ```
  #ll 2>/dev/null 1>&2  #虽然ll由正确的输出,但是将1的数据导向了2, 因此导向了数据黑洞
  
  #find /home -name .bashrc >fileName 2>&1 #将正确与错误的信息写入同一文件file
  也可以简写成(在zsh里该方式不识别):
  #find /home -name .bashrc &>fileName
  ```

* 信息stdout 同时输出到文件与使用窗口: tee, 可以将输出到/temp/file的stdout也显示在屏幕上

  ```
  ll | tee /temp/file
  ```

  

### 3.2 捕捉信息输入

##### 3.2.1 read命令

```
-p "提示"： 显示提示内容
-t num: num秒后无输入则自动退出
将输入赋予为变量： 末尾添加变量名； read -p "name: " nameVar
```

##### 3.2.2 cat < file

当cat后没有文件名, 而是以stdin '<'  file时, cat将把file作为输入.

##### 3.2.2 stdin

 	<  : 代表持续键盘输入,直到强制结束
 	<< : 代表一次性键盘输入,之后自动结束

## 4.连续执行命令

#### 4.1 无论结果如何, 都继续执行cmd2: `cmd1 ; cmd2`

#### 4.2  cmd1执行正确, 则继续执行cmd2: `cmd1 && cmd2`

```
ls /tmp/abc && touch /tmp/abc/hehe
```

#### 4.3  cmd1执行错误, 才继续执行cmd2: `cmd1 || cmd2`

```
ls /tmp/abc || mkdir /tmp/abc
```

#### 4.4 依次执行:

```
ls /tmp/abc || mkdir /tmp/abc && touch /tmp/abc/new
```

