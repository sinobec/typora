## 1. Arrsy

###### 1.1 Declare

```
array=()
```

###### 1.2 Append to the end

```
array+=("New")
```

###### 1.3 Display element

```
echo ${array[@]}  #display all element
echo ${array[2]} 
```

