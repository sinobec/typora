

### 1. IP addr static

* Debian: vi /etc/network/interfaces, then`systemctl restart networking`

  ```
  auto ens3
  iface ens3 inet static
    address 192.168.50.121
    netmask 255.255.255.0
    gateway 192.168.50.1
    dns-nameservers 192.168.50.1 8.8.8.8
  ```

* CentOS: vi /etc/sysconfig/network-scripts/ifcfg-ens3

  1. 修改ip地址
  
     ```
     ...
     BOOTPROTO=static
     DEFROUTE=yes
     ...
     IPV6_ADDR_GEN_MODE=stable-privacy
     ONBOOT=yes
             IPADDR=192.168.1.10
             NETMASK=255.255.255.0
             GATEWAY=192.168.1.1
             DNS1=192.168.1.1
             DNS2=8.8.8.8
             DOMAIN=tecmint.lan
     ```
     
  2. 修改dns: vi /etc/resolv.conf
  
     ```
     nameserver 192.168.1.1
     nameserver 8.8.8.8
     ```

### 2. ssh

Upload(append) ssh-key to server

```
ssh user@hostIP -p port "cat >> ~/.ssh/authorized_keys" < ~/.ssh/id_rsa.pub
ssh user@hostIP -p port "cat >> ~/.ssh/authorized_keys" < C:\Users\Gaop\.ssh\id_rsa.pub
```

## 3. 常用命令

##### 3.1 nmcli

更改IP: 

```
nmcli con mod ens3 ipv4.address 192.168.50.121/24
```

