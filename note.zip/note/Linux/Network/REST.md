* Option

  ```
  -X, --request - The HTTP method to be used.
  -i, --include - Include the response headers.
  -d, --data - The data to be sent.
  -H, --header - Additional header to be sent.
  ```

  

## 1. http GET

```
curl https://url/xxx:port
curl https://jsonplaceholder.typicode.com/posts?userId=1
```

## 2. http POST

```
#post data:
curl -X POST -d "userId=5&title=Hello World&body=Post body" https://url/posts
#post json:
curl -X POST -H "Content Type: application/json" -d '{"userID": 5, "title": "Manager", "body": "Mycontent"}' https://url/p
```

