

## 1. 邮件发送过程

* MUA(Mail User Agent): 将邮件发送到邮件服务器上, 指邮件客户端.
* MTA(Mail Transfer Agent): SMTP收信,端口25, Mail server的主要角色. 之后将邮件发送到下一级server, 即收件方的MTA. **SMTP是明文发送, 因此需要在发送前进行加密**.
  * MDA(Mail Delivery Agent): 即上面MTA里将邮件发送出去的功能, 可以根据收件人信息分析去向, 也可以设置自动回复.

> **Open Relay:** 在两部MTA之间进行传输的过程称为Open Relay. 在邮件服务器被侵袭后, 此功能可以被利用以便转发海量垃圾邮件. 因此该功能默认被取消, 同时将MTA设置为仅监听内网端口或开启认证.

## 2. 邮件接受过程

* MTA: 接收到邮件, 传递给MRA
* MRA(Mail Retrieval Agent): **包含POP3(端口110)和IMAP(端口143)两个协议, 均为明文**
* receiptant: MTA根据收件人地址, 将邮件发送给用户