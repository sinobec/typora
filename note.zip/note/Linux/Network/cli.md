# 基础知识

1. ### **TCP包**

   * TCP Header信息, 包含20byte

     ​	可见源端口与目标端口各占16bit

   ![image-20210518121929086](https://i.loli.net/2021/05/19/s13iTfagAvC7SRI.png)

   

   * IP Package信息: tcp包被封装到ip包里(Data部分)以便进行传输

   ![IP packet header fields](https://cdn.networklessons.com/wp-content/uploads/2015/07/xip-packet-header-fields.png.pagespeed.ic.Bq3lp4QSWJ.webp)

   ​				

   #### 1.1 TCP握手

   ###### Client —> Client设置SYN=1, seq=随机数x, 发送到Server
   
   ###### Server —> Server确知TCP包中SYN=1, 于是Server将ACK=1/SYN=1, acknowledge number =x+1, seq=随机数y  一并发回Client
   
   ​              此时server处于*SYN RECV*状态, 若发现有大量*SYN RECV*状态, 可以判断有虚假源ip发送了大量SYN请求进行DDOS攻击
   
   ###### Client —> Client端判断acknowledge number 是否为 x+1, Yes -> ACK=1, acknowledge = y+1, 然后数据发送到Server
   
   ######                   Server再判断是否: ACK=1, acknowledge = y+1
   
   ​	
   
   Send ACK (SYN-ACk-ACK) to server in order to acknowledge server that client has received ACK.

### 2. UDP包:

在添加HEADER后就向下交付给IP层去传输。既不拆分，也不合并:

UDP HEADER由4个字段，各占2个byte, 一共8个byte：

1. 源端口：在需要对方回信时使用，不需要时全为0。

2. 目的端口：发送UDP数据报的目的地。

3. 长度：UDP数据报的长度，最短为8个字节，只包含首部。

4. 检验和：用于检验UDP数据报在传输过程中有没有出差错，有则丢弃。

![UDP Protocol | User Datagram Protocol - javatpoint](https://static.javatpoint.com/tutorial/computer-network/images/udp-protocol.png)

### 3. Port

server的1024以下的端口启用, 必须以root权限.

client的端口, 会随机选取1024以上的使用. 比如client在开启http访问时, 会随机使用1024以上的端口, 向server的80或者443发送tcp包.

### 4. Socket

即ip + port的组合, 网路里可以辨识的唯一进程.

# 2.网络配置

> #### 网络Layer:
>
> ![img](https://cdn.guru99.com/images/1/102219_1135_TCPIPvsOSIM1.png)

## 2.1 本地网络配置

### 2.1.1显示本地ip: **ip a**

```
2: ens3: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9000 qdisc pfifo_fast state UP group default qlen 1000
    link/ether 02:00:17:00:33:29 brd ff:ff:ff:ff:ff:ff
    inet 10.0.0.2/24 brd 10.0.0.255 scope global dynamic ens3
       valid_lft 85752sec preferred_lft 85752sec
    inet6 fe80::17ff:fe00:3329/64 scope link
       valid_lft forever preferred_lft forever
3: docker0: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default
    link/ether 02:42:7b:0d:1e:2f brd ff:ff:ff:ff:ff:ff
    inet 172.17.0.1/16 brd 172.17.255.255 scope global docker0
       valid_lft forever preferred_lft forever
    inet6 fe80::42:7bff:fe0d:1e2f/64 scope link
```

#### 2.1.2 修改本地ip

* ###### 临时性修改, 在systemctl restart network后复原

  ```
  #ifconfig eth0 192.168.1.11; 临时设置该网卡的另一个新的ip地址
  #ifconfig eth0 mtu 9000;
  #ifconfig eth0:0 192.168.5.12 netmask 255.255.255.0 ; 在同一个网卡上再增加一个ip
  
  #ifconfig eth0:0 down; 将新增的ip, 即网络接口关闭
  ```

* ###### 永久性修改

  ###### 设置静态ip地址

  在`/etc/sysconfig/network-scripts/ `下可以发现名为`ifcfg-网卡`的配置文件

  ```
  BOOTPROTO=static
  IPADDR=192.168.1.12
  NETMASK=255.255.255.0
  GATEWAY=192.168.1.1
  DNS1=192.168.1.1
  DNS2=8.8.8.8
  MTU= ,此处可以设置MTU
  ```

  最后执行`/etc/init.d/network restart`

  ###### 设置DNS

  在`/etc/resolv.conf`中可以设置DNS

  ```
  nameserver 168.95.1.1
  nameserver 139.175.10.20
  ```

  ###### 设定hostname

  ​	在`/etc/sysconfig/network`以及`/etc/hosts`中设置Hostname, 需要重启

  ```
  #/etc/sysconfig/network
  NETWORKING=yes
  HOSTNAME=myhost.local
  
  #/etc/hosts
  192.168.1.100 myhost.local
  ```

#### 2.1.3 测试网络连接状态及max MTU: **ping**, curl

> ip **MTU**: TCP将数据封装到IP之后, IP会将数据包divide成一个个小的fragment, 再接收端又重新resemble成原始包. MTU决定了每一个piece的大小.越大的MTU, 分包的过程就越少. 一般MTU的尺寸是1500byte, 但由于MTU包含IP header和tcp header(各20byte, 所以实际上MTU的payload只有1460byte)
>
> tcp **MSS**: maximum segment size. 指的是TCP包内纯数据的最大容量. 其最大容量为1460-24=1436

Ping 参数:

```
#ping -c 3: 仅侦测3次
#ping -W 1: 仅等待对方相应1秒
```

Ping 实例: 测试网络可接受的MTU. 由于ip包的头部信息为20b, icmp的头部为8b, 因此侦测最大MTU时需要减去28.

```
#ping -c2 -s 1472 -M do 192.168.50.1
#ping -c2 -s 9000 -M do 192.168.50.1
ping: local error: Message too long, mtu=1500, 显示该网络设置的MTU仅为1500
```

当ping(icmp协议)被屏蔽时, 可以使用curl进行联通状态检测

```
crul -vk telnet://ip
```



#### 2.1.4 测试hop: **traceroute**

一般使用`traceroute -n 域名` . 默认的使用UDP包, 可以使用icmp或tcp包

* 参数

  ```
  -I ：使用 ICMP 的方式来进行侦测；
  -T ：使用 TCP 来进行侦测，一般使用 port 80 测试
  ```

* 实例

  ```
  1  192.168.50.1  0.272 ms  0.256 ms  0.193 ms
   2  * * * , 此处指的是可能有防火墙
   3  10.170.192.58  14.555 ms  14.491 ms  14.370 ms
  ```


##### 2.1.5 nmap探测端口

```
nmap -sV -O -v url
```

* Option:

  -sT: 全开tcp扫描

  -sV: 系统版本

  -O: 识别OS

  -sS : TCP 同步扫描 (TCP SYN)，因为不必全部打开一个 TCP 连接，所以这项技术通常称为半开扫描 (half-open)。这项技术最大的好处是，很少有系统能够把这记入系统日志。不过，你需要 root 权限来定制 SYN 数据包。

  -p(小写): p 1-65535, 扫描全部端口

#### 2.1.5 netstat

* option, 常用 `-tunlp` 或 `-tunap`

  ```
  -r ：列出路由表(route table)，功能如同 route 这个指令；
  -n ：不使用主机名与服务名称，使用 IP 与 port number ，如同 route -n
  与网络接口有关的参数：
  -a ：列出所有的联机状态，包括 tcp/udp/unix socket 等；
  -t ：仅列出 TCP 封包的联机；
  -u ：仅列出 UDP 封包的联机；
  -l ：仅列出有在 Listen (监听) 的服务之网络状态；
  -p ：列出 PID 与 Program 的檔名；
  -c ：可以设定几秒钟后自动更新一次，例如 -c 5 每五秒更新一次网络状态的显示
  ```

#### 2.1.6 tcpdump

用于检测tcp/udp包

* Option. 常用 -nvvv ; -i 网卡; -w 写入文件& -r 读取文件

  ```
  -A ：封包的内容以 ASCII 显示，通常用来捉取 WWW 的网页封包资料。
  -e ：使用资料连接层 (OSI 第二层) 的 MAC 封包数据来显示；
  -nn：直接以 IP 及 port number 显示，而非主机名与服务名称
  -q ：仅列出较为简短的封包信息，每一行的内容比较精简
  -X ：可以列出十六进制 (hex) 以及 ASCII 的封包内容，对于监听封包内容很有用
  -i ：后面接要『监听』的网络接口，例如 eth0, lo, ppp0 等等的界面；
  -w ：如果你要将监听所得的封包数据储存下来,后面接档名
  -r ：从后面接的档案将封包数据读出来。那个『档案』是已经存在的档案，
  并且这个『档案』是由 -w 所制作出来的。
  -c ：监听的封包数, 为了避免系统因此崩溃, 可以设为 -c 10000. 如果没有这个参数,tcpdump 会持续不断的监听直到使用者输入 [ctrl]-c 为止。
  ```

  ```
  #### 常用选项:
  'host foo', 'host 127.0.0.1' ：针对单部主机来进行封包撷取,包括进入以及发出的包.
  'net 192.168' ：针对某个网域来进行封包的撷取；
  'src host 127.0.0.1' 'dst net 192.168'：同时加上来源(src)或目标(dst)限制
  'tcp port 21'：可以针对协议及端口，如 tcp, udp, arp, ether 等
  'tcpdump ip host srv1 and not srv2': 还可以利用 and 与 or 来进行封包数据的整合显示, 此处指抓取srv1和任何主机(除srv2)之间的通信包.
  'tcpdump -c 5 -nn -i eth0 icmp and src 192.168.100.62': 抓取70主机对本机的ping
  'tcpdump -c 10 -nn -i eth0 tcp dst port 22': 抓取发到本机22端口的包
  ```

  ```
  ##USAGE##
  Basic communication // see the basics without many options
  # tcpdump -nS
  
  Basic communication (very verbose) // see a good amount of traffic, with verbosity and no name help
  # tcpdump -nnvvS
  
  A deeper look at the traffic // adds -X for payload but doesn’t grab any more of the packet
  # tcpdump -nnvvXS
  
  Heavy packet viewing // the final “s” increases the snaplength, grabbing the whole packet
  # tcpdump -nnvvXSs 1514
  
  host // look for traffic based on IP address (also works with hostname if you’re not using -n) 
  # tcpdump host 1.2.3.4
  
  src, dst // find traffic from only a source or destination (eliminates one side of a host conversation) 
  # tcpdump src 2.3.4.5 
  # tcpdump dst 3.4.5.6
  
  net // capture an entire network using CIDR notation 
  # tcpdump net 1.2.3.0/24
  
  proto // works for tcp, udp, and icmp. Note that you don’t have to type proto 
  # tcpdump icmp
  
  port // see only traffic to or from a certain port 
  # tcpdump port 3389
  
  src, dst port // filter based on the source or destination port 
  # tcpdump src port 1025 # tcpdump dst port 389
  
  src/dst, port, protocol // combine all three 
  # tcpdump src port 1025 and tcp 
  # tcpdump udp and src port 53
  
  You also have the option to filter by a range of ports instead of declaring them individually, and to only see packets that are above or below a certain size.
  
  Port Ranges // see traffic to any port in a range 
  tcpdump portrange 21-23
  
  Packet Size Filter // only see packets below or above a certain size (in bytes) 
  tcpdump less 32 
  tcpdump greater 128
  [ You can use the symbols for less than, greater than, and less than or equal / greater than or equal signs as well. ]
  
  // filtering for size using symbols 
  tcpdump > 32 
  tcpdump <= 128
  
  [ Note: Only the PSH, RST, SYN, and FIN flags are displayed in tcpdump‘s flag field output. URGs and ACKs are displayed, but they are shown elsewhere in the output rather than in the flags field ]
  
  Keep in mind the reasons these filters work. The filters above find these various packets because tcp[13] looks at offset 13 in the TCP header, the number represents the location within the byte, and the !=0 means that the flag in question is set to 1, i.e. it’s on.
  
  Show all URG packets:
  # tcpdump 'tcp[13] & 32 != 0'
  
  Show all ACK packets:
  # tcpdump 'tcp[13] & 16 != 0'
  
  Show all PSH packets:
  # tcpdump 'tcp[13] & 8 != 0'
  
  Show all RST packets:
  # tcpdump 'tcp[13] & 4 != 0'
  
  Show all SYN packets:
  # tcpdump 'tcp[13] & 2 != 0'
  
  Show all FIN packets:
  # tcpdump 'tcp[13] & 1 != 0'
  
  Show all SYN-ACK packets:
  # tcpdump 'tcp[13] = 18'
  
  Show icmp echo request and reply
  #tcpdump -n icmp and 'icmp[0] != 8 and icmp[0] != 0'
  
  Show all IP packets with a non-zero TOS field (one byte TOS field is at offset 1 in IP header):
  # tcpdump -v -n ip and ip[1]!=0
  
  Show all IP packets with TTL less than some value (on byte TTL field is at offset 8 in IP header):
  # tcpdump -v ip and 'ip[8]<2'
  
  Show TCP SYN packets:
  # tcpdump -n tcp and port 80 and 'tcp[tcpflags] & tcp-syn == tcp-syn'
  # tcpdump tcp and port 80 and 'tcp[tcpflags] == tcp-syn'
  # tcpdump -i <interface> "tcp[tcpflags] & (tcp-syn) != 0"
  
  Show TCP ACK packets:
  # tcpdump -i <interface> "tcp[tcpflags] & (tcp-ack) != 0"
  
  Show TCP SYN/ACK packets (typically, responses from servers):
  # tcpdump -n tcp and 'tcp[tcpflags] & (tcp-syn|tcp-ack) == (tcp-syn|tcp-ack)'
  # tcpdump -n tcp and 'tcp[tcpflags] & tcp-syn == tcp-syn' and 'tcp[tcpflags] & tcp-ack == tcp-ack'
  # tcpdump -i <interface> "tcp[tcpflags] & (tcp-syn|tcp-ack) != 0"
  
  Show TCP FIN packets:
  # tcpdump -i <interface> "tcp[tcpflags] & (tcp-fin) != 0"
  
  Show ARP Packets with MAC address
  # tcpdump -vv -e -nn ether proto 0x0806
  
  Show packets of a specified length (IP packet length (16 bits) is located at offset 2 in IP header):
  # tcpdump -l icmp and '(ip[2:2]>50)' -w - |tcpdump -r - -v ip and '(ip[2:2]<60)'
  
  More Details: 
  http://danielmiessler.com/study/tcpdump/
  ```

* TCP协议Flags

  ```
  S 表示 SYN 包, 表示主动要求建立连接
  . 表示 ACK 包
  F 表示 FIN 包
  P 表示 PUSH, 一般看到此Flag就代表发送正常数据了
  #实际的握手协议会对应为
  [S] seq 11
  [S.] ack 12此处加1 seq 212
  [.] ack 213此处加1
  ```

* 实例

  1. ```
     #tcpdump -nvvv -i ens3 src host 80.71.33.6
     80.71.33.6.60607 > 10.0.0.2.ssh: Flags [.], cksum 0x3a98 (correct), seq 0, ack 61825, win 4092, length 0
     02:56:51.755234 IP (tos 0x0, ttl 47, id 0, offset 0, flags [DF], proto TCP (6), length 76)
         80.71.33.6.60607 > 10.0.0.2.ssh: Flags [P.], cksum 0x6e44 (correct), seq 0:36, ack 61825, win 4096, length 36
     [结论]: 
     发送端ip后的60607代表发送端口
     .ssh显示了接受端口
     Flags [.]代表对方发送了ack包
     seq 0表示ip包的封包序列号为0, 即没有分装ip包, 如果显示seq 196:472, 那么之后会看到发送端以seq 473为起始的另一个封包.
     第二行的Flags [P.]代表tcp头的PSH
     ```
     
  2. ```
     #tcpdump -i any -n tcp port 10050
     检测zabbix客户端无响应,本机10050端口是否有incoming的数据
     ```

     

* **wireshark**: 图形化tcp包分析, 配合tcpdump抓取来的数据

#### 2.1.7 nmap

* 主要参数

  ```
  -sT：扫瞄 TCP 封包已建立的联机 connect() 
  -sS：扫瞄 TCP 封包带有 SYN 卷标的数据
  -sP：以 ping 的方式进行扫瞄
  -sU：以 UDP 的封包格式进行扫瞄
  -sO：以 IP 的协议 (protocol) 进行主机的扫瞄
  [扫瞄参数]：主要的扫瞄参数有几种：
  -PT：使用 TCP 里头的 ping 的方式来进行扫瞄，可以获知目前有几部计算机存活(较常用)
  -PI：使用实际的 ping (带有 ICMP 封包的) 来进行扫瞄
  -p ：指定端口port范围, -p 1024-2048
  [Hosts 地址与范围]：这个有趣多了，有几种类似的类型
  192.168.1.100 ：直接写入 HOST IP 而已，仅检查一部
  ```

* 常用格式

  ```
  #nmap -sTU -p 1-65535 targetIP: 查询目标的TCP和UDP去端口
  ```




#### 2.2. 实例(临时配置)

```
#ifconfig ens33:0 10.10.20.12/24, 先在网卡上增加一个网络端口, 即添加一个ip
#route add -net 10.10.20.0/24 gw 10.10.20.12 dev ens33, 然后利用该端口为gw, 添加一个路由
```



## 2.2 检测本机网络连接 

##### 2.2.1 **netstat -tanp** :  比如netstat -ntap 5 | grep 80

```
-a: 显示所有socket连接, 不能和 "-l" 一起用, 要比-l显示更多的信息，比如显示etablished/close_wait等连接.
-l: 表示正在监听的socket
-p: 表示显示进程信息(需要root)
-t: 仅显示tcp
```



##### 2.2.2 **ping**

```
#ping -c 3: 仅侦测3次
#ping -W 1: 仅等待对方相应1秒
```



## 2.3 Route Table

### 2.3.1 显示Route table内容: 

`route -n`

`netstat -nr`

传输规则 ->优先级由详细到宽泛, 比如172.17.0.0比0.0.0.0的规则更细致, 因此发往172.17.0.0的数据优先经由规则3

```
Destination     Gateway         Genmask         Flags Metric Ref    Use Iface
0.0.0.0         192.168.50.1    0.0.0.0         UG    100    0        0 ens33
192.168.50.0    0.0.0.0         255.255.255.0   U     100    0        0 ens33
172.17.0.0      0.0.0.0         255.255.0.0     U     0      0        0 docker0

第一行表示去往任意网址, 即internet, 需经由50.1的gw, 切经过ens33网卡
第二行表示去往50.0, 无需经由gw, 但是需经由ens33网卡
第三行表示去往172.17内网无需经由gw, 但是需经过docker0虚拟网卡, 且此网段cidr为16
```

***option***

o U (route is up)：该路由是启动的；

o H (target is a host)：目标是一部主机 (IP) 而非网域；

o G (use gateway)：需要透过外部的主机 (gateway) 来转递封包；

o R (reinstate route for dynamic routing)：使用动态路由时，恢复路由信息的旗标；

o D (dynamically installed by daemon or redirect)：已经由服务或转 port 功能设定为动态路由

o M (modified from routing daemon or redirect)：路由已经被修改了；

o ! (reject route)：这个路由将不会被接受(用来抵挡不安全的网域！)



### 2.3.2 设置临时路由

* 增加路由: 

  `ip route add 10.0.0.0/24 via 192.168.92.129 [dev ens3]`

  `route add -host 192.168.1.123 dev eth0`, 添加目的地为一个host的路由规则

  `route add -net 192.168.100.0/24 dev eth0`, 添加目的地为到一个网段的路由规则

* 删除路由: 

  `ip route del 10.0.0.0/24` 或 `ip route del default`

  `route del -net 169.254.0.0 netmask 255.255.0.0 dev eth0`

### 2.3.3 设置永久路由

* 增加新路由: 

* CentOS: **vi  /etc/sysconfig/network-scripts/route-ens3** (此为新文件,文件名需对应dev)

  ```
  15.15.0.0/24 via 10.1.1.110 dev enp0s3
  ```

* Ubuntu: **vi /etc/netplan/00-installer-config.yaml**

  ```
  network:
      ethernets:
          enp0s3:
              dhcp4: false
              addresses: [192.168.1.202/24]
              gateway4: 192.168.1.1
              nameservers:
                addresses: [8.8.8.8,8.8.4.4,192.168.1.1]
              routes:
              - to: 172.16.0.0/24
                via: 192.168.1.100
      version: 2
  ```

  



## 2.4 ARP table

由于arp table每个20分钟就刷新ip地址与mac地址之间的对应关系, 所以在有需要的时候可以设置静态arp

* ###### 显示本机记录中的arp table: **arp -n**

  ```
  Address                  HWtype  HWaddress           Flags Mask            Iface
  172.17.0.2               ether   02:42:ac:11:00:02   C                     docker0
  169.254.169.254          ether   00:00:17:a0:a8:eb   C                     ens3
  10.0.0.1                 ether   00:00:17:a0:a8:eb   C                     ens3
  ```

  

* ###### 建立静态arp table记录: **arp -s 192.168.1.100 01:00:2D:23:A1:0E**

# 3. ip

### 3.1 ip link: 协议第2层

该命令用于操作OSI layer 2, 即MAC地址网卡开关等.

```
#ip link set ens33 down
#ip link set eth0 mtu 9000
```

### 3.2 ip address. Ip route: 协议第3层

该命令用于操作OSI第三层, 即IP地址及路由

```
#ip address show
#ip address add 192.168.50.50/24 broadcast + dev eth0 label eth0:0
```



```
#ip route show
#ip route add 192.168.10.0/24 via 192.168.5.100 dev eth0
```







```
   <details>Active Internet connections (servers and established)
  Proto Recv-Q Send-Q Local Address           Foreign Address         State       PID/Program name
  tcp        0      0 0.0.0.0:111             0.0.0.0:*               LISTEN      1023/rpcbind
  tcp        0      0 0.0.0.0:22              0.0.0.0:*               LISTEN      1737/sshd
  tcp        0      0 127.0.0.1:25            0.0.0.0:*               LISTEN      1734/master
  tcp        0      0 0.0.0.0:443             0.0.0.0:*               LISTEN      2882/docker-proxy
  tcp       32      0 10.0.0.2:60434          140.204.8.149:443       CLOSE_WAIT  15876/updater
  tcp        1      0 10.0.0.2:55622          169.254.169.254:80      CLOSE_WAIT  15876/updater
  tcp        0      0 10.0.0.2:55814          169.254.169.254:80      ESTABLISHED 15850/gomon
  tcp        0    136 10.0.0.2:22             80.71.33.6:57201        ESTABLISHED 12032/sshd: opc [pr
  tcp        1      0 10.0.0.2:55624          169.254.169.254:80      CLOSE_WAIT  15876/updater
  tcp6       0      0 :::111                  :::*                    LISTEN      1023/rpcbind
  tcp6       0      0 :::22                   :::*                    LISTEN      1737/sshd
  tcp6       0      0 ::1:25                  :::*                    LISTEN      1734/master
</details>
  
##### ->实例
  
显示本机进程占用的端口: `netstat -ntlp | grep sshd`
  
显示端口被谁占用: `netstat -ntlp | grep 22`
  
  显示是否和远程机建立连接: `netstat -na | grep 10.10.10.2`
  
* sar -n DEV 1 10: 查看网卡流量, 每秒查看一次, 一共查看10次. rxpck大于4000则遭受攻击

## 远程探测

#### ->远程端口探测

##### 1. 探测指定端口或部分端口

###### curl -vk telnet://104.243.27.45:22

###### nmap 104.243.27.45 -p 29400-29500

	PORT      STATE SERVICE
	29497/tcp open  unknown

##### 2. 探测所有开放的端口: -p-参数指的是也扫描1000以上的端口

###### nmap -sT -p- 104.243.27.45

<details>Not shown: 957 filtered ports, 37 closed ports
PORT    STATE SERVICE
21/tcp  open  ftp
80/tcp  open  http
139/tcp open  netbios-ssn
443/tcp open  https
445/tcp open  microsoft-ds
548/tcp open  afp
## TCP包检测

##### 显示连到目标所经过的本机网卡: 

```
ip route get targetIP
```

##### 捕捉tcp package

```
tcpdump -nvvv -i any(此处可以单独指定特定的网卡)

捕捉包并写入到文件: tcpdump -i enp0s8 -w /var/tmp/捕捉包文件名.pcap
读取包文件:        tcpdump -nvvv -r /var/tmp/捕捉包文件名.pcap
		显示包文件更详细的内容: tcpdump -nvvv -r /var/tmp/db-capture.pcap port 3306 and host 192.168.33.11

```

##### tcp包的参数:

<details>- `Flags [P.]`:  flag里的缩写代表了网络传输状态, 比如S代表SYN.
- `SYN- [S]`: This is a Synchronize packet, the first packet sent from the client to the server.
- `SYN-ACK- [S.]`: This is a Synchronize Acknowledgement packet; these packet flags are used to indicate that the server received the client's `SYN` requests.
- `ACK- [.]`: The Acknowledgement packet is used by both the server and the client to acknowledge the received packets. After the initial `SYN` packet is sent, all subsequent packets should have the acknowledgement flag set.
- `PSH- [P]`: This is a Push packet. It is designed to push the buffered network data to the receiver. This is the type of packet where data is actually transferred.
- `PSH-ACK- [P.]`: The Push Acknowledgement packet is used to both acknowledge a previous packet and send data to the recipient.
- `FIN- [F]`: The `FIN` or Finish packet is used to tell the server that there is no more data and that it can close the established connection.
- `FIN-ACK- [F.]`: The Finish Acknowledgement packet is used to acknowledge that the previous Finish packet was received.
- `**RST- [R]**`: The Reset packet is used when the source system wishes to Reset the connection. In general, this is due to an error or the target port is not actually in the listening status.
- `RST-ACK -[R.]`: The Reset Acknowledgement packet is used to acknowledge that the previous Reset packet was received.

> 此包一般是发送方发送的SYN到达了接收方, 但是迟迟得不到SYN-ACK时, 由发送方发送的.一般可以由此判断发送到目标的连接是畅通的,但是没有收到接收方的SYN-ACK[S.]


```

# 3. 设置网络: 

## PART A: 永久设置





