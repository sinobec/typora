> 1. arp proxy 可以手动设置MAC与目标host ip地址的关系来设置响应流量的网卡: `arp -i eth1 -s 192.168.1.101 08:00:27:2A:30:14 pub`
> 2. 每部主机都有自己的路由表，此路由表 (routing table) 是作为封包传送时的路径依据
> 3. 动态路由通常是用在两个 Router 之间沟通彼此的路由规则用的，常见的 Linux 上的动态路由套件为 zebra

## 1. 查看route table

* **route -n**

* **netstat -nr**

  传输规则 ->优先级由详细到宽泛, 比如172.17.0.0比0.0.0.0的规则更细致, 因此发往172.17.0.0的数据优先经由规则3

  ```
  Destination     Gateway         Genmask         Flags Metric Ref    Use Iface
  0.0.0.0         192.168.50.1    0.0.0.0         UG    100    0        0 ens33
  192.168.50.0    0.0.0.0         255.255.255.0   U     100    0        0 ens33
  172.17.0.0      0.0.0.0         255.255.0.0     U     0      0        0 docker0
  
  第一行表示去往任意网址, 即internet, 需经由50.1的gw, 切经过ens33网卡
  第二行表示去往50.0, 无需经由gw, 但是需经由ens33网卡
  第三行表示去往172.17内网无需经由gw, 但是需经过docker0虚拟网卡, 且此网段cidr为16
  ```

  ***option***

  o U (route is up)：该路由是启动的；

  o H (target is a host)：目标是一部主机 (IP) 而非网域；

  o G (use gateway)：需要透过外部的主机 (gateway) 来转递封包；

  o R (reinstate route for dynamic routing)：使用动态路由时，恢复路由信息的旗标；

  o D (dynamically installed by daemon or redirect)：已经由服务或转 port 功能设定为动态路由

  o M (modified from routing daemon or redirect)：路由已经被修改了；

  o ! (reject route)：这个路由将不会被接受(用来抵挡不安全的网域！)


## 2. 设置路由

##### 2.1 设置临时路由

* 增加: 

  ```
  ip route add 10.0.0.0/24 via 192.168.92.129 [dev ens3]
  route add -host 192.168.1.123 dev eth0   #添加目的地为一个host的路由规则
  人oute add -net 192.168.100.0 netmask 255.255.255.0 dev eth0  #添加目的地为到一个网段的路由规则
  ```

* 删除: 

  ```
  ip route del 10.0.0.0/24` 或 `ip route del default
  route del -net 169.254.0.0 netmask 255.255.0.0 dev eth0
  ```

#### 2.2. 设置永久路由

* CentOS: **vi  /etc/sysconfig/network-scripts/route-ens3** (此为新文件,文件名需对应dev)

  ```
  15.15.0.0/24 via 10.1.1.110 dev enp0s3
  ```

* Ubuntu: **vi /etc/netplan/00-installer-config.yaml**

  ```
  network:
      ethernets:
          enp0s3:
              dhcp4: false
              addresses: [192.168.1.202/24]
              gateway4: 192.168.1.1
              nameservers:
                addresses: [8.8.8.8,8.8.4.4,192.168.1.1]
              routes:
              - to: 172.16.0.0/24
                via: 192.168.1.100
      version: 2
  ```


## 3. 设置IP转发 

ip forward的目的是, 在具备多个网卡的设备上, 将来到某个网卡的流量转发到其他网卡, 即将此设备设置为路由器.

```
echo "1" > /proc/sys/net/ipv4/ip_forward
```

## 4. 设置动态路由

