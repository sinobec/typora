>  防火墙的防御流程: preroute先通过头部判断, 如果发现目标不是本机,而是后端的device, 就直接转发; 
>
> 如果判断目标是本机, 则firewalld(其中的Input和Output) -> TCP Wrappers -> Host自身权限



# 1.数据包层防火墙: Netfilter

  在2,3,4层对ip, icmp, tcp等包进行分析过滤, 包含两种设置管理方式: **firewall-cmd** 和 **iptables, 前者更方便

### 1.1 Firewall-cmd

* 查看default zone

```
firewall-cmd --get-default-zone
```

* 查看端口是否开放

```
#firewall-cmd --zone=public --query-port=29498/tcp
查看已开放端口
# firewall-cmd --zone=public --list-ports
```

* 添加防火墙规则

```
# firewall-cmd --permanent --add-port=29497/tcp
# firewall-cmd --reload
```

* 排查问题

在tcp无法连接时利用tcpdump来捕捉数据包, 当显示`unreactable - admin prohibited`时可以判断是防火墙阻止了数据连接, 此时再利用firewall-cmd --list-ports排查该端口是否开启



### 1.2. iptables / nftables

##### 1.2.1 iptables

iptables通过分析数据包的头部信息来判断是否其符合规则. 判断的标准是依次从上到下, 符合任何一条规则就执行. 如果都不符合, 就执行默认的规则.

#### 1.2.2 iptables chain

一般包含两个预设的table: 

1. **Filter**: 与本机有关(INPUT, OUTPUT, FORWARD); forward与下一条(NAT)密切相关
2. **NAT(Preroute,Input,Postroute)**: 与本机之后的设备有关, 主要用于路由器

*默认规则应为: 

**iptables -P *action***:  制定policy, action包括 ACCEPT/DROP

`iptables -P INPUT DROP`: **执行该规则会立即block ssh等全部INPUT服务, 因此建议``iptables -A INPUT -j REJECT`

`iptables -A INPUT -m state --state RELATED,ESTABLISHED -j ACCEPT`启用默认state规则

`iptables -P OUTPUT ACCEPT`, 对应Output chain

`iptables -P FORWARD ACCEPT`

#### 1.2.3 观察iptables规则

```
iptables -L-n: 会观察到基本的信息,但是不包含网卡信息
iptables-save: 可以观察到完整信息
```

#### 1.2.4 增加iptables规则

`iptables [-AI 链名] [-io 网络接口] [-p 协议]  [-s 来源IP/网域] [-d 目标IP/网域] [--dport 端口范围] -j [ACCEPT|DROP|REJECT|LOG]`

-A chainName: 添加新规则到该chain的最后, 例如 iptables -A INPUT. 这会导致改规则出现在reject all之后!!!!

**-I: 添加新规则到起始**

-i: 数据包进入的网卡, 例如 iptables -A INPUT -i ens3

-o: 数据包输出的网卡

**-p protocal**: 协议, 例如 iptables -A INPUT -i ens3 -p tcp

-s: 数据包来源, 例如 iptables -A INPUT -i ens3 -p tcp -s 192.168.0.0/24

-d: 目标地址

**--dport: 端口范围**,也可以写成--dport ssh

-j: 动作

```
iptables -I INPUT -i ens3 -p tcp -s 192.168.0.0/24 --dport 10050 -j ACCEPT
```

*其他

--m state: 判断该数据包是否为自身发出后获得的响应, 如果是的话一般会Accept: iptables -A INPUT -m state --state RELATED,ESTABLISHED -j ACCEPT

> 封包的状态主要有：
>
> -INVALID ：无效的封包，例如数据破损的封包状态
>
> -ESTABLISHED：已经联机成功的联机状态；
>
> -NEW ：想要新建立联机的封包状态；
>
> -RELATED ：这个最常用！表示这个封包是与我们主机发送出去的封包有关

-m mac --mac-source MACAdd: 针对特定MAC地址进行设置

-p icmp --icmp-type 8: icmp有不同的type, 8代表echo request

##### 2.1.4 永久保持规则-Ubuntu

```
#pt-get install iptables
    iptables -I INPUT -p tcp --dport 29497 -j ACCEPT
iptables -I INPUT -p udp --dport 29497 -j ACCEPT
iptables-save
#修改conf
apt-get install iptables-persistent
netfilter-persistent save
netfilter-persistent reload
```

​		测试开放端口: netstat -anp | grep portNumber

##### 1.2.5 删除iptables rule

```
iptables -D INPUT 3 ,删除第三条input规则
```

##### 1.2.6 nftables

###### 2.2.1 Install and conf

```
apt install nftables
systemctl enable nftables.service
```

Conf: ``/etc/nftables.conf`

# 2. 应用层:TCP Wrappers

• /etc/hosts.allow => rule:ip, 即符合规则就予以放行；

• /etc/hosts.deny => rule:ip, 符合规则就予以抵挡；

• 若不在这两个档案内，亦即规则都不符合，最终则予以放行。

* 配置文件示例

  ```
  协议名:ip地址:动作(allow或deny;此设置默认值为设置文件的默认名,可以忽略)
  #/etc/hosts.allow
  ALL: 127.0.0.1
  sshd: 61.63.65.67,192.168.2.*  
  
  #/etc/hosts.deny
  sshd:ALL
  ```



# 3. IPv4的配置

配置文件在: `/proc/sys/net/ipv4/`下, 主要配置项:

```
echo "1" > /proc/sys/net/ipv4/tcp_syncookies, 预防DDOS, 但会增加tcp建立连接的时间
echo "1" > /proc/sys/net/ipv4/icmp_echo_ignore_broadcasts, 预防ping flooding
echo "1" > /proc/sys/net/ipv4/conf/有效网卡名/rp_filter, 自动分析来源的有效性,采取drop过滤
echo "1" > /proc/sys/net/ipv4/conf/有效网卡名/log_martians, 将非法ip记录到/log/messages
上述地址下的/accept_redirects以及/send_redirects, 可以允许隶属于同一设备下的不同网段之间相互传递icmp, 建议关闭
```

也可以通过修改/etc/sysctl.conf, 添加

```
net.ipv4.tcp_syncookies = 1
net.ipv4.icmp_echo_ignore_broadcasts = 1
net.ipv4.conf.all.rp_filter = 1
net.ipv4.conf.default.rp_filter = 1
net.ipv4.conf.eth0.rp_filter = 1
net.ipv4.conf.lo.rp_filter = 1 
```

# 4. NAT代理

作为NAT代理, 负责内网向外网发送数据的SNAT以及接受外网访问的DNAT功能.

##### 5.1 SNAT

1. 网数据经由preroute部分, 由于其数据包头部的目标ip地址为外网ip, 因此被iptables的规则forward到面对外网的网卡上. 
2. 在暴露在外网的网卡上进行postroute, 其数据包头部源ip地址, 被转换为该网卡的公网ip, 这两个对应的ip地址会被记录到内存中.
   1. 之后将该数据包发送到外网. 此时任何外网服务器都会判断该数据包来自于这个网卡的公网ip.
3. 传回该网卡的数据包, 在preroute阶段通过其seq号码, 分析其包头的ip地址时, 和之前暂存到内存里的ip地址进行比较. 发现此包最初的源ip地址, 并以此为依据将目标ip从公网ip转换为内网ip.
4. 此时由于目标ip为内网ip, 数据被forward到内网网卡,然后被发送到内网设备.

在iptables的语句里表现为:`iptables -t nat -A POSTROUTING -s 内网网段 -o 外网网卡 -j MASQUERAD`, MASQUERD即为将源内网ip转化为外网ip.

##### 5.2 DNAT

1. 首先需要在路由里设置preroute, 以便在外网访问数据包到达时,将其导向到内网里的http server:

```
iptables -t nat -A PREROUTING -i 外网网卡 -p tcp --dport 80 -j DNAT --to-destination 192.168.100.10:80
```

```

