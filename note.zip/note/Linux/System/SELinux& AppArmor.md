# 第一部分: SELinux

> 通常Linux的权限由DiscretionaryAccess Control, DAC来控制, 即由owner来决定权限, 为了提高安全性,  系统同时使用了Selinux, 即采用了Mandatory Access Control, MAC来针对特定程序来设置有别于owner的权限限制. 对于某些程序proc而言, root有可能不具备完整的root权限.
>
> 这样对于特定目录或与之依附的程序(proc), 就同时被DAC和MAC所控制.

###### SELinux是RedHat系统下的默认MAC控制器

## 1. SELinux的组成

### 1.1 SELinux Rules

> Rules的组成是: proc + path + rules, 对于特定的proc, 由rules来制定具备操作path的权限.

##### 1.1.1 SELinux Rules类别:

```
targeted：针对⽹络服务限制较多，针对本机限制较少，是默认的政策；
minimum：由 target 修订⽽来，仅针对选择的程序来保护！
mls：完整的 SELinux 限制，限制⽅⾯较为严格。
```



##### 1.1.2 查询并修改各个rules的状态: **getsebool -a, setsebool -P**

* 查询

```
#getsebool -a | grep httpd
...
httpd_enable_cgi --> on
httpd_enable_ftp_server --> off
httpd_enable_homedirs --> off
```

* 修改

```
#setsebool -P httpd_enable_homedirs 1
讲上述查到的off改为on
```

### 1.2 SELinux安全文本 - security context(仅针对targeted模式)

> 在经过Rules校验后, 还需要security context的效验, 符合后才可以读取path. Secure content存储于inode里

##### 1.2.1 安全文本:

安全文本指的是"文件的安全文本 <-> 进程的安全文本"两者相对应.

* 文件安全文本的创建: 取决于文件创建时的path以及由哪个proc创建的. mv文件不会改变其安全文本.
* 安全文本的第三个字段代表着该文本的type, 

##### 1.2.2 安全文本在cp.mv过程中的改变

* 在cp时: 安全文本内容会适应目标文件夹的安全文本
* 在mv时:安全文本会保留原来的值

##### 1.2.3 更改安全文本: chcon

```
#chcon -t 目标安全文本 file: 将file的安全文本更改为目标安全文本
#chcon -reference=源文件 file: 将file的安全文本更改为和源文件的一样
#chcon -R: 更改整个目录的安全文本
```

##### 1.2.4 修复安全文本type: **restorecon**

```
#restorecon -Rv pathName 
自动恢复某path下的selinux type
```



## 2. SELinux模式

模式配置文件位于: `/etc/selinux/config`

1. enforcing：强制模式，代表 SELinux 运⾏中，且已经正确的开始限制 domain/type 了；

   ​	Ubuntu的AppArmor下为: Enforcement模式

2. permissive：宽容模式：代表 SELinux 运⾏中，不过仅会有警告讯息并不会实际限制 domain/type 的存取。这种模式可以用于debug

   ​	Ubuntu下为: Complain模式

3. disabled ；关闭SELinux

* ##### 切换模式: 

  ```
  #setenforce 0 : 当前模式是enforcing时, 如果要切换成permissive
  #setenforce 1 : 当前模式是permissive时, 如果要切换成enforcing
  ```

> 从disabled切换到enforcing后, 很多service会显示无法正常工作, 此时需要切换到permissive模式, 然后运行
>
> ```
> restorecon -Rv /
> ```
>
> 

## 3. 获取SELinux状态

### 3.1 获取进程的受(SELinux)限状态: **ps**

```
#ps -eZ | grep proc
此处可以观察到进程安全文本的内容:
unconfined_u:unconfined_r:unconfined_t:s0-s0:c0.c1023 21483 ? 00:00:00 sshd
                          此处即第三个字段显示了sshd是不受限的
#ps -eZ | grep systemd
system_u:system_r:syslogd_t:s0    838 ?   00:10:38 systemd-journal
                  此处即第三个文本显示是受限de
```

### 3.2 获取SELinux模式状态: **getenforce**



### 3.3 获取SELinux policy状态: **sestatus**

## 4. SELinux实际操作: semanage

> 大部分使用SELinux的情况是针对某些网络服务(比如修改默认端口/开放端口)的修改. 
>
> 为了检测到因为selinux的设置导致某网络服务无法运行, 需要使用selinux的错误探测服务: setroubleshoot, 也可以在log/messages里查询sealert

如果遇到读取权限或者网络设置问题, ,用系统logs文件里的提示可以检测是否与SELinux的设置有关.

###  4.1 查询安全文本的值

```
#semanage fcontext -l | grep dir
```



#### 4.2 查询SELinux当前允许的端口

```
# semanage port -l | grep serviceName, 例如ssh
ssh_port_t                     tcp      22, 表明目前即使在sshd_config下更改了搜索端口, 其允许的端口仍只为22
```



### 4.2 设置端口 

* 开放端口 (同时也需要开放防火墙的端口)

```
# semanage port -a -t http_port_t -p tcp portNumber
                     此处可以是其他网络服务的type,比如ssh_port_t
#semanage port -a -t ssh_port_t -p tcp 1234
```

* 关闭端口:

```
#semanage port -d -t http_port_t -p tcp portNumber
```

## 5. SELinux故障排除: **setroubleshoot**

* 首先安装故障排除app:

```
#yum install setroubleshoot setroubleshoot-server
#systemctl enable auditd.service
#systemctl enable rsyslog.service
#sealert -a /var/log/audit/audit.log
```

* 检测error log: 会在/var/log/message以及/var/log/setroubleshoot/*里有`sealert`以及`setroubleshoot`关键词
* 

# ===== 第二部分: APPArmor =====

Apparmor有两种工作模式：enforcement、complain/learning

* Enforcement – 在这种模式下，配置文件里列出的限制条件都会得到执行，并且对于违反这些限制条件的程序会进行日志记录。

* Complain – 在这种模式下，配置文件里的限制条件不会得到执行，Apparmor只是对程序的行为进行记录。例如程序可以写一个在配置文件里注明只读的文件，但Apparmor不会对程序的行为进行限制，只是进行记录。

那既然complain不能限制程序，为什么还需要这种模式呢，因为——如果某个程序的行为不符合其配置文件的限制，可以将其行为记录到系统日志，并且可以根据程序的行为，将日志转换成配置文件。

当然我们可以随时对配置文件进行修改，选择自己需要的模式。

###### APPArmor是Ubuntu下的默认MAC控制器

## 1. 查看APPA的状态

```
# cat /sys/module/apparmor/parameters/enabled
如果返回"y", 代表appa已开启
# apparmor_status
apparmor module is loaded.
61 profiles are loaded.
42 profiles are in enforce mode.
```

## 2. APPA Profile

默认APPA不限制app以及网络访问, 除非单独设置profile

##### 2.1 查询已设置的profile

```
# aa-status
```

