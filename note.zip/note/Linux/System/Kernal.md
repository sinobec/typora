

## 1. 内核的配置文件

位于`/etc/sysctl.conf`下