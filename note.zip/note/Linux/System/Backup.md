# 1. 备份内容

#### 1.1 系统数据备份

```
/etc/ 整个⽬录
/home/ 整个⽬录
/var/spool/mail/
/var/spoll/{at|cron}/
/boot/
/root/
/usr/local/ 或 /opt: 针对安装的第三方软件
```

#### 1.2 服务的备份

除了etc和user/local之外,还需要备份:

* webserver的: /srv/www以及/var/www
* 数据库的: /var/lib/mysql

无需备份:

* /dev. /mnt, /tmp, /proc,/sys,/run,/media

# 2. 备份的方式

## 2.1 文件的备份

#### 2.1.1 tar: 全系统备份

```
tar --exclude path1 --exclude path2 -jcvp -f targetPath sourcePath
#tar --exclude /proc -jcpvf /mynas/bck/sysbck01.tar.bz2 /
#tar -jcpvf  mysql.`date +%Y-%m-%d`.tar.bz2  /var/lib/mysql
```

#### 2.1.2 rsync: 针对特定文件夹备份, 也可以远程备份

```
rsync -av 来源⽬录 ⽬标⽬录
#rsync -av /etc /tmp, 本地备份
#rsync -av -e ssh /mysourceDir root@$123.45.6.7:/var/bck/targetDir
```



## 2.2 全系统备份

以扇区备份的方式, 可以备份包括dev等块文件. 

#### 2.2.1 全盘备份: dd

```
将/dev/sda全盘备份到容量一样的/dev/sdb
#dd if=/dev/sda of=/dev/sdb
```



#### 2.2.2 增量备份: xfsdump

# 3. 制定备份周期

编辑/etc/crontab

```
30 3 * * 0 root /backup/backupweek.sh 每周的备份
30 2 * * * root /backup/backupday.sh  每日的备份
```



# 4. 示例script

#### 3.1 本地备份

```
#!/bin/bash
# ====================================================================
# 使⽤者参数输⼊位置：
# basedir=你⽤来储存此脚本所预计备份的数据之⽬录（请独⽴⽂件系统）
basedir=/backup/weekly <==您只要改这⾥就好了！
# ====================================================================
# 下⾯请不要修改了！⽤默认值即可！
PATH=/bin:/usr/bin:/sbin:/usr/sbin; export PATH
# 设置要备份的目标⽬录
named=$basedir/named
postfixd=$basedir/postfix
vsftpd=$basedir/vsftp
sshd=$basedir/ssh
sambad=$basedir/samba
wwwd=$basedir/www
others=$basedir/others
userinfod=$basedir/userinfo
# 判断目标⽬录是否存在，若不存在则予以创建。
for dirs in $named $postfixd $vsftpd $sshd $sambad $wwwd $others $userinfod
do
[ ! -d "$dirs" ] && mkdir -p $dirs
done
# 1. 将系统主要的服务之配置⽂件分别备份下来，同时也备份 /etc 全部。
cp -a /var/named/chroot/{etc,var} $named
cp -a /etc/postfix /etc/dovecot.conf $postfixd
cp -a /etc/vsftpd/* $vsftpd
cp -a /etc/ssh/* $sshd
cp -a /etc/samba/* $sambad
cp -a /etc/{my.cnf,php.ini,httpd} $wwwd
cd /var/lib
tar -jpcf $wwwd/mysql.tar.bz2 mysql
cd /var/www
tar -jpcf $wwwd/html.tar.bz2 html cgi-bin
cd /
tar -jpcf $others/etc.tar.bz2 etc
cd /usr/
tar -jpcf $others/local.tar.bz2 local
# 2. 关于使⽤者参数⽅⾯
cp -a /etc/{passwd,shadow,group} $userinfod
cd /var/spool
tar -jpcf $userinfod/mail.tar.bz2 mail
cd /
tar -jpcf $userinfod/home.tar.bz2 home
cd /var/spool
tar -jpcf $userinfod/cron.tar.bz2 cron at
```

