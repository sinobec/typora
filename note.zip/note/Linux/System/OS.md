# 1.OS版本

* 查看核⼼版本: **uname -r**

* 查看发行版: 需要安装lsb :  **lsb_release -a**
  * 以上;两种信息同时获取: **hostnamectl**

* 设置时区: 

  * Ubuntu下:

    ```
    dpkg-reconfigure tzdata
    apt-get update && apt-get install ntpdate
    ntpdate pool.ntp.br
    apt-get install ntp -y
    ```

* 查询主机信息

  ```
  dig A 域名 +short : 显示A记录
  dig MX 域名 +short : 显示MX记录
  ```

  

# 2.环境设置文件加载:

#### 2.1 加载顺序

1. 首先加载全局设置文件/etc/profile (不要修改)

2. 其次login shell会依次加载以下设置文件里的一个:

   ~/.bash_profile

   ~/.bash_login

   ~/.profile

#### 2.2 重新加载bashrc: source

在更改过~/.bashrc文件后,比如添加alias命令,需要即刻使其生效, 即运行: `source ~/.bashrc`, 或 `. "$HOME/.bashrc"`

3. Non login shell仅读取 `. ~/.bashrc`, 该文件的核心内容是 `. /etc/bashrc`

#### 2.3 自定义cli: alias, unalias

需要将自定义cli的内容增加到:  `vi ~/.bashrc`

```
alias ll='ls -alF'
执行
source ~/.bashrc
```

# 3.硬件信息

#### 3.1 启动时加载信息查看: **dmesg**

系统在启动时会加载硬件, 相关信息可以利用 dmesg 命令来读取/

#### 3.2 系统硬件信息查看: **dmidecode -i *hdtype***

`dmidecode -t 1` , 可以列出全部硬件信息

# 4. Startup steps

### 1.1 加载BIOS信息, selftest. 通过加载BIOS可以获得各个开机启动的设备

## 1.2 读取位于首位的开机硬盘/usb里的MBR/GPT里的Boot loader程序, 比如grub2

每个OS所在的扇区都有专属于该OS的boot sector,也可以启动操作系统

##### 1.2.1 grub2的配置路径

centOS7位于`/boot/efi/EFI/centos`, 核心的配置文件为grub.cfg, 此文件不可被修改.

##### 1.2.2 自定义grub2配置

```
1. 修改/etc/default/grub文件,可以实现自定义参数,比如开机菜单显示时间
2. 配置生效: grub2-mkconfig -o grub.cfg
```

### 1.3 根据Boot loader的设置加载kernel. kernel检测硬件并加载drivers

此过程中Boot loader会先调用initramfs虚拟文件系统, 该系统可以被加载到内存里执行, 用来加载startup里所需的最核心模块, 比如raid,usb,lvm等, 这样bootloader就可以进一步访问硬盘.

### 1.4 kernel加载systemd, 初始化软件系统

  1. systemd执行sysinit.target对系统进行初始化

     ---- 加载核⼼功能、⽂件系统、⽂件系统设备的驱动

  2. 加载basic.target准备进入操作系统

     ---- 加载音频, 防火墙, SELinux, dmesg以及modules

  3. systemd执行multi-use.target里的各种服务

     ---- 在startup时就启动的服务,位于/etc/systemd/system/multi-user.target.wants/目录下. 因此将service在该目录下建立一个symbollink即可自启动之.

  4. systemd执行multi-user下的/etc/rc.d/rc.local文件

  5. systemd执行multi-user下的getty.target文件

  6. systemd执行graphical.target所需的服务



# 5. Startup时加载的配置文件

### 2.1 /etc/sysconfig/目录

在该目录下的配置文件会在开机时加载, 默认的配置包括:

Iptables, network-scripts等等



### 2.2 kernel加载模块

##### 2.2.1 加载/配置module的path: 有些服务需要自定义模块, 比如防火墙模块

/etc/modules-load.d/*.conf：单纯要核⼼载⼊模块的位置；

/etc/modprobe.d/*.conf：可以加上模块参数的位置



##### 2.2.2 查询已加载的module

```
显示已加载的module
#lsmod
查询模块具体信息
#modinfo modName
```



##### 2.2.3 手动加载/卸载module

```
加载模块
#modprobe modName
卸载模块
$modprobe -r monName 
```



# 6. Startup fix

#### 6.1 恢复root密码:

1. ```
   在开机菜单界面, 按"e", 此时会出现grub.cfg的内容. 
   移至类似于`linux16 /vmlinuz`那一行, 在行末添加 
   rd.break enforcing=0
   ctrl x
   #mount -o remount,rw /sysroot
   #chroot /sysroot, 暂时将/sysroot作为根目录
   #passwd --stdin root
   #exit
   #reboot
   开机后
   #restorecon -Rv /etc
   #setenforce 1 
   ```
   
   







1. 在开机菜单界面, 按"e", 此时会出现grub.cfg的内容. 
2. 移至类似于`linux16 /vmlinuz`那一行, 在行末添加`systemd.unit=rescue.target`
3. ctrl x进入rescue模式(需要root密码)
4. 