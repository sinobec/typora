

**~/.ssh** : 权限 (.ssh/) 必须是 700 

**~/.ssh/authorized_keys** : 权限则必须为 644 ，



/etc/ssh/sshd_config的几项设置:

PermitRootLogin no, 禁止root登录

DenyGroups nossh, 禁止这个组登录

DenyUsers testssh, 禁止这个账户登录