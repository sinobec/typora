# 1.log的类型

> 建议将/var/log放置于单独的分区

系统的log由两部分产生, 一是rsyslog.service, 另一个是systemd

## 1.1 rsyslog.service: 记录所有信息到硬盘

```
配置文件
/etc/rsyslog.conf: 指定各个服务的log file所在
/etc/rsyslog.d/: 其下自定义配置
```

###### 1.1.1 配置语法之服务分类

`authpriv.*    /var/log/secure`, 指的是对于authpriv服务的所有事件等级, 其log存于/var/log/secure里

​		kern: 内核

​		user: 用户

​		auth: 登录

​		authpriv: pam

​		systemd: systemd的服务

###### 1.1.2 配置语法之事件等级

`uucp,news.crit /var/log/spooler`, 指的是对于news服务, 其事件等级为crit及以上的, 其log存于/var/log/spooler里

​		0: emerg, 最严重错误, 系统接近崩溃

​		1: alert

​		2:  crit

​		3: err, 包括配置文件错误, 网络入侵

###### 1.1.3 定制log文件

如果按需定制, 讲特定的事件记录到特定的log文件里, 可以设置rsyslog.conf文件

```
添加
*.err /var/log/allerr.log
```



#### 1.2 设置rsyslog服务器与客户端

* 设置服务器端:

```
#vi /etc/rsyslog.conf
取消注释
$ModLoad imtcp
$InputTCPServerRun 514

#systemctl restart rsyslog
```

* 设置客户端

  ```
  #vi /etc/rsyslog.conf
  添加
  *.* @@140.238.51.195 ,此为server的ip
  #或者将不同类型的log发送至不同的server
  cron.* @10.1.1.15
  ftp.* @10.1.1.20
  #systemctl restart rsyslog
  ```
  
  

## 1.2 systemd-journald.service: 记录开机后的信息到/run/log/(即内存中)

```
#journalctl -optionA -optionB
例如
#journalctl -r --since "2021-21-01" --until "2021-25-01"
#journalctl --since yesterday --until today
```

OptionA:	

```
-n: 仅显示最新的log
-r: 按照从新的到旧的顺序显示
-f: 实时显示log
-p log等级: 例如: -p err, 可以显示遭受的网络攻击.
```

OptionB:

```
--since "时间"
--until "时间"
```

###### 1.2 1 讲journal的log文件另存为其他path

```
#mkdir /var/log/journal
#chown root:systemd-journal /var/log/journal
#chmod 2775 /var/log/journal
```

这样在重启systemd-journald之后就会将其永久保存该处

# 2. logrotate: /log文件的轮换

> Rotate: 指的是将旧的登录⽂件命名为旧⽂件， 并重新创建⼀个新的空的⽂件来记录log. 过于陈旧的log会被删除.

```
配置文件
/etc/logrotate.conf
/etc/logrotate.d/
```

# 3. 分析log文件

#### 3.1 集中管理log文件: logwatch

安装后该服务会自动倍设置在: /etc/cron.daily下, root账户可以利用 `mail` 语句来查询log.

 

















i