## 1. Install Elastic

```
rpm --import https://artifacts.elastic.co/GPG-KEY-elasticsearch
vi /etc/yum.repos.d/elasticsearch.repo
-->
	[elasticsearch]
	name=Elasticsearch repository for 7.x packages
	baseurl=https://artifacts.elastic.co/packages/7.x/yum
	gpgcheck=1
	gpgkey=https://artifacts.elastic.co/GPG-KEY-elasticsearch
	enabled=0
	autorefresh=1
	type=rpm-md

yum -y install --enablerepo=elasticsearch elasticsearch
```

#### 1.2. Config

执行文件路径: /usr/share/elasticsearch

配置文件路径:  /etc/elasticsearch

#### 1.3 配置环境

* vi  /etc/elasticsearch/jvm.options

```javascript
-Xms4096m
-Xmx4096m
#内存大小依据硬盘大小, 每GB约需2M内存
```

* vi  /etc/elasticsearch/elasticsearch.yml

  ```javascript
  node.name: node的name
  node.attr.rack: r1
  network.host: node的ip地址
  http.port: 9200
  discovery.seed_hosts: ["10.66.66.1", "10.66.66.2","10.66.66.3"]
  cluster.initial_master_nodes: ["node-1", "node-2","node-3"]
  ```

* vi /etc/security/limits.conf

```javascript
elasticsearch      soft    nofile  100000
elasticsearch      hard    nofile  100000
elasticsearch      soft    memlock unlimited
elasticsearch      hard    memlock unlimited
elasticsearch      soft    nproc   4096
elasticsearch      hard    nproc   4096
```

* /etc/sysctl.conf, 修改后 -> `sysctl -p`

```
vm.swappiness=10
vm.max_map_count=262144
```

＊　vi　/etc/hosts

```
10.66.66.1  node-1
10.66.66.2  node-2
10.66.66.3  node-3
```

开启进程

```javascript
systemctl start elasticsearch

systemctl daemon-reload
systemctl enable elasticsearch
```

#### 1.4　配置ｃａ证书

###### 1.4.1 在 /etc/elasticsearch 下编辑 elasticsearch.yml

```
transport.port: 9300
http.cors.enabled: true
http.cors.allow-origin: "*"
http.cors.allow-headers: Authorization
# 开启X-Pack的安全认证
xpack.security.enabled: true
# 开启X-Pack的集群内互信安全认证，与上面安全认证开关同步必开
xpack.security.transport.ssl.enabled: true
# 验证模式为证书模式
xpack.security.transport.ssl.verification_mode: certificate
# 配置证书路径
xpack.security.transport.ssl.keystore.path: elastic-certificates.p12
xpack.security.transport.ssl.truststore.path: elastic-certificates.p12
# 如果需要启用SSL/TLS通过HTTPS访问ES集群，再添加如下配置
xpack.security.http.ssl.enabled: true
xpack.security.http.ssl.keystore.path: elastic-certificates.p12
xpack.security.http.ssl.truststore.path: elastic-certificates.p12
xpack.security.http.ssl.client_authentication: none

discovery.seed_hosts: ["10.66.66.1:9300", "10.66.66.2:9300","10.66.66.3:9300"]
```

###### 1.4.2 在/usr/share/elasticsearch下执行：

```
bin/elasticsearch-certutil ca
bin/elasticsearch-certutil cert --ca elastic-stack-ca.p12
chown -R elasticsearch:elasticsearch *.p12
#将此文件连同属性copy到其他node的进程文件夹下, 然后在所有node执行
ln -s /usr/share/elasticsearch/elastic-certificates.p12 /etc/elasticsearch/elastic-certificates.p12
ln -s /usr/share/elasticsearch/elastic-stack-ca.p12 /etc/elasticsearch/elastic-stack-ca.p12
```

```
#restart elasticsearch
bin/elasticsearch-setup-passwords interactive
```

## 2. Kibana

#### 2.1 install

```
wget https://artifacts.elastic.co/downloads/kibana/kibana-7.8.0-x86_64.rpm
yum -y install perl-Digest-SHA
shasum -a 512 kibana-7.8.0-x86_64.rpm
rpm --install kibana-7.8.0-x86_64.rpm
```

进程文件: `/usr/share/kibana`

配置文件: `/etc/kibana`

#### 2.2 Config

* vi  /etc/kibana/kibana.yml

```
server.port: 5601
server.host: "0.0.0.0"
# 设置Elasticsearch集群地址，方便Kibana做容灾管理
elasticsearch.hosts: ["https://node-1:9200","https://node-2:9200","https://node-3:9200"]
kibana.index: ".kibana"
# 国际化设置，设置为中文
i18n.locale: "zh-CN"
# 开启X-Pack的安全认证
xpack.security.enabled: true
# Elasticsearch内置账户密码
elasticsearch.username: "kibana"
elasticsearch.password: "ESabc+2333" # 设置内置账户密码时kibana账户的密码
# Kibana SSL/TLS访问开启，若无需配置SSL/TLS，可忽略
server.ssl.enabled: true
server.ssl.key: /etc/kibana/kibana-certificates.key
server.ssl.certificate: /etc/kibana/kibana-certificates.cer
server.ssl.certificateAuthorities: /etc/kibana/kibana-certificates-ca.cer
server.ssl.clientAuthentication: none
# Elasticsearch如开启SSL/TLS访问，则需要配置如下两条规则
elasticsearch.ssl.verificationMode: certificate
elasticsearch.ssl.certificateAuthorities: /etc/kibana/kibana-certificates-ca.cer
```









































