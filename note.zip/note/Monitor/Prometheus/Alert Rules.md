## 1. Basic Concept

[^Network partition ]: 指的是网络里某组node处于非离线的挂起 (比如电脑休眠或虚拟机主机休眠), 导致与其他组node的网络通信失联. 但该组的node认为这是其他组的node失效导致.

##### 1.1 Group

* 记录大规模同类型发生的事件, 比如outages, 该类事件会导致相关地区的node同时出现大量alert.

* Network partition发生时, 至少一半的网络无法连接


