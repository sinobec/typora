## 1. 确定本地vpn网关类型

https://docs.microsoft.com/en-us/azure/vpn-gateway/vpn-gateway-about-vpn-devices

## 2. Azure

###### 2.1 新建VNET

###### 2.2 新建VNET下的subnet, 选择Gateway Subnet

###### 2.3 新建Virtual Network Gateway

​      选择SKU:　Basic最便宜

​      Route-base:默认，适用于大多数本地网关，比如windows server

###### 2.4 新建Local network gateway

​	1. ip address: 本地pip

​	2. Address space: 本地site的网段, 比如192.168.3.0/24 (可以添加多个), 不要与Zaure的Vnet网段重复?

​    3. resource group: 选择和上述资源相同的

## 3. Local

1. 打开RRAS management -> Deploy VPN only
2. 右键RRAS -> Configuration and Enable Route and remote access -> Secure connection between two private networks
3. Interface Name: Azure Local GW
4. VPN Type: IKEv2
5. Destination address: Azure Virtual GW的 pip
6. Static Route: 此处指向Azure GW端所处的全部VNet, 那么就需要填写2.10VNet的address space (比如10..0.0.0/16) , 否则Azure里的某些资源, 本地可能无法访问. 
7. metric为10. (本地网络的metric的value需要权衡)
8. Finished: then, on the “Options” tab select persistent connection to prevent the connection from automatically disconnecting.
9. 在RRAS -> IPV4里, -> static route, 新建, 重复第6步

## 4. Azure

1. 点击Local GW -> Connection -> New
2. 选择VirtualGW: 选择2.3的那个

## 5. Local

启用SSAS NAT

```
$ExternalInterface="External"
$InternalInterface="Internal"
cmd.exe /c "netsh routing ip nat add interface $ExternalInterface"
cmd.exe /c "netsh routing ip nat set interface $ExternalInterface mode=full"
cmd.exe /c "netsh routing ip nat add interface $InternalInterface"
```

