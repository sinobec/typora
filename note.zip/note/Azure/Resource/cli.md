



3. Delete RG

   ```
   Remove-AzResourceGroup -Name "name" -AsJob -Force
   ```

   

