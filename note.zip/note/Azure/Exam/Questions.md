## 订阅与资源管理

#### 订阅与权限

* 某个Global admin建立了新的AD后, 其他原AD的global admin不会自动获得对该AD的管理权限,比如在该AD内增加用户.

* 创建Azure AD用户: 只有AD里的Global admin & user admin才可以, Azure的Owner不可以. 

* **RG里的服务的操作(比如LB添加backpool)**:  需要有rg的network contributor权限, 而不是lb的net con权限

* VM contributor: 只能管理VM, 不能管理VNet, 因此要创建完整的VM, 至少需要Contributor

* **kubectl授权用户可以登录**: 使用Azure AD客户端应用程序通过OAuth 2.0设备授权

* 只有Office 365 group支持到期自动删除成员功能,到期后mail/site都将被删除

* 邀请外部协作者访问: 需要在Users -> User settings -> External collaboration里设置

* **Contributor role**: 可以 管理所有的resources (and add resources) in a Resource Group

* 分配给用户新的role: 在AD根下 -> user -> 点击user->Assign role-> **Directory roles**里挑选role

* Azure AD里无法修改local AD user的个人信息(除location外)

* 修改重置密码的安全问题所需的权限: AD Global admin role

* 指定**订阅的service admin**: 在订阅的属性一项里修改/指定

* **允许Traffic Analytics所需权限**: 至少是reader

* **分配policy给AD的root manage group**: 只有Owner才可以

  

####  Policy

* 制定策略时, 如果Scope里有设置exclusion, Basic里设置了NotAllowed, name值得就是"只有exclusion里的那个scope才可以做的"

* **设置conditional access policy**: 必须包括User + Cloud app(应用到的对象) + Grant(所需的具体操作). 比如要求财务部必须使用MFA, 就素要首先指定user为财务部, 然后在cloud app里设置为<u>用户设备注册登录</u>, 最后在grant里指定为要求MFA

  

  #### 资源管理

* RG的tag不会被group内的资源继承

* 移动资源到**新的订阅**时, 也可以移动Recovery Vault

* 分配License: AD -> license -> All product -> 挑选lic分配

* 添加Admin账户给所有新设备: 在AD -> device项目里设置

* **Assigned Group**: 其成员只有在初次分配时才存在其中, 之后需要添加的user需要被手动添加, 比如Assigned O365组成员.

* **Dynamic group:** 不可以手动添加成员到改组. 只能通过添加成员到Assigned group的方式

* RG有readonly的lock时: 其他rg的资源可以移入此处,但该rg里的资源不可以移出

* 当查看rg中多个利用模板部署的资源的源模板时: 只能在RG->Deployment里查看

## 存储

* **三种存储账户**: GPv1, GPv2和Blob storage, 前两个支持全部类型存储, 后面的Blob storage只支持块blob. 存储Docker映像需要放置在blob里
* **Export service**:  仅支持从**Blob storage**导出export data 
* **import service**: , 支持**Blob storage & Azure Files**. 需要准备dataset csv和driveset csv文件
* **访问Blob权限**: 支持Azure Active Directory或SAS验证
* **访问file权限**: 只支持SAS
* azCopy:只能拷贝数据到**blob和file**类型的存储里
* SAS: 可以设置有效时间,ip源等
* 存储账户的url一般为: file(blob).core.windows.net
* 当在server point里创建和cloud point同名文件时, 云终结点里的文件不会被覆盖,而是会被重命名.
* 存储冗余: LRS->在同一个zone里做个3备份; ZRS->在同一个region里的3个不同zone的数据中心各做一个备份; 
* Live migration: 实时迁移转换为ZRS的, 只支持从同一个region, 且只支持GPv2
* **限制对存储账户的网络访问**:  在存储账户的 -> networking -> 选择Selected Network(此处选择VNet) 以及 Firewall下选择IP range(此处选择外网允许的ip)

## 监控

* **IT 服务管理连接器 (ITSMC)**: 建立监视警报, 包括利用 Azure  Alert在 ITSM 中创建 (指标警报、活动日志警报和 Log Analytics 警报) ; 选择将 ITSM 中的事件和更改请求数据同步到 Azure Log Analytics 工作区
* 查询Log analysis workspace里的表格内容(比如error): **`tableName | search "error"`**
* Advisor: 可以协助监控资源的使用情况, 探查**未被充分使用**的资源
* **记录VM的某时段内的几个以上的error事件**: 需要1. 创建Log Analytics workspace并配置数据; 2.在VM上安装Monitor agent; 3.在Monitor中创建Alert，并将Log Analytics工作区指定为源
* 警报规则: 监控的数据来自于Log analysis workspace
* 警报规则Alert rule和操作组Action group: 每一条触发都需要建立单独的alert rule; 若组员相同,可只建立一个action group
* **监控VM的进出流量**: 1.Enable Network Watcher; 2.Register Insights provider; 3.Enable <u>NSG flow log</u>; 4.在相关的存储账户里的container里可以看到一个insight.xxx的账户,点击到尽头会看到一个p1h.json,这就是log.

##### Network Watcher工具的区别:

* Monitoring -> **Connection Monitor**: 监视Azure内部资源之间的连接,唯一可以监控RTT
* Monitoring -> **Network Performance Monitor**: 监控Azure内部以及Azure和Local之间的连接
* Diagnostic -> **ip flow**: 针对连接到单个VM的连接诊断
* Diagnostic -> **Connection trouble**: VM之间的连接诊断

## VM

* Availability set: 位于同一个zone内, 通过多个<u>更新域</u>和<u>故障域</u>提供冗余. 默认提供5个更新域,3个故障域. 使用此设置的VM必须使用managed disk

  Available zone: 提供同一个region里3个数据中心的备份

* 同一region不同zone之间的VM可以互通

* **移动App Service plan**: 移到另一个位于不同region的RG后, App Service plan仍保留在原物理区域

* **<u>通过模板部署VM: 配置期间,  可以调整admin的名字</u>**

* **VM的Runbook**: 可以调整VM的大小,以提高VM性能.

* 当VM收到维护的影响时, 需要重新deploy这个VM(到不同的更新域)

* VMss: Expand mode为auto时, 更改vm尺寸会立即应用到set里所有的vm. 

  ​			 enableAutomaticUpdate为false时, OS更新每次只能有总数量的1/4的vm来进行.

* 无法将VM里的App迁移到另一个vnet: 需要先删除VM，保留磁盘(因为磁盘里有app的数据)，在VNet2中创建新的VM（然后重新连接磁盘

* ASP.Net: 仅适用于Windows

* VM app的**pre-deploy**: 首先要修改模板的Extension, 然后将脚本上传

* **Automation DS**C**: 目的是post-deploy,确保众多VM都安装有所需app, 以及都具备同样的运行环境. 设置步骤1：将配置上载**到Azure自动化状态配置; 2:将配置**编译**为节点配置; 3:将虚拟机加载到Azure状态配置; 4:分配节点配置; 5:检查节点的合规性状态。

* **VMss的两种orchestration modes**: ScaleSetVM(instance的缩放由SS来管理); VM (VM单独建立,但是可以将其添加到VMss)

* **为Vmss配置的proximity placement groups**: 需要和VMss位于同一region. ppg的目的是使虚拟机尽可能靠近，以实现低延迟

* 当Windows设备加入Azure后, Azure AD里的Global admin会默认成为win10的管理员.

* **让device加入到azure AD时,需要设置MFA等安全策略**: 搜索Conditional Access, 在policies里设置MFA等

* **对多台VM(nsg)赋予同样的规则**: 在rg的policy里设置custom policy(需要先在服务->policy-definition里自定义该规则),如果有合适的内置规则也可以启用.

* k8s自动缩放: kubectl autoscale, 然后az aks update

* 生成并推送容器img到Azure reg: az acr build

* 要在本地安装kubectl: 使用az aks install-cli命令

##  Networking

* Application Gateway: 作用是将"来访流量"以特定规则导向后端App, 在其后可以接LB
* 当在VNet所在的RG设置了以下notAllowed policy后 (Microsoft.ClassicNetwork/virtualNetworks, Microsoft.Network/virtualNetworks, Microsoft.Compute/virtualMachines) , 该VNet的address space将不可被更改. 但是可以将其他Vnet移动到此RG
* P2S VPN: 在每一个client PC上都需要有个cert证书, 该证书可以首先在某台机器上生成,然后导出为.pfx, 再copy到其他机器上安装之. 这个cert证书在Azure端进行配置VPN GW的时候也需要被导入.
* NSG的in规则: 可以单独针对来自Internet的流量. 方法是在source里选择service tag.该方法还可以将流量源设置为Azure里的很多服务.
* **将VM加入到某ASG**: 在VM->Networking菜单里,点击asg的tab, 实际上是将'<u>挂载到该VM上的nic'</u>与asg相关联
* 在已经配置好的VPNVnet里,如果改变了topology,那么之前已经下载过的P2Svpn客户端需要重新下载.
* **在Subnet级别设置的nsg rule**: 将自动应用于位于该子网内的所有NIC, 即所有VM. 因此如果在Subnet的nsg设置了允许rdp, 那么单独的VM就无须重复设置改规则. 
  * 但此时如果在VM级别设置了更详细的规则, 则该规则会起作用.
* 迁移本地的DNS zone至Azure DNS zone: 使用Powershell自带的迁移脚本, install-script PrivateDnsMigrationScript
* **如果要使web app得以访问某个VNet里的VM**: 需在该Webapp的Networking->VNet Integration设置里, 将其连接到那个VNet
* LB 端口转发: 可以设置LB的NAT转发规则, 以设置端口转发. 在LB->inbound NAT rule里,添加源ip/端口协议/目标VM
* **LB的basic类型**: 只可以将位于同一个 availability set 或者VMss里的VM加入到load balance. LB位于VNet里的一个subnet之上, 但是可以针对整个VNet进行负债平衡 - 需在backpool里添加符合要求的VM.
* **DNS zone**: 在Azure里有两种DNS zone. DNS zone(其实指的是public DNS zone), 另一个是Private DNS zone. 只有Private DNS zone可以实现: virtual network link和auto registration功能(两个功能在同一个页面). ()

