## 1. Link

https://towardsdatascience.com/getting-started-with-sql-server-management-studio-part-1-step-by-step-setup-63428650a1e0