## 1. WAC

Windows Admin Center, 基于网页的Server管理, 可添加第三方插件, 也可以进行网页的RDP

#可以和Azure互联, 

```
 Settings. → GATEWAY | Azure -> Register
 Network-> Azure network adpater
```

##### 1.2 设置权限

对于操作机和目标远程机不再同一个域的情况, 需要将操作机添加到本地机的TrustedHost里

```
set-item wsman:\localhost\Client\TrustedHosts -value myPCame #只能使用DNS name, 不可以用ip
set-item wsman:\localhost\Client\TrustedHosts -value *       #允许所有的操作机链接到此目标机
get-item wsman:\localhost\Client\TrustedHosts  #查看结果
```

在目标机上设置GPO

```
Computer / Policies / Administrative Templates / Windows Components / Windows Remote Management (WinRM) / WinRM Service | Allow remote server management through WinRM
```



## 2. RSAT: 不占用 rdp

Remote Server Administration Tools, *

##### 2.1 连接

* 首先开启remote 修改firewall支持:

  ```
  Netsh advfirewall firewall set rule group=”Windows Defender Firewall Remote Management” new enable =yes
  ```

* 远程机需要在防火墙inbound里, Enable -> COM+ NetworkAccess; Enable所有的Remote event log rules

  ```
  netsh advfirewall firewall set rule group=”Windows Management Instrumentation (WMI)” new enable=yes
  netsh advfirewall firewall set rule group=“remote event log management” new enable=yes
  ```

  

* 在Rsat添加server后, 需要在本地机将远程机添加到TrustedHost里

  ```
  #先查看是否已经添加
  get-item wsman:\localhost\Client\TrustedHosts
  
  #添加
  set-item wsman:\localhost\Client\TrustedHosts -value SERVERName
  ```

＊　在RSAT里选择远程机，右键-＞Managed By: 填写完整用户名(Server01/Administrator)及密码

## 3. Active Directory Administrative Center

##### 3.1 Installation:

需要在File Server里添加 Resource Manager role
