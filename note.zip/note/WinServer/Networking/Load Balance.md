#### 1. Windows Built-in NLB

针对stateless类型/role的服务器的redundancy，比如Web server或DA server。

> Unicast模式：如果switch或者router不支持Multicast，只能选择这个模式。

每个NIC都可以配置为NLB的一个组成部分，所有NLB中的NIC都有一个共同的virtual MAC addr。此时如果客户端发送一个数据到其中一个NIC的IP地址，ARP table将会根据唯一的这个Virtual MAC address，将该数据发到所有的NLB中的NIC上。

- 优点： 配置简单
- 缺点： 会影响NLB中各个NIC之间的通信（因为彼此的MAC地址相同）；会引起switch flooding。

> Multicast模式：适用于server只有一个NIC，但需要switch和router的支持。

在有避免switch flooding的需求时，可以设置为该种模式。Multicast将NLB里的NIC组成了一个VLAN，每个NIC将被分配一个新的唯一的MAC addr；这就需要登录到switch上以便建立新的static ARP table。

#### 2. 配置NLB

> ##### Enable NLB：

1. Enable MAC address spoofing：（用物理网卡作为组件的server不需要该步骤） 目的是建立Virtual MAC address。需要在每一个VM上的NIC上挨个进行设置。
2. 打开其中一个服务器。
3. Server - Tools： 打开NLB
4. 右键 - New Cluster
5. 输入本机的name（FQDN的前缀） - connect， next
6. Add IP Address： 输入NLB的IP地址， next
7. 选择NLB的mode
8. Filtering mode默认的是Multi host。如果需要限制port，选择port后，选择Disable this port range。
9. Finish
10. 在NLB manager里新的Cluster，右键选择Add host to cluster
11. 重复以上步骤
12. 在每个服务器的NIC的TCP/IP属性里，可以看到至少两个IP地址。
13. 有必要的话，flush ARP table的cache。

- 添加具备NLB的site
  1. 在IIS里，右键site，edit binging，将IP地址改为NLB的地址
  2. 在DNS server里，新建A记录，指向NLB的IP地址。

> #### Remove NLB：

如果需要将某个服务器从NLB里移除，在NLB manager里右键删除host。