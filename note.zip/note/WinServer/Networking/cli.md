##### 1. ping： icmp，端口23

##### 2. tracert

##### 3. pathping: ping + tracert

### 4. **tcpdump**

在Windows下的应用包括netsh, pktmon:

###### 	4.1 **netsh**:

```
netsh trace start capture=yes
#停止
netsh trace stop
```

捕捉文件保存为epl, 可以通过Windows Network Monitor打开

###### 		4.2 pktmon

```
pktmon start --capture
#Stop
pktmon stop --capture
```

添加过滤端口: `pktmon filter add -p portNumber`

捕捉文件保存为epl, 可以通过Windows Network Monitor打开

### 5.**route & netsh** 

* netsh: 主要用来设置网络tcpip地址

  显示网卡id:

  ```
  netsh interface ipv4 show interfaces
  ```

  设置ip地址:

  ```
  netsh interface ip set address name="本地连接" source=static addr=192.168.2.123 mask=255.255.255.0 gateway=192.168.2.1 gwmetric=0
  ```

* route:用来设置iptable

  ```
  route print
  # 是
  route add -p 192.168.16.0  mask 255.255.255.0  10.10.10.1  metric  1  if 5
  ```

  

### 6. Test-Connection

 	Test-Connection *target，* 类似ping，但是可以指定特定的源以及多个源，还可以指定多个目标。

```
Test-Connection -Source DC1, AC1 -ComputerName DA1 
```



##### 7. telnet： 在大部分server 屏蔽了ping的情况下，可以使用telnet。同时该命令还可以探测远端端口：

`telnet *target portNumber*:` 当连接成功时，会转到空窗口

##### 8. Test-NetConnection： 同样可以探测远端端口，

```
Test-NetConnection target -port portNumber 
```

##### 9. Wireshark / Message Analyzer： 详细网络探测工具

##### 10. TCPView ： 显示所有已经建立的tcp/udp连接

