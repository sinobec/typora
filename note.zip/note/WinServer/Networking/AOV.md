# VPN Basic

#### 1. IPSec 

https://www.cndba.cn/dave/article/3240

> IPSec: 需要开放UDP 500乃至UDP 4500端口. Intemet Protocol Security是端到端IP层通信的确保安全机制，包含一组协议。最主要的应用是构造虚拟专用网（VPN），它作为一个第三层隧道协议实现了VPN通信，可以为IP网络通信提供透明的安全服务，保证数据的完整性和机密性，它所使用的加密算法和完整性验证算法从目前看来是不可能被破解的

###### 1.1.1 IPS:ec的协议

1. **AH**: 数据完整性验证. 通常使用, 但在使用NAT的环境中，AH可能会遇到问题。
2. **ESP**: 包含AH的完整性验证, 同时提供数据加密 (由于需要使用高强度的加密算法，需要消耗更多的计算机运算资源，使用上受到一定限制). 使用ESP认证, 需要同时选择一种加密算法.
3. **IKE**:  Internet Key Exchange

###### 1.1.1 IPSec的模式

1. **传输模式**: 默认模式,又称端到端（End-to-End）模式，它适用于两台主机之间进行IPSec通信。
2. **隧道模式**: 常用. Tunnel Mode使用在两台网关之间，站点到站点（Site-to-Site）的通信。参与通信的两个网关实际是为了两个以其为边界的网络中的计算机提供安全通信的服务。只要使用IPSec的双方有一方是安全网关，就必须使用隧道模式. 可以隐藏内部主机和服务器的IP地址。大部分VPN都使用隧道模式，因为它不仅对整个原始报文加密，还对通信的源地址和目的地址进行部分和全部加密



### 2. PPTP

易被破解, 已过时

### 3. L2TP

其本身不进行加密, 一般和IPSec配合使用. 该协议使用upd 500, 传输速度慢于OPENVpn

### 4. OpenVPN

https://openvpn.net/oracle-quick-start-guide/

OSI Layer 3. 是一种SSLv3 VPN, 可随意配置端口. 其使用的OPENssl资料库**(即隧道类型为OpenVPN (SSL)**)可使用各种主流加密方式(但一般使用AES/BLOWFish). 

传输速度快于IPSec, 需要安装客户端.





## [Configure Windows 10 Client Always On VPN Connections](https://docs.microsoft.com/en-us/windows-server/remote/remote-access/vpn/always-on-vpn/deploy/vpn-deploy-client-vpn-connections)

[Configure Windows 10 Client Always On VPN Connections](https://docs.microsoft.com/en-us/windows-server/remote/remote-access/vpn/always-on-vpn/deploy/vpn-deploy-client-vpn-connections)

> 和DirectAccess的区别 1.该方案适用于可以不加入域的设备，包括各种平台的移动设备。而DirectAccess要求设备必须加入域。 2. 该方案常用User tunnel，导致在用户Login之后才能建立VPN连接，此时VPN远程连接将不能控制比如登录密码等issue。而DirectAccess可以在Login之前就能建立连接。

* 优势：

  AOV允许用户使用安全的通信方式获取服务器上的资源，处理邮件，操作App，也允许对户外设备进行GPO和SCCM（system center configuration manager）的管理。

* 劣势：

  早期的VPN只能在用户登录到系统后，手动打开VPN app后才能连上。这就意味着一些依赖于在登录时就需要进行的一些公司内部的操作（比如GPO和登录脚本）将无法在正确的时机被执行。

* AOVPN的优势：

  由于AOVPN是在网络建立时就立即连接，所以在用户登录之前就可以开启vpn通道。该VPN可以自动识别公司内网的DNS suffix， 这样就会在内网连接时不启动VPN，而在外网时始终启动。

* 部署要求：

```
Win10 1607及以上，域设备
```



* 触发条件:

  ```
  联网
  application triggering： 启动某程序
  DNS触发，一般也是在启动特定程序时激活了某DNS解析。
  ```

##### Tunnel类

```
User Tunnel: 常用。由internal PKI进行验证。由于该验证是基于用户的Auth，所以无法在用户登录前开启。
Device Tunnel：也是由internal PKI签发验证，但是是基于device auth，因此可以在用户登录前开启。该方案要求该设备需要加入Domain， 被签发machine certificate， OS至少为Win10 1709并且是企业版或者Edu SKU，Tunnel只能是基于IKEv2。 
```



## 2. AOVPN的组件：



- **IKEv2**： 最好的连接类型，***Device Tunnel***使用的唯一连接形式，由于需要得到Certificate，因此设备必须加入Domain。 必须通过**UDP port 500和4500**建立连接，因此在某些特殊场合，当网络环境的防火墙屏蔽了相关端口时，将无法建立连接。
- **SSTP**： fallback method形式。使用SSL证书建立连接，因此需要事先在Remote Server上授权证书，但无需在终端设备上授权证书。该方法使用**TCP 443**建立连接，适用于各种公私网络场景。
- L2TP, PPTP: 不常用。尤其是PPTP缺少足够的安全性。
- CA： 需要在环境里有至少一个CA server以便颁布证书，也需要在环境里有PKI
  1. **User certificates**: 适用于***User Tunnel***。These are the certificates issued to your VPN users from an internal CA
  2. **Machine certificates**: 适用于D***evice Tunnel***。These are certificates issued to your workstations (mostly laptops) from an internal CA
  3. **SSL certificate**: 适用于***SSTP VPN connections***。Installed on your Remote Access Server in order to validate the incoming traffic.
  4. **VPN and NPS machine certificates**: **Remote Access Server以及NPS servers**所需，由CA颁布.
- **Network Policy Server (NPS)**：外部链接进入时，由该服务器进行判断该用户是否有权限登录VPN。

##### 配置：

在安装DirectAccess时，可以选择同时安装VPN，VPN Configuration的配置内容主要是IP地址分配。