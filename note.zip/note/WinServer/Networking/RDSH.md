> #### Roles组件：

- **Remote Desktop Session Host**: This is the most common type of RDS server, as it is the one hosting the programs and sessions that users connect to. Depending on the size of your environment, there may be many of these servers running concurrently.
- **Remote Desktop Connection Broker**: This is like the load balancer for RDS servers. It distributes users evenly across RDSH servers, and helps users to reconnect to existing sessions rather than creating fresh ones.
- **Remote Desktop Licensing**: This is responsible for managing the licenses that are required for RDS use in a network.
- **Remote Desktop Gateway**: This is a gateway device that can bring remote users out on the Internet into an RDS environment. For example, a user at home could utilize the connection provided by an RD Gateway in order to access work information.
- **Remote Desktop Web Access**: This enables users to access desktops and applications by using the local Start menu on their Windows 7, 8, or 10 computers. Users can also utilize this to access applications via a web browser.
- **Remote Desktop Virtualization Host**: This is a role that integrates with Hyper-V in order to provide virtual desktop sessions to users. The difference here is that resources given to those users are spun up from Hyper-V, rather than shared resources such as an RDSH.

#### ｜Installation first RDSH server： 不能安装在AC server上

```
  1. Add roles and features
  2. 选择Remote Desktop Services installation
  3. 选择Standard deployment
  4. 如果不是和HyperV集成，就选择Session-based desktop deployment
  5.  初次安装时会只有一个server，所以在这个步骤以及之后的两个步骤，将唯一的server加入
  6. 勾选安装后restart
  7.  deploy。重启后会继续安装。
  8.  完毕
```

### * 安装多个RDSH server：

```
   1. 在第一个RDSH server上，选择Add other servers to manage。 输入服务器名，添加
   2. 然后点击Remote Desktop Services
   3. Add RD Session Host servers。 此时会立即出现刚才添加的服务器，next， 选择restart， add。
```

### * 在客户端上访问RDSH

```
    在客户端上打开浏览器，输入： [<https://rds1/rdweb>](<https://rds1/rdweb>)。 或者在客户端上运行Remote Desktop Connection tool，输入计算机名（为RDSH的名字）。
```

#### ｜ 在RDSH上安装App：

```
 1. 首先将RDSH置入Install Mode
 2. Start = Program - Install Application on Remote Desktop
 3.
```