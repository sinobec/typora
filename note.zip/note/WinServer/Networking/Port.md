> 常用端口

1. Windows server下

   ```python
   111: RPC远程调用
   113: Windows Authentication
   135: RPC远程调用，控制ie浏览器以及excel远程编辑
   137: Netbios使用，查询PC name和IP
   138: Netbios使用,获得PC name，进一步获得IP
   139：Netbios使用,共享文件打印机使用的端口
   161 : SNMP使用该端口
   445: 类似于139， SMB
   3389: RDP
   ```

2. 邮件服务

```python
25: SMTP
110: POP3
143: IMAP
```

1. 网络连接

```python
23: Telnet
53: DNS, UDP
67: DHCP
1080: Socks代理
```

1. 数据库

```python
1433: MS SQL Server TCP
1434: MS SQL Server UDP
3306: MySQL
```

1. 相对于VPN，DirectAccess DA需要客户端必须加入domain，因为DA的设置是通过Domain GPO传递到客户端的。

2. Remote Access的一个role叫Web Application Proxy (WAP)。其用途是允许外界访问Excange或Sharepoint的Web-based资源。

3. DA server通常需要2个NIC。

4. **Multi-Site DirectAccess**： Windows 8以上的系统得以访问基于Multi-Site DirectAccess技术的DA server，即可以依据就近原则访问几个分布在不同地理位置的DA服务器，这几个servers可以组成DA array。但WIndows 8以下的操作系统只能访问Primary server。

5. IPv6 convert to IPv4：

   IPv4: 32bit, 分成四段，每段8bit，由decimal DEC表达。比如192的二进制是11000000. IPv6: 128bit， 分成8段，每段16bit， 由HEX表达。前四段即前64bit代表路由信息；后四段代表device ID。 第一部分的前3段代表组织的prefix，第四段的16bit代表subnet ID。

   - ipv4地址转换为ipv6地址：将ipv4转换为hex,由于只有32bit，所以将ipv4的32bit hex放置到后面两段，之前用0填充。由于0000在ipv6里可以被忽略，所以之前的两段可以写为:0000:0000: ⇒ ：：

   利用6to4, Teredo, IP-Https技术可以将IPv6数据包封装到IPv4 Header里。由于DA数据包在网络里是以IPV6的形式传播，到达DA server后会被转换为IPV4数据包（加入DA服务器配置为IPv4）。 Teredo利用UDP的3544端口封装，具备较好的宽容度，允许WIndows 8以下的操作系统以较快的湿度转换为IPv4。但Teredo无法在NAT下运行，因此服务器需要2个连续的外部IP地址的NIC。 6to4利用Protocol 41封装。 IP-Https则在封装的基础上，进行TLS加密，并以https的协议进行传输。

6. internal PKI： 对于Windows 7及以下，需要internal PKI。但为了更高的安全性，建议使用internal PKI。

> AD所需端口   ;

445: 用户登录与验证身份时会用到的连接端口,计算机登录与验证身份时会用到的连接端口,建立域信任时会用到的连接端口,两个域内的域控制器在验证信任关系时会用到以下的服务

AD用户密码修改：464/TCP

Microsoft-DS traffic : 445/TCP 445/UDP

Kerberos : 88/TCP 88/UDP

LDAP ping : 389/UDP