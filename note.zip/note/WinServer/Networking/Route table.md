## 1. 显示route table:

* Windows

  ```
  route print
  ```

* Centos 下

  ```
  ip route show
  route -n
  ```
  

## 2. 添加route table

- Windows

  ```python
  route add -p 192.168.16.0   mask 255.255.255.0   10.10.10.1   metric  1          if 5
               目标网段                              源网段的GW    路由跳数，低则高优先   内网网卡
  ```

* centOS下:

  ```
  ip route add 172.16.5.0/24 via 10.0.0.101 dev eth0 (临时的)
  vi /etc/sysconfig/network-scripts/route-eth0, 添加172.16.5.0/24 via 10.0.0.101 dev eth0
  ```

- powershell

  ```python
  New-NetRoute -DestinationPrefix "192.168.16.0/24" -InterfaceIndex 5 -NextHop 10.10.10.1
  ```


## 3.Delete toute table:

```
#192.168.50.57 route delete 0.0.0.0 mask 0.0.0.0 192.168.0.1
```

