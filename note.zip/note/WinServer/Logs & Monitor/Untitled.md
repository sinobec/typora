# Basic - Windows Event Viewer 

## 1. 建立Event Monitor Task





# [应用案例]

## 1. 监控Windows Updates

利用wsus的event ID事件记录来监控update是否正确安装

```
Event ID 18 : shows that an update has been downloaded and is pending installation. It also shows the scheduled installation's date and time. 
Event ID 19 : shows the successful installation of an update. 
Event ID 21 : shows a successful installation that was unable to restart due to a logged-on administrator. 
```

