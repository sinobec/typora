## 1. Prometheus

Windows监控利用的是WMI Exporter(普通windows host的dashboard与server有差别). 需要开启9182端口.

##### 1.1 在Windows设备上操作:

1. 下载Windows Exporter: https://github.com/prometheus-community/windows_exporter

2. 安装&验证运行状态: http://localhost:9182/metrics

   

##### 1.2 在Prometheus服务器上操作

编辑 vim  /etc/prometheus/prometheus.yml

```
- job_name: 'DC01' 
  scrape_interval: 6s
  scrape_timeout: 5s
  static_configs: 
     targets: ['135.84.23.150:9182']
```

systemctl restart premetheus



## 2. Logs

Use CMTrace to read log files

## 3.Eventviewer
