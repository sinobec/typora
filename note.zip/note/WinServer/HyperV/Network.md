## 1. Vitual Switch

##### 1. External: 

和物理网卡连接