## 1. 创建GPO

> **GPO的优先级**(依次递减): GPO执行的顺序是按照以下顺序的逆序, 因此Enforced GPO最后被执行, 导致最终生效
>
> ```
> 1. Enforced GPO 
> 2. OU内部各分支 
> 3. OU  
> 4. Domain  
> 5. Site  
> 6. Local
> ```

* **设置OU范围的GPO**: 在Domain User Computer菜单创建OU后, 在GPO界面里可以看到新建的OU. 在此OU下可以创建针对该OU范围的GPO.

* **创建单独的GPO Object**: 在Group Policy Objects文件夹下新建项目, 然后将其Link到相关项目(比如OU里)

#### 1.1 GPO的Inheritance

默认会继承上一级的GPO, 可以在OU内部分支下, 右键"block inheritance"

#### 1.2 Update GPO

```
net time \\server01 /set
gpupdate /force
```



## 2. 过滤GPO

1. **Scope**: 删除原有的authenticate,新增对应的group

2. **Delegation**: add, 选择authenticate users,权限选择Read ， Apply group policy.

   > 有的情况下，设置了GPO给某个特定的Group，但是又会设置其中的个别成员不受该GPO的限制。此时可以在Delegation里添加这几个成员，并将其Advanced里的权限设置为Read → Allow,  Apply group policy → Deny.

3. WMI filter. 利用query来定制更细致的GPO filter. 在GP manager里右键WMI filter->New, Add query. 举例:选择所有非laptop

   ```
   Select * From Win32_OperatingSystem Where Not (CSName like '%LAPTOP%')
   ```

   然后点击某GPO, 右侧最下方可以选择之前建立的WMI filter

## 3. 查看GPO结果

在`gpupdate /force`后, 在客户端运行`gpresult /r

## 4. 案例

1. 部署App

2. 设置用户安全

3. 监视用户login/off

4. 设置防火墙:  可以设置Inbound等通常的防火墙Rules

   ```
   Computer | Configuration | Policies | Windows | Security| Windows Defender Firewall with Advanced Security | Windows Defender Firewall with Advanced Security
   ```

5. 设置Autoenroll cert

6. 允许用户安装app而无需输入密码

7. 安装网络打印机

   ```
   User Configuration | Preferences | Control Panel Settings->右键Printer
   ```

8. 为user设置VPN profiles

   ```
   User Configuration | Preferences | Control Panel Settings->右键 Network Options -New | VPN Connection
   ```

   
