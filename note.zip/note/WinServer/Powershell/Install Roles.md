#####  Install Role/Features

```
Get-WindowsFeature       #list已安装Roles
Install-WindowsFeature   #安装Roles

```

e.x:

```
#安装Domain Controller
Install-WindowsFeature -Name AD-Domain-Services,GPMC -computerName ContosoDC1 -IncludeManagementTools -Restart

#卸载Role
Uninstall-WindowsFeature -Name AD-Domain-Services,GPMC -computerName ContosoDC1 -IncludeManagementTools -Restart
```

ess "192.168.50.79" -AddressFamily IPv4 -PrefixLength 24 -DefaultGateway "192.168.50.1
   ```

   ```
   Set-DnsClientServerAddress -InterfaceAlias Ethernet0 -ServerAddresses "192.168.50.1"
   ```

   