##### 1. 批量建立AD user: 从csv中取得数据

```
Import-Module ActiveDirectory

$import_users = Import-Csv -Path sample.csv
#假设csv有如下columns:
$import_users | ForEach-Object {
    New-ADUser `
        -Name $($_.FirstName + " " + $_.LastName) `
        -GivenName $_.FirstName `
        -Surname $_.LastName `
        -Department $_.Department `
        -State $_.State `
        -EmployeeID $_.EmployeeID `
        -DisplayName $($_.FirstName + " " + $_.LastName) `
        -Office $_.Office `
        -UserPrincipalName $_.UserPrincipalName `
        -SamAccountName $_.SamAccountName `
        -AccountPassword $(ConvertTo-SecureString $_.Password -AsPlainText -Force) `
        -Enabled $True
}
```

#### 2. 建立单个User

需要手动输入用户名

```
#### Import AD
Import-Module ActiveDirectory

#### Setup new user var
$firstName = Read-Host -Prompt "First Name "
$lastName = Read-Host -Promt "Last Name "


New-AdUser `
    -Name "$firstName $lastName" `
    -GivenName $firstName `
    -Surname $lastName `
    -UserPrincipalName "$firstName.$lastName" `
    -AccountPassword (ConvertTo-SecureString "123456Gp" -AsPlainText -Force) `
    -Path "OU=Domain Users, OU=CONTOSO, DC=contoso, DC=local" `
    -ChangePasswordAtLogon 1
    -Enabled $True
```



