## 1. 激活

###### 1.1 无法连接服务器

```
slmgr.vbs -skms zh.us.to
```

