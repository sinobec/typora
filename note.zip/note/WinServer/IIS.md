## 1. Remore IIS Manager

如果需要远程控制IIS server

1. 在IIS server上执行:

   ```
   安装IIS Role
   安装web management service 服务: `**Install-WindowsFeature Web-Mgmt-Service**, 并将其设置为自启动:` **sc config WMSVC start=auto**
   添加防火墙规则: `**netsh advfirewall firewall add rule name=”IIS Remote Management” dir=in action=allow service=WMSVC**`
   运行regedit, 在HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\WebManagement\Server, 将“EnableRemoteManagement”设置为'1"
   启动Web management service: **`net start WMSVC`**
   ```

2. 在操作机上执行:

   ```
   安装IIS Manager for Remote Administration
   运行IIS management
   右键Start site, connect to server
   输入名字或ip
   输入admin信息
   Connect
   1
   ```

   

