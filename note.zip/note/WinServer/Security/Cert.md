## 1. Install

在安装AC CS时，在role里选择Certification Authority Web Enrollment一项，会允许用户在浏览器里请求cert。 因为当请求端的设备和CA server不在同一个网络里时，通过MMC会很难实现(需要选择AD里的Enrollment Policy)。

## 2.Post-install

root cert server配置时选择Enterprise CA

## 3. Issue Cert

###### 3.1 Duplicate from Cert Template

打开Cert authority,在Tempalte一项右键->Manage, 选择cert. 常用的有Computer以及User, 分别针对设备和用户. 然后右键该模板->Duplicate. 在Subject Name里选择common name.

###### 3.2 Issue

右键Cert template->New->...issue, 选择cert. 然后右键该cert->Properties->Security, 添加对应的PC group或User group, 赋予Enroll或Autoenroll权限.

###### 3.3 AutoEnroll

在进行完上述Autoenroll操作后, 需要在DC设置GPO. 

```
Computer | Policies | Windows| Security| Public Key Policies
Enable → Certificate Services Client - Auto-Enrollment
```

## 3. User requests cert

在客户端需要以Admin登录并开启浏览器: https://<CASERVER>/certsrv

