## 1. Change RDP port

```
HKEY_LOCAL_MACHINE\System\CurrentControlSet\Control\Terminal Server\WinStations\RDP-Tcp
#PortNumber, 然后重启
```

## 2. Password GPO

Computer Configuration | Policies | Windows Settings | Security Settings | Account Policies | Password Policy