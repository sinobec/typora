## 1. Dynamic access control(DAC)

> 通常file的访问权限由NTFS和Share控制, 但在需要细分权限的情况下, 会出现过多的user group设置, 其次具备权限的用户可能在不安全的环境或者设备里访问敏感数据, 另外对于仅有的NTFS以及Share安全设置选项, 因为不足矣涵盖各种所需的安全选项, 比如禁止用户copy文件至其他位置.
>
> **DAC**具备更加丰富的权限设置, 同时针对audit还提供了不同权限的汇总功能. 在设置了DAC之后, file的权限将由share, NTFS以及DAC共同监管

可以定义的权限包括:

* **Claim type**: 定义一些用户和计算机的属性. 打开ADAC, 点击Dynamic access control, 右键CLaim types, New. 可以选择很多设置内容, 比如地理位置, 所在部门, 设备描述, DNS host, 员工ID, 电话号码,  title, 甚至单纯的描述字段, 来实现对该User和设备的约束. 
* **Resource Properties** : 定义文件夹的属性. 适用于文件服务器上的档案. 这里可以自定义很多文件额外描述, 比如自定义'重要性', 然后自定义重要性等级. 把这个属性和user联系起来, 就能设置详细的权限.
* **Resource Properties list** : 把定义的文件夹属性放在一个集合里面
* **Central Access Rule**:　针对user／设备和目标文件之间建立权限，比如对地理位置的设备，针对特定文件，建立Deny权限．这样该地区设备无法访问特定文件．
* 设置GPO以便使Central　Access　Rule生效：Computer Configuration/Policies/Windows Settings/Security Settings/File System/Central Access Policy上添加前面创建的Central Access Rule

