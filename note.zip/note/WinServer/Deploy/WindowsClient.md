## 1. Server Role

* DC: AD, DNS, DHCP
* MDT: MDT, WSUS

## 2. DC设置

##### 2.1 设置OU

.ps1

```
$oulist = Import-csv -Path c:\oulist.txt
ForEach($entry in $oulist){
    $ouname = $entry.ouname
    $oupath = $entry.oupath
    New-ADOrganizationalUnit -Name $ouname -Path $oupath
    Write-Host -ForegroundColor Green "OU $ouname is created in the location $oupath"
}
```

.oulist.txt (假设domain为: srv.acis.cc)

```
OUName,OUPath
Acis,"DC=SRV,DC=ACIS,DC=CC"
Accounts,"OU=Acis,DC=SRV,DC=ACIS,DC=CC"
Computers,"OU=Acis,DC=SRV,DC=ACIS,DC=CC"
Groups,"OU=Acis,DC=SRV,DC=ACIS,DC=CC"
Admins,"OU=Accounts,OU=Acis,DC=SRV,DC=ACIS,DC=CC"
Service Accounts,"OU=Accounts,OU=Acis,DC=SRV,DC=ACIS,DC=CC"
Users,"OU=Accounts,OU=Acis,DC=SRV,DC=ACIS,DC=CC"
Servers,"OU=Computers,OU=Acis,DC=SRV,DC=ACIS,DC=CC"
Workstations,"OU=Computers,OU=Acis,DC=SRV,DC=ACIS,DC=CC"
Security Groups,"OU=Groups,OU=Acis,DC=SRV,DC=ACIS,DC=CC"
```

Run .ps1

```
Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Force
Set-Location C:\
.\ou.ps1
```

## 3. MDT

* 在MDT服务器上下载相关程序并安装: https://docs.microsoft.com/en-us/windows-hardware/get-started/adk-install

* 安装ADK for Windows 10 或11, WinPE addons
* 安装 [Windows System Image Manager (WSIM) 1903 update](https://go.microsoft.com/fwlink/?linkid=2095334), 确保**C:\Program Files (x86)\Windows Kits\10\Assessment and Deployment Kit\Deployment Tools\WSIM** -> **Details** tab displays a **File version** of **10.0.18362.144** or later.

##### 3.1 安装WDS, windows deploy services

```
Install-WindowsFeature -Name WDS -IncludeManagementTools
WDSUTIL /Verbose /Progress /Initialize-Server /Server:DC01 /RemInst:"D:\RemoteInstall"
WDSUTIL /Set-Server /AnswerClients:All
```

##### 3.2 安装WSUS

```
Install-WindowsFeature -Name UpdateServices, UpdateServices-WidDB, UpdateServices-Services, UpdateServices-RSAT, UpdateServices-API, UpdateServices-UI
cmd /c "C:\Program Files\Update Services\Tools\wsusutil.exe" postinstall CONTENT_DIR=C:\WSUS
```

* 同时需要在DC上设置GPO: 

  1. gpmc.msc, 右键域, 新建GPO->**WSUS – Auto Updates and Intranet Update Service Location**

  2. 编辑GPO: Computer Configuration\Policies\Administrative Templates\Windows Components\Windows Update. 右键"**Configure Automatic Updates**", Enable -> **Configure Automatic Updates**

     在**Options**下, from the **Configure automatic updating** list, select **3 - Auto download and notify for install** ->OK

     > 在Regedit下确定以下项没有Enable, 否则Windows Store连接不上:
     >
     > Computer\HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\DoNotConnectToWindowsUpdateInternetLocations

  3. 右键**Specify intranet Microsoft update service location**, Edit, Enable->**Specify intranet Microsoft update service location** 

     在**Options**下, in the **Set the intranet update service for detecting updates** and **Set the intranet statistics server** options, type **http://Your_WSUS_Server_FQDN:PortNumber**, and then select **OK**. 端口号为http:8530, https:8531

##### 3.3 安装MDT

https://docs.microsoft.com/en-us/mem/configmgr/mdt/

* 安装MDT service account

  ```
  New-ADUser -Name MDT_BA -UserPrincipalName MDT_BA -path "OU=Service Accounts,OU=Accounts,OU=Acis,DC=SRV,DC=ACIS,DC=CC" -Description "MDT Build Account" -AccountPassword (ConvertTo-SecureString "3891289Gp$$" -AsPlainText -Force) -ChangePasswordAtLogon $false -PasswordNeverExpires $true -Enabled $true
  ```

  

* 开启服务器端Logs,以便读取reference image

  ```
  New-Item -Path D:\Logs -ItemType directory
  New-SmbShare -Name Logs$ -Path D:\Logs -ChangeAccess EVERYONE
  icacls D:\Logs /grant '"MDT_BA":(OI)(CI)(M)'
  ```

  下载Log读取程序:https://go.microsoft.com/fwlink/p/?LinkId=734717

## 4. 建立Windows 10 reference image

*以下步骤均在MDT服务器上完成

##### 4.1 建立MDT workbench

打开Deployment Workbench, 右键**Deployment Shares**, 新建**New Deployment Share**

```
Deployment share path: D:\MDTBuildLab
Share name: MDTBuildLab$
Deployment share description: MDT Build Lab
# 确定可以访问 \\MDT01\MDTBuildLab$
```

为了确保MDT账户可以读取MDT workbench里的配置, 然后将Image写入daoworkbench里, 需要让该账户具备NTFS以及SMB的对于文件夹**D:\MDTBuildLab**的相应权限

```
icacls "D:\MDTBuildLab" /grant '"SRV\MDT_BA":(OI)(CI)(M)'
grant-smbshareaccess -Name MDTBuildLab$ -AccountName "SRV\MDT_BA" -AccessRight Full -force
#SRV/MDT_BA是该账户的全名
```

##### 4.2 建立MDT setup文件

1. 将Windows IOS解压到D:\Downloads\WinISO

2. 在MDT Workbench里展开**Deployment Shares** -> **MDT Build Lab**, 右键**Operating Systems** , 新建folder **Windows 10**

3. 右键这个Windows 10文件夹, 选择**Import Operating System**

   ```
   Full set of source files
   Source directory: (WinISO文件夹)
   Destination directory name: W10X64
   ```

4. 之后会在这个Windows 10文件夹内出现一个或多个安装项目

##### 4,3 设置附加安装Programs

1. 在MDT workbench里展开**Deployment Shares \ MDT Build Lab \ Applications**

2. 右键**Applications**, 新建Folder ->比如叫做**Microsoft**

3. **安装O365**: 下载相应的Program比如O365,https://www.microsoft.com/download/details.aspx?id=49117. 将其解压到D:/Downloads/O365. 在该文件夹中需要新增配置configuration.xml, 例如

   ```
   <Configuration>
    <Add OfficeClientEdition="64" Channel="Broad">
      <Product ID="O365ProPlusRetail">
        <Language ID="en-us" />
      </Product>
    </Add>
    <Display Level="None" AcceptEULA="TRUE" />
    <Updates Enabled="TRUE" />
   </Configuration>
   ```

   * 建立O365的安装源(安装O365之后不要打开).

     ```
     $ApplicationName = "Install - Office365 ProPlus - x64"
     $CommandLine = "setup.exe /configure configuration.xml"
     $ApplicationSourcePath = "D:\Downloads\Office365"
     Import-MDTApplication -Path "DS001:\Applications\Microsoft" -Enable "True" -Name $ApplicationName -ShortName $ApplicationName -CommandLine $CommandLine -WorkingDirectory ".\Applications\$ApplicationName" -ApplicationSourcePath $ApplicationSourcePath -DestinationFolder $ApplicationName -Verbose
     ```

     

4. 安装Powershell MDT管理模块(适用于安装大量App)

   ```
   Import-Module "C:\Program Files\Microsoft Deployment Toolkit\bin\MicrosoftDeploymentToolkit.psd1"
   New-PSDrive -Name "DS001" -PSProvider MDTProvider -Root "D:\MDTBuildLab"
   ```

5. 安装Visual C++ Redistributable 2019

   ```
   $ApplicationName = "Install - MSVC 2019 - x64"
   $CommandLine = "vc_redist.x64.exe /Q"
   $ApplicationSourcePath = "D:\Downloads"
   Import-MDTApplication -Path "DS001:\Applications\Microsoft" -Enable "True" -Name $ApplicationName -ShortName $ApplicationName -CommandLine $CommandLine -WorkingDirectory ".\Applications\$ApplicationName" -ApplicationSourcePath $ApplicationSourcePath -DestinationFolder $ApplicationName -Verbose
   ```

   ```
   $ApplicationName = "Install - MSVC 2019 - x86"
   $CommandLine = "vc_redist.x86.exe /Q"
   $ApplicationSourcePath = "D:\Downloads"
   Import-MDTApplication -Path "DS001:\Applications\Microsoft" -Enable "True" -Name $ApplicationName -ShortName $ApplicationName -CommandLine $CommandLine -WorkingDirectory ".\Applications\$ApplicationName" -ApplicationSourcePath $ApplicationSourcePath -DestinationFolder $ApplicationName -Verbose
   ```

##### 4.4 建立reference image task sequence

该过程将引用之前创造的OS以及App, 并且从WSUS服务器获取更新

1. 在**Deployment Shares > MDT Build Lab**下右键**Task Sequences**, 新建文件夹->Windows 10

2. 右键该Windows文件夹, 新建 **New Task Sequence**.

   ```
   Task sequence ID: REFW10X64-001
   Task sequence name: Windows 10 Enterprise x64 RTM Default Image
   Task sequence comments: Reference Build
   Template: Standard Client Task Sequence
   Select OS: 选择相关的版本, 安装ISO有多个版本的会显示于此
   Specify Product Key: Do not specify a product key at this time
   Full Name: Contoso
   Organization: Contoso
   Internet Explorer home page: http://www.contoso.com
   Admin Password: Do not specify an Administrator Password at this time
   ```

3. **设置安装选项**: 安装O365, WSUS, features等等

   在上述Windows 10文件夹里, 右键'Windows 10 Enterprise x64 RTM Default Image'项目 -> **Properties**

   a: 在**Task Sequence** tab进行如下配置

   ```
   在State Restore下 
   > Windows Update (Pre-Application Installation) action: 在Options tab -> 清除Disable
   
   > Windows Update (Post-Application Installation) action: Also enable this action.
   
   >After the Tattoo action, add a new Group action (点击右上角Add ->New Group) 
   	1. Name: Custom Tasks (Pre-Windows Update)
   	2. 右上角Add a new Install Roles and Features action: 
   		Name: Install - Microsoft NET Framework 3.5.1
   		选择: Windows 10
   		选择: .NET Framework 3.5 (includes .NET 2.0 and 3.0)
   	3. After the Install - Microsoft NET Framework 3.5.1 action, add a "new Install Application' action, 右上角Add-?General:
   		Name: Microsoft Visual C++ Redistributable 2019 - x86
   		选择: Install a Single Application: browse to 'Install - MSVC 2019 - x86'
   	4. 重复3, 选择'Install - MSVC 2019 - x64'
   	5. 重复3, 选择'Microsoft 365 Apps'
   
   >After Windows Update (Post-Application Installation) action,更名'Custom Tasks'为'Custom Tasks (Post-Windows Update)'
   ```

   [Option]: Lite Touch Installation (LTI) Suspend, 当需要在安装时手动执行某些操作, 可以

##### 4.5 MDT deployment share rules

该rules对应与**D:\MDTBuildLab\Control\CustomSettings.ini**文件

1. 右键**MDT Build Lab**, 选择properties, 选择**Rules** tab(该文件改变内容会即时更新, 不必重新Update image)

   ```
   [Settings]
   Priority=Default
   
   [Default]
   _SMSTSORGNAME=ACIS
   UserDataLocation=NONE
   DoCapture=YES
   OSInstall=Y
   AdminPassword=38912389Gp$$
   TimeZoneName=Eastern Standard Time 
   JoinWorkgroup=WORKGROUP
   HideShell=YES
   FinishAction=SHUTDOWN
   DoNotCreateExtraPartition=YES
   WSUSServer=http://DC01.srv.acis.cc:8530
   ApplyGPOPack=NO
   SLSHARE=\\DC01\Logs$
   SkipAdminPassword=YES
   SkipProductKey=YES
   SkipComputerName=YES
   SkipDomainMembership=YES
   SkipUserData=YES
   SkipLocaleSelection=YES
   SkipTaskSequence=NO
   SkipTimeZone=YES
   SkipApplications=YES
   SkipBitLocker=YES
   SkipSummary=YES
   SkipRoles=YES
   SkipCapture=NO
   SkipFinalSummary=YES
   ```

   在同个tab里,点击Edit bootstrap.ini(该文件改变后需要重新Update, 生成新的Boot image):

   ```
   [Settings]
   Priority=Default
   
   [Default]
   DeployRoot=\\DC01\MDTBuildLab$
   UserDomain=SRV
   UserID=MDT_BA
   UserPassword=3891289Gp$$
   
   SkipBDDWelcome=YES
   ```

2.  选择WinPE tab

   * x86

     ```
     Image description: MDT Build Lab x86
     ISO file name: MDT Build Lab x86.iso
     ```

   * x64

     ```
     Image description: MDT Build Lab x64
     ISO file name: MDT Build Lab x64.iso
     ```

##### 4.6 Update the deployment share

该步骤生成boot image: 右键**MDT Build Lab**, 点击**Update Deployment Share**

##### 4.7 Build the Windows 10 reference image

1. 将D:\MDTBuildLab\Boot\MDT Build Lab x86.iso拷贝到HV宿主机的某个文件夹,x86 iso可以部署32以及64位OS.

2. 在HV宿主机(已有HyperV)上新建Windows虚拟机, 

3. 需要先建立Virtual Switch(External), 虚拟机使用该vs. 然后在宿主机的Network share设置重新设置DNS以便让宿主机以及VM可以连通DC.

   ```
   Name: REFW10X64-001
   Store the virtual machine in a different location: C:\VM
   Generation 1
   Memory: 2024 MB
   #在内存设置里, min ram设置为1024MB
   Network: Must be able to connect to \MDT01\MDTBuildLab$
   Hard disk: 60 GB (dynamic disk)
   Install OS with image file: C:\ISO\MDT Build Lab x86.iso
   ```

   然后建立一个Checkpoint(在HyperV Manager右下角菜单)

   查询VM是否可以链接到\\DC01\MDTBuildLab$, 可以使用在虚拟机启动后执行`pushd \\DC01\MDTBuildLab$`

3. 开始生成Win10 ref image:

   选择 ->Capture an image of this reference computer

   ```
   Location: \\MDT01\MDTBuildLab$\Captures
   File name: REFW10X64-001.wim
   ```

   

