## 1. GPO部署Program

##### 1. 1 在server上创建共享文件夹

该文件夹的NTFS Permission需要允许Authenticated User.  将其共享给Authenticated Users（在Advanced Share里设置). 共享权限设为Full Control

##### 1.2 建立GPO

在server上新建GPO. Computer -> Conf ->Software -> Installation, 右键New Package, 选择网络路径下的文件夹里的msi

##### 

## 2. Script

##### 2.1 编辑安装script

需要设置好server的安装文件位置,文件名; 客户端目标文件夹

```
@echo off
REM Begin Script
REM Remote software installation script
REM Author: Jason Pearce of jasonpearce.com
REM Written: 2010 November 17
REM Trigger this script as a scheduled task via Group Policy

@REM INSTALL APPLICATION FROM LOCAL MEDIA
@echo off
setlocal EnableDelayedExpansion

REM Variables
SET FRIENDLYNAME=软件名称...
SET SOURCEFOLDER=D:\Downloads
SET SOURCEFILE=源文件名称.msi
SET TARGETFOLDER=%Temp%
SET LOGFOLDER=\\服务器log文件文件夹

REM Copy remote media to local folder
echo %DATE% %TIME% Began copying %FRIENDLYNAME% from %SOURCEFOLDER% to %TARGETFOLDER% >>%LOGFOLDER%\%COMPUTERNAME%.txt
%SystemRoot%\system32\xcopy.exe %SOURCEFOLDER% %TARGETFOLDER% /Y /E /I /S
echo %DATE% %TIME% Finished copying %FRIENDLYNAME% from %SOURCEFOLDER% to %TARGETFOLDER% >>%LOGFOLDER%\%COMPUTERNAME%.txt
echo %COMPUTERNAME%,%DATE%,%TIME%,%FRIENDLYNAME%,copied >>%LOGFOLDER%\InstallationLog.csv

REM Install application on client
echo %DATE% %TIME% Began installing %FRIENDLYNAME% >>%LOGFOLDER%\%COMPUTERNAME%.txt
%SystemRoot%\system32\msiexec.exe /i %TARGETFOLDER%\%SOURCEFILE% /qn
echo %DATE% %TIME% Finished installing %FRIENDLYNAME% >>%LOGFOLDER%\%COMPUTERNAME%.txt
echo %COMPUTERNAME%,%DATE%,%TIME%,%FRIENDLYNAME%,installed >>%LOGFOLDER%\InstallationLog.csv

REM Delete local installation media
echo %DATE% %TIME% Began deleting %TARGETFOLDER% >>%LOGFOLDER%\%COMPUTERNAME%.txt
rd %TARGETFOLDER% /S /Q
echo %DATE% %TIME% Finished deleting %TARGETFOLDER% >>%LOGFOLDER%\%COMPUTERNAME%.txt
echo %COMPUTERNAME%,%DATE%,%TIME%,%FRIENDLYNAME%,folder deleted >>%LOGFOLDER%\InstallationLog.csv

echo End Installation Script
```

##### 2.2 建立GPO

1. 编辑GPO: Computer > Preferences > Control Panel Settings > Scheduled Tasks

2. 右键'新建Scheduled Task`

   ```
   Action - create
   Run - 选择上述bat
   Schedule - 选择Once
   Setting>Power Management - Wake the computer to run this task
   ```

   建立一个GPO就可以对应多个Scheduled Tasks(每个Task执行一个.bat安装文件)

















