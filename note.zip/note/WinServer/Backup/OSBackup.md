## 1. Windows server backup:

add new role

#### 1.1 System State backup

https://www.comparitech.com/net-admin/active-directory-backup-guide/

## 2. WIndowns station backup

Control panel -> schedule backup

