## 1. Desired State Configuration (DSC)

> Desired State Configuration (DSC)可以保存服务器的环境配置, 比如环境变量以及运行的services等. 一旦配置环境有变, DSC将自动恢复原有配置.

建立DSC服务器的方法是安装Local Configuration Manager (LCM): **Windows Management Framework**, 可以实时监控服务器是否依照DSC配置运行.

