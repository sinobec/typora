## 1. Audit Login/Logoff

1. 新建GPO

   ```
   Computer ➔ Policies ➔ Windows ➔ Security ➔ Advanced Audit Policy Configuration ➔ “Audit Policies” ➔ “Logon/Logoff”.
   Computer ➔ Policies ➔ Windows ➔ Security ➔ Advanced Audit Policy Configuration ➔ “Audit Policies” ➔ System > Audit Security State Change — Set this to “Success”.
   ```

   依次点选Logon/Logoff/Other LogOnOff, 然后选择里面的两个选项;

2. 在该GPO的Security Filter里, Add->Everyone

3. 新建powershell ps1

   ```
   #### Find DC list from Active Directory
   $DCs=Get-ADDomainController-Filter*
    
   #### Define time for report (default is 1 day)
   $startDate= (get-date).AddDays(-1)
   
   #### Store successful logon events from security logs with the specified dates and workstation/IP in an array
   
   foreach ($DCin$DCs){
   $slogonevents=Get-Eventlog-LogNameSecurity-ComputerName$DC.Hostname -after$startDate|where {($_.eventID -eq4624) -or ($_.eventID -eq4625) }} 
   
   #### Crawl through events; print all logon history with type, date/time, status, account name, computer and IP address if user logged on remotely
   
   
     foreach ($ein$slogonevents){
       #### Logon Successful Events
       #### Local (Logon Type 2)
   
       if (($e.EventID -eq4624 ) -and ($e.ReplacementStrings[8]-eq2)){
         write-host"Type: Local Logon`tDate: "$e.TimeGenerated "`tStatus: Success`tUser: "$e.ReplacementStrings[5]"`tWorkstation: "$e.ReplacementStrings[11]
       }
   
       #### Remote (Logon Type 10)
       if (($e.EventID -eq4624 ) -and ($e.ReplacementStrings[8]-eq10)){
         write-host"Type: Remote Logon`tDate: "$e.TimeGenerated "`tStatus: Success`tUser: "$e.ReplacementStrings[5]"`tWorkstation: "$e.ReplacementStrings[11]"`tIP Address: "$e.ReplacementStrings[18]
       }
   
       #### Logon Failed Events
       #### Local (Logon Type 2)
   
       if (($e.EventID -eq4625 ) -and ($e.ReplacementStrings[8]-eq2)){
         write-host"Type: Local Logon`tDate: "$e.TimeGenerated "`tStatus: Failed`tUser: "$e.ReplacementStrings[5]"`tWorkstation: "$e.ReplacementStrings[11]
       }
   
       #### Remote (Logon Type 10)
   
       if (($e.EventID -eq4625 ) -and ($e.ReplacementStrings[8]-eq10)){
         write-host"Type: Remote Logon`tDate: "$e.TimeGenerated "`tStatus: Failed`tUser: "$e.ReplacementStrings[5]"`tWorkstation: "$e.ReplacementStrings[11]"`tIP Address: "$e.ReplacementStrings[18]
   }} 
   ```
   
   