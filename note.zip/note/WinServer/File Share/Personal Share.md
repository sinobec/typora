# **Home folder  My Document文件夹重定向**

- **Step 1**:

1.Server management center: Add role: file server resource manager.

2.在Service manager → file and storage service → share: 右边空白处右键“New Share”.

1. SMB advanced

2. 选择目标盘

3. 命名为 xxx$

4. Enable access-based emulation and caching

5. **~~Customize permissions：** Disable inheritance and Convert inherited permissions into...~~

   只保留Admin/System/OWNER的full control权限。→ Next

6. **Management Properties**: Select "User Files" on Management properties, → Next

7. **Quota**:  "Auto apply template", 选择一个Quota template， Next...

8. 在资源管理器里访问该Folder, 右键属性 - 共享, 记录下共享的path， 比如\\SRV1\Private$.

- [**Step 2**](https://tidal.com/browse/track/162800000):

1. 新建GPO(在合适的OU下)
2. User Configuration | Policies | Windows Settings | Folder Redirection | Documents
3. 右键 - 属性
4. Setting → Basic - Redirect everyone's folder to the same location
5. Root Path, 选择刚才建立的共享文件夹

Step 2：

1. 在AD UserComputer 里,多选用户, 在Profile里的Home folder里选择connect , to选择一个盘符，填写之前记录的共享文件夹的 “path\%UserName%”， 比如“\\SRV1\Private$\%UserName%”
2. 用户重登录.

### [建立user roaming profile]

Logon scripts比GPO慢很多,除非特殊需要,一般建议使用GPO

该方法因为文件巨大且登录缓慢,已经逐渐过时,取代的是Azure AD里的Enterprise State Roaming或者Experience Virtualization (UE-V). 对于文件共享, 常用的是云存储比如OneDrive.

**- Step 1:**

1.在Service manager → file and storage service → share: 右边空白处右键“New Share”

2.选择SMB quick

3.选择磁盘

4.ShareName后面要加$

5.选择Enable access-based enumeration & Encrypt data access .

6.Customized permission: Remove inheritance: Convert inheritance into explicit....

7.Remove Users

8.新建Authenticated Users, 取消所有默认, 点击高级permission, list folder & create folder, scope选择this folder only.

9.创建profile

**-  Step 2: 将profile添加到(允许使用该profile的)用户里**

在User属性里的profile一栏, 添加\\serverName\profileName$\%username%