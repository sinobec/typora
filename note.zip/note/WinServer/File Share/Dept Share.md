# **[自动Mapping网络部门文件夹]: GPO → Scope**

在创建新用户以后, 通常会设置用户可以自动访问的网络文件夹以便获取共享资源.

通过设立不同的用户组, 把每个组拥有访问属于该组的特定文件夹的权限

### *  **Step 1: 创建部门共享文件夹**

1.在Service manager → file and storage service → share: 右边空白处右键“New Share”.

2.选择SMB quick

3.选择目标磁盘

4.设置ShareName

5.可以不选择Enable access-based enumeration & Encrypt data access .

6.Customized permission → Remove inheritance → Convert inheritance into explicit....

7.Remove Users, 保留Admin/System/Owner

8.Add → 准备授权的组名,  比如Sales， 默认权限加上write.

9.创建

### * **Step 2: GPO自动Map部门共享文件夹**

1.在主OU下, 新建“Share Folder”并添加网络地址(该地址需为上一步创建的Share的地址,此时在服务器对应的目标盘会自动创建文件夹, 右键Share会显示path)

2.新建GPO, User - Preference - Windows Setting - Drive Map

3."New Mapped Drive" - ... 选择对应的目标位置，比如\\DC1\Pubilc Files$，  → 选择“Reconnect”并选择开始盘符.

4.在新建好的GPO里设置Scope,删除authenticated users并增加对应的Group（此步骤是为了避免所有的域用户都有浏览该文件夹的权限，即仅允许特定组有此文件夹权限）.在Delegation里新增authenticated  users并设置为Read.