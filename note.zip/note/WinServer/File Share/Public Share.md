GPO不可以应用在Container上

- server共享的文件不可以有everyone的用户权限,取代的是authenticated user.

> File and Storage Services: FSRM



### *  **Step 1: 创建公共共享文件夹**

1.在Service manager → file and storage service → share: 右边空白处右键“New Share”.

2.选择SMB quick

3.选择目标磁盘

4.设置ShareName， 需要在最后添加$,比如“Pubilc Files$"

5.可以不选择Enable access-based enumeration & Encrypt data access .

6.Customized permission → Remove inheritance → Convert inheritance into explicit....

7.Remove Users, 保留Admin/System/Owner,

8.添加“Authentication Users”，选择默认权限， 如果允许用户新建文件夹和文件，需要增加Write权限。

9.创建

### * **Step 2: GPO自动Map域共享文件夹**

1.在主OU下, 新建“Share Folder”并添加网络地址(该地址需为上一步创建的Share的地址,此时在服务器对应的目标盘会自动创建文件夹, 右键Share会显示path)

2.新建GPO, User - Preference - Windows Setting - Drive Map

3."New Mapped Drive" - ... 选择对应的目标位置，比如\\DC1\Pubilc Files$，  → 选择“Reconnect”并选择开始盘符.



