## 1. Var Scope

##### 1.1 Global var:

`let var = 'abc'` #仅能声明一次, 但是可以更改值

##### 1.2 Local var:

 在code里的变量是local var

## 2. Var的遮影法则

在函数里, 对变量的引用会逐级向上级查询是否已有定义, 以第一个被查询到的定义为准(即使再向上还有其他定义)

```javascript
let petname = 'cat'
if (true) {
	let petname = 'dog'
		if (true) {
			console.log(petname)  //这里输出dog.
		}
}
```

