## 1. 常用内置函数

str.length():

str.split()  :

str.trim) :